#!/usr/bin/env python3
"""Forward-test report: reads the app's own recorded trades / signal outcomes from XXX/ and prints an honest verdict.

    python tools/forward_eval.py            # human readable
    python tools/forward_eval.py --json     # machine readable
Works offline (no server needed). Set TITAN_DATA to point at another data folder.
"""
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from app.engine import readiness  # noqa: E402


def line(label: str, st: dict) -> str:
    if not st.get("n"):
        return f"  {label:<14} —"
    ci = st.get("ci95") or [None, None]
    return (f"  {label:<14} n={st['n']:<4} mean={st['mean']:+.3f}  t={st['t']:+.2f}  win={st['win']:.0f}%  PF={st['pf']}  "
            f"CI95=[{ci[0]}, {ci[1]}]  maxDD={st['max_dd']}  worst-streak={st['worst_streak']}")


def main() -> None:
    r = readiness.assess()
    if "--json" in sys.argv:
        print(json.dumps(r, ensure_ascii=False, indent=1))
        return
    p = r["paper"]
    print("═══ TITAN forward evaluation ═══")
    print(f"Paper trades (R multiples after fees/slippage):\n{line('ALL', p['stats'])}")
    print(f"  VERDICT: {p['verdict']['fa']} — {p['verdict']['why']}")
    for k in ("by_grade", "by_side", "by_reason"):
        if p[k]:
            print(f"\n{k}:")
            for name, st in p[k].items():
                print(line(name, st))
    s = r["signals"]
    print(f"\nSignal outcomes ({s['n']} logged, directional % after {s['cost_pct']}% costs):")
    for h, st in s["horizon_after_costs_pct"].items():
        print(line(h, st))
    pa = s["path"]
    print(f"  TP1-before-SL: {pa['tp1']} vs {pa['sl']}  (p={pa['p_tp1']})")
    print("\n" + r["rules"])


if __name__ == "__main__":
    main()
