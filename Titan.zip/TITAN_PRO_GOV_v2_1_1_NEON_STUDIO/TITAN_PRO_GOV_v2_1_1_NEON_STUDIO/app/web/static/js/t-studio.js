/* TITAN · Studio: 170+ personalization options (colors, glass, neon effects, background, typography, layout, dashboard widgets,
   chart, data), 16 theme presets, live preview, export/import, plus the effects engine (particles, cursor glow, ripple, tilt, count-up). */
(function (W) {
  'use strict';
  const T = W.TT, S = T.S, esc = T.esc, V = T.V = T.V || {};
  const P = T.P = { O: [], cats: [], byId: {} };

  /* ── option registry ── */
  const CATS = [['theme', 'تم‌ها', 'spark'], ['colors', 'رنگ‌ها', 'layers'], ['glass', 'شیشه و کارت', 'cube'], ['fx', 'افکت‌های نئونی', 'bolt'], ['bg', 'پس‌زمینه', 'globe'], ['type', 'قلم و متن', 'book'],
    ['layout', 'چیدمان و ناوبری', 'grid'], ['dash', 'ویجت‌های داشبورد', 'home'], ['market', 'بازار و کارت‌ها', 'coins'], ['work', 'صفحهٔ ارز', 'candles'], ['chart', 'نمودار', 'activity'], ['chartc', 'رنگ نمودار', 'ruler'], ['data', 'داده، زمان و رفتار', 'clock'], ['backup', 'پشتیبان و بازنشانی', 'db']];
  P.CATS = CATS;
  function opt(cat, id, label, type, def, x) { const o = Object.assign({ cat, id, label, type, def }, x || {}); P.O.push(o); P.byId[id] = o; }
  const sel = (cat, id, label, def, pairs, x) => opt(cat, id, label, 'select', def, Object.assign({ opts: pairs }, x || {}));
  const rng = (cat, id, label, def, min, max, step, x) => opt(cat, id, label, 'range', def, Object.assign({ min, max, step }, x || {}));
  const col = (cat, id, label, def, x) => opt(cat, id, label, 'color', def, x);
  const tog = (cat, id, label, def, x) => opt(cat, id, label, 'toggle', def, x);
  const ON = [[1, 'روشن'], [0, 'خاموش']];

  // colors (brand + text + aurora)
  col('colors', 'bull', 'رنگ صعود / خرید', '#35f2c1', { css: '--bull' }); col('colors', 'bear', 'رنگ نزول / فروش', '#ff5a86', { css: '--bear' });
  col('colors', 'warn', 'رنگ هشدار / انتظار', '#ffc861', { css: '--warn' }); col('colors', 'info', 'رنگ اطلاعات', '#62b0ff', { css: '--info' });
  col('colors', 'ai', 'رنگ هوش مصنوعی / ویژه', '#a88bff', { css: '--ai' }); col('colors', 'gold', 'رنگ طلایی', '#ffd98a', { css: '--gold' });
  col('colors', 'ink', 'رنگ متن اصلی', '#e9efff', { css: '--ink' }); col('colors', 'ink2', 'رنگ متن دوم', '#a9b6e0', { css: '--ink2' }); col('colors', 'mut', 'رنگ متن کم‌رنگ', '#7482b3', { css: '--mut' });
  col('colors', 'bg0', 'رنگ زمینهٔ اصلی', '#050918', { css: '--bg0' }); col('colors', 'bgA', 'درخشش زمینه ۱', '#18235a', { css: '--bgA' }); col('colors', 'bgB', 'درخشش زمینه ۲', '#2a1250', { css: '--bgB' });
  col('colors', 'a1', 'شفق ۱', '#2f5bff', { css: '--a1' }); col('colors', 'a2', 'شفق ۲', '#00e0b0', { css: '--a2' }); col('colors', 'a3', 'شفق ۳', '#b13cff', { css: '--a3' });
  sel('colors', 'mode', 'حالت روشن / تیره', 'dark', [['dark', 'تیره'], ['light', 'روشن']]);
  rng('colors', 'hue', 'چرخش رنگ کل رابط (درجه)', 0, 0, 360, 5, { fn: 'filter' }); rng('colors', 'sat', 'اشباع رنگ کل رابط', 100, 40, 200, 5, { fn: 'filter' });
  rng('colors', 'bri', 'روشنایی کل رابط', 100, 60, 140, 2, { fn: 'filter' }); rng('colors', 'con', 'کنتراست کل رابط', 100, 70, 140, 2, { fn: 'filter' });
  // glass + cards
  rng('glass', 'blur', 'میزان تاری شیشه (px)', 24, 0, 60, 1, { css: '--blur', unit: 'px' }); rng('glass', 'gsat', 'اشباع پشت شیشه (٪)', 150, 80, 260, 5, { css: '--sat', unit: '%' });
  rng('glass', 'ga', 'غلظت شیشه (بالا)', 0.085, 0, 0.5, 0.005, { css: '--ga' }); rng('glass', 'gb', 'غلظت شیشه (پایین)', 0.028, 0, 0.4, 0.005, { css: '--gb' });
  rng('glass', 'gla', 'شفافیت لبهٔ شیشه', 0.13, 0, 0.8, 0.01, { css: '--gla' }); rng('glass', 'bw', 'ضخامت لبه (px)', 1, 0, 4, 0.5, { css: '--bw', unit: 'px' });
  rng('glass', 'r1', 'گردی کارت‌ها (px)', 22, 0, 44, 1, { css: '--r1', unit: 'px' }); rng('glass', 'r2', 'گردی کنترل‌ها (px)', 14, 0, 30, 1, { css: '--r2', unit: 'px' });
  rng('glass', 'shadow', 'سایهٔ کارت‌ها', 0.8, 0, 1.6, 0.05, { css: '--shadow' });
  sel('glass', 'cards', 'سبک کارت', 'glass', [['glass', 'شیشه‌ای'], ['outline', 'فقط خط‌دور'], ['flat', 'تخت'], ['neon', 'نئونی'], ['neu', 'برجسته (Neumorphic)'], ['solid', 'تو‌پر']], { da: 'cards' });
  sel('glass', 'glassx', 'نوع شیشه', 'default', [['default', 'پیش‌فرض'], ['crystal', 'کریستالی'], ['frosted', 'مات'], ['smoke', 'دودی'], ['none', 'بدون برق لبه']], { da: 'glass' });
  sel('glass', 'btn', 'سبک دکمه‌ها', 'round', [['round', 'گرد'], ['square', 'تیز'], ['pill', 'قرصی'], ['neon', 'نئونی']], { da: 'btn' });
  sel('glass', 'tabs', 'سبک تب‌ها', 'pill', [['pill', 'قرصی'], ['underline', 'زیرخط'], ['box', 'جعبه‌ای'], ['neon', 'نئونی']], { da: 'tabs' });
  sel('glass', 'sec', 'سبک عنوان بخش‌ها', 'fade', [['fade', 'خط محو'], ['line', 'خط رنگی'], ['box', 'کادر'], ['none', 'بدون خط']], { da: 'sec' });
  // fx
  rng('fx', 'gk', 'شدت درخشش نئون', 1, 0, 3, 0.1, { css: '--gk' });
  sel('fx', 'aurora', 'شفق پس‌زمینه', 'on', [['on', 'ثابت'], ['anim', 'متحرک'], ['off', 'خاموش']], { da: 'aurora' }); rng('fx', 'ab', 'تاری شفق', 1, 0.3, 2.5, 0.1, { css: '--ab' });
  sel('fx', 'neon', 'حاشیهٔ نئونی کارت‌های مهم', 'pulse', [['none', 'بدون'], ['pulse', 'ضربان'], ['rotate', 'چرخان رنگین‌کمانی'], ['all', 'همهٔ کارت‌ها']], { da: 'neon' });
  tog('fx', 'scan', 'خطوط اسکن CRT', false, { da: 'scan' }); rng('fx', 'scanop', 'شدت خطوط اسکن', 0.5, 0.1, 1, 0.05, { css: '--scanop' });
  tog('fx', 'grain', 'دانهٔ فیلم (Grain)', false, { da: 'grain' }); rng('fx', 'grainop', 'شدت دانه', 0.07, 0.02, 0.2, 0.01, { css: '--grainop' });
  tog('fx', 'vig', 'حاشیهٔ تیره (Vignette)', false, { da: 'vig' }); tog('fx', 'hud', 'گوشه‌های HUD روی کارت‌ها', false, { da: 'hud' });
  tog('fx', 'tilt', 'کج‌شدن سه‌بعدی کارت‌ها با ماوس', true, { da: 'tilt' }); tog('fx', 'hoverlift', 'بالا‌آمدن کارت هنگام هاور', false, { da: 'hoverlift' });
  tog('fx', 'ripple', 'موج لمس / کلیک', true); tog('fx', 'cglow', 'نور دنبال‌کنندهٔ ماوس', true); tog('fx', 'countup', 'شمارش متحرک اعداد', true);
  sel('fx', 'particles', 'ذرات متحرک پس‌زمینه', 'network', [['off', 'خاموش'], ['stars', 'ستارگان'], ['dots', 'نقاط شناور'], ['network', 'شبکهٔ متصل'], ['matrix', 'باران ماتریکس'], ['snow', 'برف'], ['fireflies', 'کرم شب‌تاب'], ['bubbles', 'حباب']]);
  rng('fx', 'pcount', 'تعداد ذرات', 70, 10, 260, 5); rng('fx', 'pspeed', 'سرعت ذرات', 1, 0.2, 4, 0.1); rng('fx', 'psize', 'اندازهٔ ذرات', 1.6, 0.6, 5, 0.1); rng('fx', 'pop', 'شفافیت ذرات', 0.5, 0.1, 1, 0.05);
  sel('fx', 'pcolor', 'رنگ ذرات', 'bull', [['bull', 'رنگ صعود'], ['info', 'رنگ اطلاعات'], ['ai', 'رنگ ویژه'], ['ink', 'رنگ متن'], ['rainbow', 'رنگین‌کمان']]);
  sel('fx', 'anim', 'انیمیشن ورود صفحه', 'rise', [['rise', 'بالا‌آمدن'], ['fade', 'محو'], ['slide', 'لغزش'], ['zoom', 'بزرگ‌شدن'], ['none', 'بدون']], { da: 'anim' });
  rng('fx', 'spd', 'سرعت همهٔ انیمیشن‌ها', 1, 0.3, 3, 0.1, { css: '--spd' }); tog('fx', 'chglow', 'درخشش نمودار', true);
  sel('fx', 'title', 'سبک عنوان‌ها', 'plain', [['plain', 'ساده'], ['glow', 'درخشان'], ['gradient', 'گرادیان']], { da: 'title' }); tog('fx', 'snd', 'صدای هشدار سیگنال جدید', false);
  // background
  sel('bg', 'bgmode', 'نوع پس‌زمینه', 'aurora', [['aurora', 'شفق'], ['grid', 'شبکه'], ['dots', 'نقطه‌چین'], ['mesh', 'مش رنگی'], ['gradient', 'گرادیان'], ['solid', 'تک‌رنگ'], ['image', 'تصویر شخصی']], { da: 'bgmode' });
  opt('bg', 'bgimg', 'تصویر پس‌زمینه (آپلود)', 'file', ''); rng('bg', 'bgdim', 'تیرگی روی تصویر', 0.45, 0, 0.9, 0.05, { fn: 'bgdim' });
  // typography
  sel('type', 'font', 'قلم رابط', 'vaz', [['vaz', 'Vazirmatn (پیش‌فرض)'], ['sys', 'سیستم'], ['tahoma', 'Tahoma'], ['segoe', 'Segoe UI'], ['serif', 'سریف (Georgia)'], ['mono', 'تک‌فاصله'], ['rounded', 'گرد (Trebuchet)'], ['arial', 'Arial']], { fn: 'font' });
  rng('type', 'fs', 'اندازهٔ متن (px)', 14, 11, 20, 0.5, { css: '--fs', unit: 'px' }); rng('type', 'lh', 'ارتفاع خط', 1.7, 1.3, 2.2, 0.05, { css: '--lh' });
  rng('type', 'ls', 'فاصلهٔ حروف (px)', 0, -0.5, 3, 0.1, { css: '--ls', unit: 'px' }); rng('type', 'fw', 'ضخامت متن', 400, 300, 600, 50, { css: '--fw' }); rng('type', 'hw', 'ضخامت عنوان‌ها', 650, 400, 900, 50, { css: '--hw' });
  sel('type', 'monof', 'قلم اعداد و قیمت', 'mono', [['mono', 'تک‌فاصله'], ['same', 'همان قلم رابط'], ['tabular', 'جدولی']], { fn: 'mono' });
  rng('type', 'zoom', 'بزرگ‌نمایی کل رابط (٪)', 100, 70, 150, 5, { fn: 'zoom' });
  // layout
  sel('layout', 'nav', 'جای منوی اصلی', 'right', [['right', 'راست (ستون)'], ['left', 'چپ (ستون)'], ['top', 'بالا (نوار)'], ['bottom', 'پایین (داک)'], ['hidden', 'مخفی']], { da: 'nav' });
  sel('layout', 'railstyle', 'سبک ستون منو', 'glass', [['glass', 'شیشه‌ای'], ['solid', 'تو‌پر'], ['float', 'شناور'], ['flat', 'بدون زمینه']], { da: 'railstyle' });
  sel('layout', 'labels', 'برچسب منو', 'on', [['on', 'آیکن + نام'], ['off', 'فقط آیکن']], { da: 'labels' }); rng('layout', 'rail', 'عرض ستون منو (px)', 92, 56, 150, 2, { css: '--rail', unit: 'px' });
  sel('layout', 'topbar', 'نوار بالا', 'on', [['on', 'کامل'], ['solid', 'تو‌پر'], ['min', 'کم‌حجم'], ['off', 'مخفی']], { da: 'topbar' });
  sel('layout', 'density', 'تراکم', 'normal', [['compact', 'فشرده'], ['normal', 'عادی'], ['spacious', 'باز']], { da: 'density' });
  rng('layout', 'gap', 'فاصلهٔ کارت‌ها (px)', 14, 4, 32, 1, { css: '--gap', unit: 'px' }); rng('layout', 'pad', 'فضای داخلی کارت (px)', 16, 6, 32, 1, { css: '--pad', unit: 'px' });
  rng('layout', 'padv', 'حاشیهٔ صفحه (px)', 22, 4, 60, 2, { css: '--pad-view', unit: 'px' }); sel('layout', 'maxw', 'حداکثر عرض محتوا', 'none', [['none', 'تمام‌عرض'], ['1600px', '۱۶۰۰'], ['1400px', '۱۴۰۰'], ['1200px', '۱۲۰۰'], ['1000px', '۱۰۰۰']], { css: '--maxw' });
  tog('layout', 'railgroups', 'گروه‌بندی منو با عنوان', true);
  tog('layout', 'topclock', 'ساعت و تاریخ در نوار بالا', true, { da: 'topclock' }); tog('layout', 'topstatus', 'وضعیت اسکن در نوار بالا', true, { da: 'topstatus' }); tog('layout', 'topsub', 'زیرعنوان زیر نام صفحه', true, { da: 'topsub' }); tog('layout', 'topscanbtn', 'دکمهٔ اسکن در نوار بالا', true, { da: 'topscanbtn' });
  sel('layout', 'startpage', 'صفحهٔ شروع', 'dash', [['dash', 'داشبورد'], ['market', 'بازار'], ['work', 'تحلیل ارز'], ['signals', 'سیگنال‌ها'], ['trade', 'معاملات']]);
  // dashboard
  sel('dash', 'wcols', 'تعداد ستون ویجت‌ها', 'auto', [['auto', 'خودکار (بر اساس عرض صفحه)'], ['1', '۱ ستون'], ['2', '۲ ستون'], ['3', '۳ ستون'], ['4', '۴ ستون'], ['5', '۵ ستون'], ['6', '۶ ستون']], { fn: 'wcols' });
  opt('dash', 'dashlist', 'ترتیب، اندازه و نمایش ویجت‌ها', 'widgets', null);
  tog('dash', 'dtape', 'نوار قیمت متحرک بالای داشبورد', true); tog('dash', 'dsince', 'نمایش زمان فعال‌شدن سیگنال در کارت‌ها', true);
  rng('dash', 'opps', 'تعداد فرصت‌های نمایش‌داده‌شده', 6, 2, 12, 1);
  // market
  sel('market', 'mstyle', 'سبک کارت ارزها', 'cards', [['cards', 'کارت'], ['compact', 'فشرده'], ['list', 'فهرست']]); rng('market', 'mminw', 'حداقل عرض کارت (px)', 250, 180, 420, 10, { css: '--mminw', unit: 'px' });
  tog('market', 'mspark', 'نمایش نمودار کوچک', true); tog('market', 'mtf', 'نمایش چهار تایم‌فریم', true); tog('market', 'msince', 'نمایش زمان فعال‌شدن', true);
  sel('market', 'msort', 'مرتب‌سازی پیش‌فرض', 'conf', [['conf', 'اطمینان'], ['chg', 'تغییر ۲۴س'], ['vol', 'حجم'], ['name', 'نام']]);
  // coin page
  rng('work', 'chh', 'ارتفاع نمودار (px)', 460, 280, 900, 10); sel('work', 'wtab', 'تب پیش‌فرض صفحهٔ ارز', 'trend', [['trend', 'روند'], ['signal', 'سیگنال نهایی'], ['forecast', 'پیش‌بینی'], ['patterns', 'الگوها']]);
  sel('work', 'wsplit', 'چیدمان تب سیگنال', 'split', [['split', 'دو ستون'], ['stack', 'تک ستون']]); tog('work', 'wgroups', 'نمایش عنوان گروه‌های تب', true);
  tog('work', 'wstick', 'هدر ارز چسبان باشد', false, { da: 'wstick' }); tog('work', 'wtools', 'نوار ابزار نمودار', true, { da: 'wtools' }); tog('work', 'wlegend', 'راهنمای نمودار', true, { da: 'wlegend' });
  // chart
  sel('chart', 'chs', 'نوع نمودار', 'candles', [['candles', 'شمعی'], ['hollow', 'شمع توخالی'], ['heikin', 'هایکن‌آشی'], ['bars', 'میله‌ای OHLC'], ['line', 'خطی'], ['area', 'ناحیه‌ای']]);
  rng('chart', 'chw', 'پهنای شمع (نسبت)', 0.7, 0.25, 0.95, 0.05); rng('chart', 'chwick', 'ضخامت سایه (px)', 1.2, 0.5, 3, 0.1);
  sel('chart', 'chgrid', 'شبکهٔ نمودار', 'lines', [['lines', 'خط'], ['dots', 'نقطه‌چین'], ['none', 'بدون']]); rng('chart', 'chgridop', 'شفافیت شبکه', 0.055, 0, 0.3, 0.005);
  sel('chart', 'chcross', 'خط‌ نشانگر', 'dash', [['dash', 'خط‌چین'], ['solid', 'ممتد'], ['none', 'بدون']]); rng('chart', 'chvol', 'ارتفاع حجم (٪)', 15, 0, 35, 1);
  tog('chart', 'ema1', 'EMA کوتاه', false); rng('chart', 'ema1p', 'دورهٔ EMA کوتاه', 9, 3, 30, 1);
  tog('chart', 'ema2', 'EMA ۲۱', true); rng('chart', 'ema2p', 'دورهٔ EMA دوم', 21, 8, 60, 1);
  tog('chart', 'ema3', 'EMA ۵۰', true); rng('chart', 'ema3p', 'دورهٔ EMA سوم', 50, 20, 120, 1);
  tog('chart', 'ema4', 'EMA ۲۰۰', false); rng('chart', 'ema4p', 'دورهٔ EMA چهارم', 200, 100, 300, 5);
  tog('chart', 'bb', 'باند بولینگر', false); rng('chart', 'bbp', 'دورهٔ بولینگر', 20, 10, 50, 1); tog('chart', 'vwap', 'VWAP (حرکتی)', false);
  tog('chart', 'fib', 'سطوح فیبوناچی آخرین موج', true); tog('chart', 'autol', 'روندخط‌های خودکار', true); tog('chart', 'pts', 'نقاط لمس الگوهای ساختاری', true);
  tog('chart', 'plabels', 'برچسب الگوهای کندلی', true); tog('chart', 'zlabels', 'برچسب سطوح حمایت/مقاومت', true); tog('chart', 'lastline', 'خط قیمت آخر', true);
  tog('chart', 'wm', 'نام ارز به‌صورت واترمارک', true); tog('chart', 'chhead', 'خط OHLC بالای نمودار', true);
  rng('chart', 'conop', 'شفافیت مخروط پیش‌بینی', 0.22, 0, 0.6, 0.02); sel('chart', 'fcs', 'سبک کندل‌های پیش‌بینی', 'ghost', [['ghost', 'شبح'], ['solid', 'پر'], ['outline', 'توخالی']]);
  sel('chart', 'chside', 'محور قیمت', 'right', [['right', 'راست'], ['left', 'چپ']]); rng('chart', 'chbars', 'تعداد کندل نمایش اولیه', 84, 30, 200, 2);
  rng('chart', 'chmark', 'اندازهٔ نشانگر الگوها', 6, 3, 12, 1); sel('chart', 'chtip', 'راهنمای شناور', 'rich', [['rich', 'کامل'], ['compact', 'فشرده'], ['off', 'خاموش']]);
  rng('chart', 'prec', 'ارقام اعشار قیمت (۰=خودکار)', 0, 0, 8, 1);
  // chart colors
  col('chartc', 'c_up', 'کندل صعودی (خالی = رنگ صعود)', '', { empty: 1 }); col('chartc', 'c_down', 'کندل نزولی (خالی = رنگ نزول)', '', { empty: 1 });
  col('chartc', 'c_bg1', 'زمینهٔ نمودار (بالا)', '#0a1235', { css: '--chart-bg1' }); col('chartc', 'c_bg2', 'زمینهٔ نمودار (پایین)', '#070c24', { css: '--chart-bg2' });
  col('chartc', 'c_grid', 'رنگ شبکه', '#ffffff'); col('chartc', 'c_ema1', 'رنگ EMA کوتاه', '#62b0ff'); col('chartc', 'c_ema2', 'رنگ EMA دوم', '#ffc861'); col('chartc', 'c_ema3', 'رنگ EMA سوم', '#a88bff'); col('chartc', 'c_ema4', 'رنگ EMA چهارم', '#ff8a5c');
  col('chartc', 'c_entry', 'رنگ خط ورود', '#62b0ff'); col('chartc', 'c_sl', 'رنگ حدضرر (خالی = رنگ نزول)', '', { empty: 1 }); col('chartc', 'c_tp', 'رنگ اهداف (خالی = رنگ صعود)', '', { empty: 1 });
  col('chartc', 'c_cone', 'رنگ مخروط پیش‌بینی', '#62b0ff'); col('chartc', 'c_fib', 'رنگ فیبوناچی', '#ffd98a'); col('chartc', 'c_trend', 'رنگ روندخط‌ها', '#ffffff'); col('chartc', 'c_now', 'رنگ خط «اکنون»', '#ffc861'); col('chartc', 'c_vol', 'رنگ حجم (خالی = رنگ کندل)', '', { empty: 1 });
  // data / behaviour
  sel('data', 'tz', 'منطقهٔ زمانی', 'local', [['local', 'ساعت دستگاه'], ['Asia/Tehran', 'تهران'], ['UTC', 'UTC'], ['Europe/London', 'لندن'], ['America/New_York', 'نیویورک'], ['Asia/Dubai', 'دبی'], ['Asia/Tokyo', 'توکیو']], { top: 1 });
  sel('data', 'cal', 'تقویم', 'both', [['both', 'شمسی + میلادی'], ['j', 'شمسی'], ['g', 'میلادی']], { top: 1 }); tog('data', 'h24', 'ساعت ۲۴ ساعته', true, { top: 1 });
  rng('data', 'poll', 'هر چند ثانیه داده تازه شود', 4, 2, 30, 1); tog('data', 'toasts', 'پیام‌های اعلان', true); sel('data', 'toastpos', 'جای پیام‌ها', 'bl', [['bl', 'پایین چپ'], ['br', 'پایین راست'], ['tl', 'بالا چپ'], ['tr', 'بالا راست']]);
  tog('data', 'reltime', 'نمایش زمان نسبی کنار تاریخ‌ها', true); tog('data', 'confirmx', 'تایید قبل از بستن پوزیشن/ریست', true);
  sel('data', 'pfmt', 'قالب قیمت', 'auto', [['auto', 'خودکار'], ['full', 'کامل با جداکننده'], ['compact', 'فشرده K/M']]);

  /* ── presets (each sets many options at once) ── */
  const base = { mode: 'dark', bull: '#35f2c1', bear: '#ff5a86', warn: '#ffc861', info: '#62b0ff', ai: '#a88bff', gold: '#ffd98a', ink: '#e9efff', ink2: '#a9b6e0', mut: '#7482b3', bg0: '#050918', bgA: '#18235a', bgB: '#2a1250', a1: '#2f5bff', a2: '#00e0b0', a3: '#b13cff', c_bg1: '#0a1235', c_bg2: '#070c24' };
  const PR = (name, o) => ({ name, v: Object.assign({}, base, o) });
  P.presets = [
    PR('نئون شب (پیش‌فرض)', {}),
    PR('اقیانوس عمیق', { bull: '#3df5d4', bear: '#ff6b81', info: '#4cc9f0', ai: '#7b8cff', bg0: '#030d1c', bgA: '#0b3a5e', bgB: '#07253f', a1: '#0077b6', a2: '#00f5d4', a3: '#4361ee', c_bg1: '#06203a', c_bg2: '#041424' }),
    PR('شفق قطبی', { bull: '#7dffb3', bear: '#ff7aa8', info: '#7ad7ff', ai: '#c39bff', bg0: '#04111a', bgA: '#0e4d4a', bgB: '#2b1b5a', a1: '#00ffa3', a2: '#00b3ff', a3: '#b36bff', fx: 'anim', c_bg1: '#081f2a', c_bg2: '#051520' }),
    PR('غروب آتشین', { bull: '#ffd166', bear: '#ff4d6d', warn: '#ff9e4a', info: '#ff8fab', ai: '#ffb86b', bg0: '#14060d', bgA: '#5a1530', bgB: '#4d2208', a1: '#ff4d6d', a2: '#ff9e4a', a3: '#c9184a', c_bg1: '#240c16', c_bg2: '#160810' }),
    PR('ماتریکس', { bull: '#39ff14', bear: '#ff2e63', warn: '#e6ff00', info: '#00ffa2', ai: '#7dff9b', ink: '#d6ffd9', ink2: '#8fd69a', mut: '#4f8a58', bg0: '#010a03', bgA: '#06340f', bgB: '#021a08', a1: '#00ff41', a2: '#008f11', a3: '#39ff14', c_bg1: '#04170a', c_bg2: '#020d05', particles: 'matrix', pop: 0.3 }),
    PR('سایبر صورتی', { bull: '#00f5ff', bear: '#ff2bd6', warn: '#ffe600', info: '#7a5cff', ai: '#ff6ec7', bg0: '#0a0414', bgA: '#3a0b5e', bgB: '#5e0b49', a1: '#ff2bd6', a2: '#00f5ff', a3: '#7a5cff', c_bg1: '#150826', c_bg2: '#0d0418' }),
    PR('طلای لوکس', { bull: '#e9c46a', bear: '#e76f51', warn: '#f4a261', info: '#8ecae6', ai: '#cdb4db', gold: '#ffd700', bg0: '#0b0906', bgA: '#3d2f0f', bgB: '#241a08', a1: '#c9a227', a2: '#8a6d1d', a3: '#b5651d', c_bg1: '#17120a', c_bg2: '#0e0b06' }),
    PR('فضای ژرف', { bull: '#5ef2ff', bear: '#ff5d8f', info: '#6c8cff', ai: '#b794ff', bg0: '#02030c', bgA: '#10143a', bgB: '#1c0f3a', a1: '#3a47ff', a2: '#00d4ff', a3: '#8a2be2', particles: 'stars', c_bg1: '#070a22', c_bg2: '#03051a' }),
    PR('جنگل شبانه', { bull: '#8cff9d', bear: '#ff8a80', warn: '#ffe082', info: '#80deea', ai: '#b39ddb', bg0: '#030a06', bgA: '#0e3b22', bgB: '#10261a', a1: '#00c853', a2: '#64dd17', a3: '#00bfa5', particles: 'fireflies', c_bg1: '#06180e', c_bg2: '#030e08' }),
    PR('گرافیت مینیمال', { bull: '#4ade80', bear: '#f87171', warn: '#fbbf24', info: '#60a5fa', ai: '#a78bfa', bg0: '#0e0f12', bgA: '#1b1d24', bgB: '#15161b', a1: '#334155', a2: '#1f2937', a3: '#3f3f46', c_bg1: '#14161b', c_bg2: '#0e1013', particles: 'off', aurora: 'off', fx: 'min' }),
    PR('بنفش سلطنتی', { bull: '#6ef3c5', bear: '#ff6b9d', info: '#8e9bff', ai: '#e0aaff', bg0: '#0a0516', bgA: '#33135e', bgB: '#1d0b3d', a1: '#7b2cbf', a2: '#9d4edd', a3: '#c77dff', c_bg1: '#150a2c', c_bg2: '#0c051b' }),
    PR('گدازه', { bull: '#ffe066', bear: '#ff3b30', warn: '#ff9f1c', info: '#ff7b54', ai: '#ff5d8f', bg0: '#0d0402', bgA: '#4a1103', bgB: '#2b0a02', a1: '#e63946', a2: '#ff7b00', a3: '#ffba08', particles: 'fireflies', c_bg1: '#1c0a05', c_bg2: '#110503' }),
    PR('یخ و برف', { bull: '#8ff3ff', bear: '#ff9ab3', info: '#9ad1ff', ai: '#c4b5fd', bg0: '#04121f', bgA: '#14507a', bgB: '#0b2e4d', a1: '#38bdf8', a2: '#e0f2fe', a3: '#818cf8', particles: 'snow', c_bg1: '#082338', c_bg2: '#05172a' }),
    PR('روشن · آسمانی', { mode: 'light', bull: '#00a37a', bear: '#e0245e', warn: '#d98900', info: '#1d6fdc', ai: '#7b4bdb', gold: '#b8860b', ink: '#132041', ink2: '#41507a', mut: '#7a86a8', bg0: '#eaf1ff', bgA: '#cfe0ff', bgB: '#e3d9ff', a1: '#7aa7ff', a2: '#7de3c8', a3: '#c4a7ff', c_bg1: '#ffffff', c_bg2: '#f1f5ff', c_grid: '#132041', c_trend: '#132041', particles: 'off' }),
    PR('روشن · کاغذی', { mode: 'light', bull: '#0b8f63', bear: '#c81e4c', warn: '#b7791f', info: '#2563eb', ai: '#6d28d9', ink: '#1f2430', ink2: '#4b5565', mut: '#8a93a3', bg0: '#f6f3ec', bgA: '#ebe4d3', bgB: '#e3ddcf', a1: '#e9d8a6', a2: '#b7e4c7', a3: '#ffd6a5', c_bg1: '#fffdf8', c_bg2: '#f4efe4', c_grid: '#1f2430', c_trend: '#1f2430', particles: 'off', aurora: 'off' }),
    PR('روشن · نعنایی', { mode: 'light', bull: '#00997a', bear: '#d6336c', info: '#0d7fb8', ai: '#6741d9', ink: '#0f2a2e', ink2: '#3d5a5f', mut: '#7a9599', bg0: '#e6fbf5', bgA: '#c4f1e4', bgB: '#d9f0ff', a1: '#63e6be', a2: '#74c0fc', a3: '#b2f2bb', c_bg1: '#ffffff', c_bg2: '#effcf8', c_grid: '#0f2a2e', c_trend: '#0f2a2e', particles: 'off' }),
    PR('خون ماه', { bull: '#7cf5c8', bear: '#ff1f4b', warn: '#ff9d2e', info: '#ff6b8a', ai: '#d65db1', bg0: '#0a0206', bgA: '#4d0a1f', bgB: '#2a0612', a1: '#c1121f', a2: '#780000', a3: '#ff4d6d', particles: 'bubbles', c_bg1: '#190712', c_bg2: '#0f040b' })
  ];
  // option group keys of a preset that are not plain options
  const PRESET_FX = { min: { gk: 0.3, neon: 'none', cglow: false, tilt: false }, };

  /* ── value access ── */
  const val = id => { const o = P.byId[id], v = (S.cfg.p || {})[id]; return v === undefined ? o.def : v; };
  T.p = val; T.byIdReady = true;
  P.set = function (id, v, quiet) { S.cfg.p = S.cfg.p || {}; S.cfg.p[id] = v; if (!quiet) { P.apply(); T.saveCfg(); } };
  P.reset = function () { S.cfg.p = {}; S.cfg.dash = null; P.apply(); T.saveCfg(); };
  P.preset = function (i) {
    const pr = P.presets[i]; if (!pr) return; const keep = {}; ['tz', 'cal', 'h24', 'poll', 'startpage'].forEach(k => { if (S.cfg.p && S.cfg.p[k] !== undefined) keep[k] = S.cfg.p[k]; });
    S.cfg.p = Object.assign({}, pr.v, { preset: i }, keep); if (pr.v.fx === 'min') Object.assign(S.cfg.p, PRESET_FX.min); delete S.cfg.p.fx;
    P.apply(); T.saveCfg();
  };
  const FONTS = { vaz: '"Vazirmatn","IRANSans","Segoe UI",Tahoma,system-ui,sans-serif', sys: 'system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif', tahoma: 'Tahoma,"Segoe UI",sans-serif', segoe: '"Segoe UI",Tahoma,sans-serif', serif: 'Georgia,"Times New Roman","Noto Naskh Arabic",serif', mono: 'ui-monospace,Menlo,Consolas,"Vazirmatn",monospace', rounded: '"Trebuchet MS","Vazirmatn",Tahoma,sans-serif', arial: 'Arial,Tahoma,sans-serif' };
  const MONOS = { mono: 'ui-monospace,"SF Mono",Menlo,Consolas,monospace', same: 'inherit', tabular: 'var(--f)' };
  const mixHex = (a, b, t) => { const x = T.rgb(a), y = T.rgb(b); return '#' + x.map((v, i) => Math.round(v * (1 - t) + y[i] * t).toString(16).padStart(2, '0')).join(''); };

  /* ── apply everything to the document ── */
  P.apply = function () {
    const R = document.documentElement, st = R.style, light = val('mode') === 'light';
    P.O.forEach(o => {
      const v = val(o.id);
      if (o.css) st.setProperty(o.css, v + (o.unit || ''));
      if (o.da) R.setAttribute('data-' + o.da, v === true ? 'on' : v === false ? 'off' : String(v));
    });
    const dk = { compact: .65, normal: 1, spacious: 1.4 }[val('density')] || 1;
    st.setProperty('--gap', Math.round(val('gap') * dk) + 'px'); st.setProperty('--pad', Math.round(val('pad') * dk) + 'px'); st.setProperty('--pad-view', Math.round(val('padv') * Math.min(dk, 1.2)) + 'px');
    ['scan', 'grain', 'vig', 'hud', 'tilt', 'hoverlift'].forEach(k => R.setAttribute('data-' + k, val(k) ? 'on' : 'off'));
    R.setAttribute('data-glass', val('glassx')); R.setAttribute('data-light', light ? '1' : '0'); R.setAttribute('data-density', val('density'));
    st.setProperty('--tint', light ? '20 32 74' : '255 255 255'); st.setProperty('--shade', light ? '255 255 255' : '11 18 48');
    ['bull', 'bear'].forEach(k => st.setProperty('--' + k + '2', mixHex(val(k), '#000000', 0.32)));
    // colors shared with canvas / svg code (mutated in place so the chart sees them)
    Object.assign(T.col, { bull: val('bull'), bear: val('bear'), warn: val('warn'), info: val('info'), ai: val('ai'), gold: val('gold'), mut: val('mut'), ink: val('ink'), ink2: val('ink2'), bg: val('c_bg1'), grid: val('c_grid') });
    T.S.fx = { gk: +val('gk') };
    st.setProperty('--f', FONTS[val('font')] || FONTS.vaz); st.setProperty('--mono', MONOS[val('monof')] || MONOS.mono);
    const filt = []; if (+val('hue')) filt.push(`hue-rotate(${val('hue')}deg)`); if (+val('sat') !== 100) filt.push(`saturate(${val('sat')}%)`); if (+val('bri') !== 100) filt.push(`brightness(${val('bri')}%)`); if (+val('con') !== 100) filt.push(`contrast(${val('con')}%)`);
    const sh = document.getElementById('shell'); if (sh) sh.style.filter = filt.join(' ');
    R.style.zoom = +val('zoom') === 100 ? '' : (+val('zoom') / 100);
    // background image + dim
    let img = ''; try { img = localStorage.getItem('titan_bgimg') || ''; } catch (e) { /* storage blocked */ }
    st.setProperty('--bgimg', img && val('bgmode') === 'image' ? `linear-gradient(rgba(0,0,0,${val('bgdim')}),rgba(0,0,0,${val('bgdim')})),url(${img})` : 'none');
    // toast position
    const tp = val('toastpos'), tz = document.getElementById('toasts');
    if (tz) { tz.style.cssText = `position:fixed;z-index:99;display:flex;flex-direction:column;gap:8px;${tp[0] === 'b' ? 'bottom:22px' : 'top:22px'};${tp[1] === 'l' ? 'left:22px' : 'right:22px'}`; }
    // shared option object read by other modules
    T.S.cfg.tz = val('tz'); T.S.cfg.cal = val('cal'); T.S.cfg.h24 = !!val('h24');
    ['ema', 'vol', 'fc', 'cone', 'lv', 'pat', 'zones', 'struct'].forEach(k => { if (S.cfg.layers[k] === undefined) S.cfg.layers[k] = true; });
    if (P.fx) P.fx.refresh();
    if (T.drawNav) T.drawNav();
    if (T.V.work && T.V.work.chart && T.V.work.chart.d) { T.V.work.chart.applyOpts(); T.V.work.chart.draw(); }
    const ch = document.getElementById('chartHost'); if (ch && ch.parentElement) ch.parentElement.classList.toggle('chartglow', !!val('chglow'));
  };

  /* ── effects engine ── */
  const fx = P.fx = {
    cv: null, ctx: null, parts: [], raf: 0, kind: 'off', glow: null, mx: 0, my: 0,
    init() {
      if (this.cv) return;
      this.cv = document.createElement('canvas'); this.cv.id = 'fxbg'; document.body.insertBefore(this.cv, document.body.firstChild); this.ctx = this.cv.getContext('2d');
      this.glow = document.createElement('div'); this.glow.id = 'cursorglow'; this.glow.style.opacity = 0; document.body.appendChild(this.glow);
      addEventListener('resize', () => this.size()); this.size();
      document.addEventListener('pointermove', e => {
        this.mx = e.clientX; this.my = e.clientY;
        if (val('cglow')) { this.glow.style.left = e.clientX + 'px'; this.glow.style.top = e.clientY + 'px'; this.glow.style.opacity = 1; }
        if (val('tilt')) { const t = e.target.closest && e.target.closest('.coin,.kpi'); if (t) { const r = t.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; t.style.transform = `perspective(700px) rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 9).toFixed(2)}deg) translateZ(0)`; } }
      }, { passive: true });
      document.addEventListener('pointerout', e => { const t = e.target.closest && e.target.closest('.coin,.kpi'); if (t) t.style.transform = ''; }, { passive: true });
      document.addEventListener('pointerleave', () => { this.glow.style.opacity = 0; });
      document.addEventListener('pointerdown', e => {
        if (!val('ripple')) return; const t = e.target.closest && e.target.closest('.btn,.nav,.coin,.seg button,.tabs button,.hc,.tfc,.preset,.chip');
        if (!t) return; const d = document.createElement('span'); d.className = 'ripple'; d.style.cssText = `position:fixed;left:${e.clientX - 40}px;top:${e.clientY - 40}px;width:80px;height:80px;z-index:70`; document.body.appendChild(d); setTimeout(() => d.remove(), 650);
      }, { passive: true });
    },
    size() { if (this.cv) { this.cv.width = innerWidth; this.cv.height = innerHeight; this.make(); } },
    color(i) { const c = val('pcolor'); return c === 'rainbow' ? `hsl(${(i * 37) % 360} 90% 65%)` : T.col[c] || T.col.bull; },
    make() {
      const n = +val('pcount'), w = this.cv.width, h = this.cv.height, k = val('particles'); this.kind = k; this.parts = [];
      if (k === 'off') return;
      const cnt = k === 'matrix' ? Math.floor(w / 18) : n;
      for (let i = 0; i < cnt; i++) this.parts.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5), vy: (Math.random() - .5), r: .5 + Math.random(), p: Math.random() * 6.28, c: i, y0: Math.random() * h });
    },
    refresh() {
      this.init(); if (val('particles') !== this.kind || this.parts.length !== (val('particles') === 'matrix' ? Math.floor(this.cv.width / 18) : (val('particles') === 'off' ? 0 : +val('pcount')))) this.make();
      this.glow.style.display = val('cglow') ? '' : 'none';
      cancelAnimationFrame(this.raf); if (this.kind !== 'off' && !matchMedia('(prefers-reduced-motion: reduce)').matches) this.loop(); else this.ctx.clearRect(0, 0, this.cv.width, this.cv.height);
    },
    loop() {
      const c = this.ctx, w = this.cv.width, h = this.cv.height, k = this.kind, sp = +val('pspeed'), sz = +val('psize'), op = +val('pop');
      const step = () => {
        if (document.hidden) { this.raf = requestAnimationFrame(step); return; }
        if (k === 'matrix') { c.fillStyle = 'rgba(0,0,0,.08)'; c.globalCompositeOperation = 'destination-out'; c.fillRect(0, 0, w, h); c.globalCompositeOperation = 'source-over'; } else c.clearRect(0, 0, w, h);
        c.globalAlpha = op; const t = performance.now() / 1000;
        for (let i = 0; i < this.parts.length; i++) {
          const p = this.parts[i]; c.fillStyle = c.strokeStyle = this.color(p.c);
          if (k === 'stars') { c.globalAlpha = op * (.4 + .6 * Math.abs(Math.sin(t * sp + p.p))); c.beginPath(); c.arc(p.x, p.y, p.r * sz, 0, 7); c.fill(); }
          else if (k === 'matrix') { p.y += (2 + p.r * 3) * sp; if (p.y > h) p.y = -20; c.font = '14px monospace'; c.fillText(String.fromCharCode(0x30A0 + Math.random() * 60), p.x, p.y); }
          else if (k === 'snow') { p.y += (.5 + p.r) * sp; p.x += Math.sin(t + p.p) * .4 * sp; if (p.y > h) { p.y = -5; p.x = Math.random() * w; } c.beginPath(); c.arc(p.x, p.y, p.r * sz * 1.4, 0, 7); c.fill(); }
          else if (k === 'bubbles') { p.y -= (.3 + p.r * .6) * sp; p.x += Math.sin(t + p.p) * .3; if (p.y < -20) { p.y = h + 20; p.x = Math.random() * w; } c.beginPath(); c.arc(p.x, p.y, p.r * sz * 4, 0, 7); c.lineWidth = 1; c.stroke(); }
          else if (k === 'fireflies') { p.x += Math.sin(t * .6 + p.p) * .5 * sp; p.y += Math.cos(t * .5 + p.p * 2) * .4 * sp; c.globalAlpha = op * (.3 + .7 * Math.abs(Math.sin(t * 1.2 + p.p))); c.shadowColor = c.fillStyle; c.shadowBlur = 12; c.beginPath(); c.arc(p.x, p.y, p.r * sz * 1.3, 0, 7); c.fill(); c.shadowBlur = 0; }
          else { p.x += p.vx * sp * .6; p.y += p.vy * sp * .6; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1; c.beginPath(); c.arc(p.x, p.y, p.r * sz, 0, 7); c.fill(); }
        }
        if (k === 'network') {
          c.lineWidth = 1; const R2 = 130 * 130;
          for (let i = 0; i < this.parts.length; i++) for (let j = i + 1; j < this.parts.length; j++) {
            const a = this.parts[i], b = this.parts[j], dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy;
            if (d2 < R2) { c.globalAlpha = op * (1 - d2 / R2) * .6; c.strokeStyle = this.color(a.c); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke(); }
          }
          const mx = this.mx, my = this.my; this.parts.forEach(a => { const dx = a.x - mx, dy = a.y - my; if (dx * dx + dy * dy < 160 * 160) { c.globalAlpha = op * .5; c.strokeStyle = this.color(a.c); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(mx, my); c.stroke(); } });
        }
        c.globalAlpha = 1; this.raf = requestAnimationFrame(step);
      };
      step();
    },
    /** called after every view render: count-up numbers */
    after(root) {
      if (!val('countup') || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      T.$$('.kpi b, .xl.num', root || document).forEach(el => {
        if (el.dataset.cu) return; el.dataset.cu = 1; const m = el.textContent.trim().match(/^([^\d−\-+]*)([−\-+]?)([\d,]*\.?\d+)(.*)$/); if (!m) return;
        const target = parseFloat(m[3].replace(/,/g, '')); if (!isFinite(target) || target === 0) return; const dec = (m[3].split('.')[1] || '').length, pre = m[1] + m[2], suf = m[4], t0 = performance.now();
        const run = now => { const k = Math.min(1, (now - t0) / 700), e = 1 - Math.pow(1 - k, 3), v = target * e; el.textContent = pre + (dec ? v.toFixed(dec) : Math.round(v).toLocaleString('en-US')) + suf; if (k < 1) requestAnimationFrame(run); else el.textContent = pre + (dec ? target.toFixed(dec) : Math.round(target).toLocaleString('en-US')) + suf; };
        requestAnimationFrame(run);
      });
    },
    beep(up) { try { const a = new (W.AudioContext || W.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain(); o.type = 'sine'; o.frequency.value = up ? 880 : 520; g.gain.value = .06; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + .18); } catch (e) { /* no audio */ } }
  };

  /* ── dashboard widget layout (order / visibility / size / height) ── */
  P.dashDefault = () => [['tape', 4, 0], ['mood', 1, 1], ['clock', 1, 1], ['health', 1, 1], ['best', 1, 1], ['radar', 2, 1], ['autotrade', 2, 1], ['opps', 4, 1], ['trends', 2, 1], ['heat', 2, 1], ['equity', 2, 1], ['lessons', 2, 1], ['breadth', 2, 1], ['gainers', 1, 1], ['losers', 1, 1], ['log', 4, 1]].map(([id, span, on]) => ({ id, span, on: !!on, h: 0 }));
  P.dashLayout = function () {
    const def = P.dashDefault(), cur = S.cfg.dash;
    if (!Array.isArray(cur)) return def;
    const ids = new Set(cur.map(x => x.id)), out = cur.filter(x => def.some(d => d.id === x.id)); def.forEach(d => { if (!ids.has(d.id)) out.push(Object.assign({}, d, { on: false })); }); return out;
  };

  /* ═════════ STUDIO VIEW ═════════ */
  const fmtVal = (o, v) => o.type === 'range' ? (+v).toFixed(o.step < 0.01 ? 3 : o.step < 1 ? 2 : 0).replace(/\.?0+$/, '') + (o.unit && o.unit !== '%' && o.unit !== 'px' ? '' : '') : v;
  function optRow(o) {
    const v = val(o.id); let ctl = '';
    if (o.type === 'color') ctl = `<div class="row" style="gap:6px"><input type="color" data-o="${o.id}" value="${esc(v || '#888888')}">${o.empty ? `<button class="btn sm" data-clr="${o.id}">پیش‌فرض</button>` : ''}</div>`;
    else if (o.type === 'range') ctl = `<div class="row" style="gap:8px"><input type="range" data-o="${o.id}" min="${o.min}" max="${o.max}" step="${o.step}" value="${v}"><span class="rv" data-rv="${o.id}">${fmtVal(o, v)}</span></div>`;
    else if (o.type === 'select') ctl = `<select class="inp" data-o="${o.id}">${o.opts.map(([k, n]) => `<option value="${esc(k)}" ${String(v) === String(k) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
    else if (o.type === 'toggle') ctl = `<button type="button" class="sw ${v ? 'on' : ''}" data-tg="${o.id}" role="switch" aria-checked="${v ? 'true' : 'false'}" aria-label="${esc(o.label)}"></button>`;
    else if (o.type === 'file') ctl = `<div class="row" style="gap:6px"><input type="file" accept="image/*" data-file="${o.id}" class="inp" style="max-width:190px"><button class="btn sm" data-clrimg="1">حذف</button></div>`;
    else if (o.type === 'widgets') return wlist();
    return `<div class="opt"><label>${esc(o.label)}</label>${ctl}</div>`;
  }
  const WN = { tape: 'نوار قیمت متحرک', mood: 'حال‌وهوای بازار', clock: 'ساعت و تازگی داده', health: 'سلامت سیستم', best: 'بهترین فرصت', radar: 'رادار بازار (نئونی)', autotrade: 'معامله خودکار و نتایج', opps: 'فرصت‌های فعال', trends: 'روند ارزها', heat: 'ماتریس ارز × تایم‌فریم', equity: 'منحنی سرمایه نئونی', lessons: 'درس‌های اشتباهات', breadth: 'پهنای بازار', gainers: 'بیشترین رشد', losers: 'بیشترین افت', log: 'آخرین سیگنال‌ها' };
  P.WN = WN;
  function wlist() {
    return `<div class="wl" id="wl">${P.dashLayout().map((w, i) => `<div class="wi" draggable="true" data-i="${i}"><span class="wh-grip mut" aria-hidden="true">⠿</span><b class="wn">${esc(WN[w.id] || w.id)}</b>
      <button type="button" class="sw ${w.on ? 'on' : ''}" data-won="${i}" role="switch" aria-checked="${w.on ? 'true' : 'false'}" aria-label="نمایش ${esc(WN[w.id] || w.id)}"></button>
      <select class="inp wsp" data-wspan="${i}" aria-label="اندازه">${[1, 2, 3, 4, 5, 6].map(n => `<option value="${n}" ${w.span === n ? 'selected' : ''}>${T.fa(n)} ستون</option>`).join('')}</select>
      <span class="wa"><button class="btn sm" data-wup="${i}" aria-label="بالا">↑</button><button class="btn sm" data-wdn="${i}" aria-label="پایین">↓</button></span></div>`).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn sm" id="wl-reset">بازگشت به چیدمان پیش‌فرض</button></div>`;
  }
  V.studio = {
    cat: 'theme', q: '',
    mount() {
      const v = T.$('#view');
      v.innerHTML = `<div class="studio"><div class="glass cats" id="st-cats"></div><div id="st-body"></div></div>`;
      this.cats(); this.body();
      T.on(v, '#st-cats button', 'click', (e, b) => { this.cat = b.dataset.c; this.cats(); this.body(); T.$('#st-body').scrollIntoView && window.innerWidth < 900 && T.$('#st-body').scrollIntoView({ block: 'start' }); });
    },
    cats() {
      const n = c => P.O.filter(o => o.cat === c).length;
      T.$('#st-cats').innerHTML = `<div class="cats-head"><b>${T.ic('spark')}استودیو شخصی‌سازی</b><span class="xs mut">${T.fa(P.O.length)} گزینه · ${T.fa(P.presets.length)} تم · ذخیرهٔ خودکار</span></div><div class="cats-list" role="tablist">`
        + P.CATS.map(([k, n_, ic]) => `<button type="button" role="tab" data-c="${k}" class="${this.cat === k ? 'on' : ''}"><span class="ci">${T.ic(ic)}</span><span class="cn">${n_}</span>${['theme', 'backup'].includes(k) ? '' : `<span class="cc">${T.fa(n(k))}</span>`}</button>`).join('') + '</div>';
    },
    body() {
      const b = T.$('#st-body'), c = this.cat; let h = '';
      if (c === 'theme') {
        h = T.panel('تم‌های آماده', 'spark', `<div class="presets">${P.presets.map((p, i) => `<div class="preset ${S.cfg.p && S.cfg.p.preset === i ? 'on' : ''}" data-pr="${i}"><div class="sw3">${['bg0', 'bull', 'bear', 'info', 'ai'].map(k => `<i style="background:${p.v[k]}"></i>`).join('')}</div>${esc(p.name)}</div>`).join('')}</div>`, { sub: 'با یک کلیک همهٔ رنگ و پس‌زمینه عوض می‌شود؛ بعد می‌توانید ریزتنظیم کنید' })
          + T.panel('ابزارهای سریع', 'bolt', `<div class="row wrap" style="gap:8px"><button class="btn" id="st-rand">${T.ic('refresh')}پالت تصادفی هماهنگ</button><button class="btn" id="st-neonmax">${T.ic('bolt')}نئون حداکثر</button><button class="btn" id="st-calm">${T.ic('shield')}حالت آرام (بدون افکت)</button><button class="btn" id="st-light">${T.ic('eye')}روشن/تیره</button></div>`, { cls: '' });
      } else if (c === 'backup') {
        h = T.panel('پشتیبان و بازنشانی', 'db', `<div class="col" style="gap:10px"><div class="row wrap"><button class="btn pri" id="st-exp">${T.ic('db')}خروجی تنظیمات (JSON)</button><label class="btn">${T.ic('plus')}ورودی تنظیمات<input type="file" id="st-imp" accept=".json" hidden></label><button class="btn dng" id="st-reset">${T.ic('trash')}بازنشانی همهٔ شخصی‌سازی‌ها</button></div>
          <textarea class="inp" id="st-json" rows="10" style="width:100%;font-family:var(--mono);font-size:11px" readonly>${esc(JSON.stringify(S.cfg.p || {}, null, 1))}</textarea><div class="xs mut">تنظیمات در پوشهٔ XXX/settings.json (بخش ui) روی سرور ذخیره می‌شود؛ تصویر پس‌زمینه فقط در مرورگر.</div></div>`);
      } else {
        const rows = P.O.filter(o => o.cat === c).map(optRow).join('');
        h = T.panel(P.CATS.find(x => x[0] === c)[1], P.CATS.find(x => x[0] === c)[2], `<div class="opts">${rows}</div>`, { sub: T.fa(P.O.filter(o => o.cat === c).length) + ' گزینه' });
      }
      b.innerHTML = h; this.bind(b);
    },
    bind(b) {
      const self = this;
      T.on(b, '[data-pr]', 'click', (e, t) => { P.preset(+t.dataset.pr); self.body(); });
      b.querySelectorAll('[data-o]').forEach(el => {
        const o = P.byId[el.dataset.o], f = () => { let v = el.value; if (o.type === 'range') { v = +v; const rv = b.querySelector(`[data-rv="${o.id}"]`); if (rv) rv.textContent = fmtVal(o, v); } P.set(o.id, v); if (o.type === 'select' && ['mode', 'nav', 'cards'].includes(o.id)) { /* structural */ } };
        el.addEventListener(o.type === 'range' || o.type === 'color' ? 'input' : 'change', f);
      });
      T.on(b, '[data-tg]', 'click', (e, t) => { const o = P.byId[t.dataset.tg]; const v = !val(o.id); t.classList.toggle('on', v); t.setAttribute('aria-checked', v); P.set(o.id, v); if (o.id === 'snd' && v) fx.beep(true); });
      T.on(b, '[data-clr]', 'click', (e, t) => { P.set(t.dataset.clr, ''); self.body(); });
      const fi = b.querySelector('[data-file]'); if (fi) fi.addEventListener('change', () => { const f = fi.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 1600 / im.width), cv = document.createElement('canvas'); cv.width = im.width * k; cv.height = im.height * k; cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); try { localStorage.setItem('titan_bgimg', cv.toDataURL('image/jpeg', .7)); P.set('bgmode', 'image'); T.toast('تصویر پس‌زمینه اعمال شد', 'ok'); self.body(); } catch (e) { T.toast('تصویر برای ذخیره‌سازی مرورگر بزرگ است', 'err'); } }; im.src = r.result; }; r.readAsDataURL(f); });
      T.on(b, '[data-clrimg]', 'click', () => { try { localStorage.removeItem('titan_bgimg'); } catch (e) { /* */ } P.set('bgmode', 'aurora'); self.body(); });
      // widget list
      const wl = b.querySelector('#wl'); if (wl) {
        const L = P.dashLayout(), save = () => { S.cfg.dash = L; T.saveCfg(); };
        T.on(b, '[data-wup]', 'click', (e, t) => { const i = +t.dataset.wup; if (i > 0) { [L[i - 1], L[i]] = [L[i], L[i - 1]]; save(); self.body(); } });
        T.on(b, '[data-wdn]', 'click', (e, t) => { const i = +t.dataset.wdn; if (i < L.length - 1) { [L[i + 1], L[i]] = [L[i], L[i + 1]]; save(); self.body(); } });
        T.on(b, '[data-won]', 'click', (e, t) => { const i = +t.dataset.won; L[i].on = !L[i].on; t.classList.toggle('on', L[i].on); t.setAttribute('aria-checked', L[i].on); save(); });
        b.querySelectorAll('[data-wspan]').forEach(s => s.addEventListener('change', () => { L[+s.dataset.wspan].span = +s.value; save(); }));
        const rs = b.querySelector('#wl-reset'); rs && rs.addEventListener('click', () => { S.cfg.dash = null; T.saveCfg(); self.body(); });
        let drag = -1; wl.querySelectorAll('.wi').forEach(el => { el.addEventListener('dragstart', () => { drag = +el.dataset.i; el.classList.add('drag'); }); el.addEventListener('dragend', () => el.classList.remove('drag')); el.addEventListener('dragover', e => { e.preventDefault(); el.classList.add('over'); }); el.addEventListener('dragleave', () => el.classList.remove('over')); el.addEventListener('drop', e => { e.preventDefault(); const to = +el.dataset.i; if (drag > -1 && drag !== to) { const [m] = L.splice(drag, 1); L.splice(to, 0, m); save(); self.body(); } }); });
      }
      const on = (id, fn) => { const el = b.querySelector('#' + id); el && el.addEventListener('click', fn); };
      on('st-rand', () => { const h = Math.random() * 360, hs = (o, s, l) => `hsl(${(h + o) % 360} ${s}% ${l}%)`, hex = c => { const cv = document.createElement('canvas').getContext('2d'); cv.fillStyle = c; return cv.fillStyle; };
        Object.assign(S.cfg.p = S.cfg.p || {}, { bull: hex(hs(0, 95, 62)), bear: hex(hs(180, 95, 66)), info: hex(hs(60, 90, 64)), ai: hex(hs(240, 85, 72)), warn: hex(hs(120, 90, 66)), bg0: hex(hs(0, 60, 5)), bgA: hex(hs(20, 55, 20)), bgB: hex(hs(200, 55, 15)), a1: hex(hs(0, 90, 55)), a2: hex(hs(120, 90, 50)), a3: hex(hs(240, 90, 60)), c_bg1: hex(hs(0, 50, 9)), c_bg2: hex(hs(0, 50, 6)), mode: 'dark' }); P.apply(); T.saveCfg(); self.body(); });
      on('st-neonmax', () => { Object.assign(S.cfg.p = S.cfg.p || {}, { gk: 2.2, neon: 'rotate', cards: 'neon', particles: 'network', cglow: true, hud: true, scan: false, title: 'glow', btn: 'neon', tabs: 'neon', aurora: 'anim' }); P.apply(); T.saveCfg(); self.body(); });
      on('st-calm', () => { Object.assign(S.cfg.p = S.cfg.p || {}, { gk: .4, neon: 'none', cards: 'glass', particles: 'off', cglow: false, tilt: false, hud: false, scan: false, grain: false, aurora: 'on', anim: 'fade', countup: false, ripple: false }); P.apply(); T.saveCfg(); self.body(); });
      on('st-light', () => { P.set('mode', val('mode') === 'light' ? 'dark' : 'light'); self.body(); });
      on('st-exp', () => { const blob = new Blob([JSON.stringify({ p: S.cfg.p, dash: S.cfg.dash }, null, 1)], { type: 'application/json' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'titan-studio.json'; a.click(); });
      const imp = b.querySelector('#st-imp'); imp && imp.addEventListener('change', () => { const f = imp.files[0]; if (!f) return; f.text().then(t => { try { const j = JSON.parse(t); S.cfg.p = j.p || j; S.cfg.dash = j.dash || null; P.apply(); T.saveCfg(); T.toast('تنظیمات وارد شد', 'ok'); self.body(); } catch (e) { T.toast('فایل نامعتبر است', 'err'); } }); });
      on('st-reset', () => { if (!val('confirmx') || confirm('همهٔ شخصی‌سازی‌ها پاک شود؟')) { P.reset(); self.body(); T.toast('بازنشانی شد', 'ok'); } });
    },
    tick() { }
  };
})(window);
