/* TITAN · core utilities: state, API, time (Jalali/Gregorian + time-zone), numbers, icons, small graphic builders. */
(function (W) {
  'use strict';
  const T = W.TT = {};
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  T.$ = $; T.$$ = $$;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  T.esc = esc;

  /* ── state + persisted display preferences (server-side: XXX/settings.json → ui) ── */
  const DEF = { tz: 'local', cal: 'both', h24: true, layers: { ema: true, vol: true, fc: true, cone: true, lv: true, pat: true, zones: true, struct: true }, last: { sym: 'BTCUSDT', tf: '1h' }, p: {}, dash: null };
  T.S = { fx: { gk: 1 }, cfg: JSON.parse(JSON.stringify(DEF)), status: null, matrix: null, market: null, coin: null, route: 'dash', sub: 'signal', sym: 'BTCUSDT', tf: '1h', now: Date.now(), skew: 0 };
  let saveT = 0;
  T.saveCfg = function () {
    clearTimeout(saveT);
    saveT = setTimeout(() => T.post('/api/settings', { ui: T.S.cfg }).catch(() => {}), 500);
  };

  /* ── API ── */
  T.api = async function (path, opt) {
    const r = await fetch(path, Object.assign({ headers: { 'Content-Type': 'application/json' } }, opt || {}));
    let j = null;
    try { j = await r.json(); } catch (e) { /* non-json */ }
    if (!r.ok && !(j && j.error)) throw new Error('HTTP ' + r.status);
    return j;
  };
  T.post = (p, b) => T.api(p, { method: 'POST', body: JSON.stringify(b || {}) });
  T.del = p => T.api(p, { method: 'DELETE' });

  /* ── time ── (every date/time in the UI goes through here: calendar + zone are user settings) */
  const _dtf = {};
  function dtf(kind, opts) {
    const tz = T.S.cfg.tz === 'local' ? undefined : T.S.cfg.tz;
    const k = kind + '|' + tz + '|' + JSON.stringify(opts);
    if (!_dtf[k]) {
      const loc = kind === 'j' ? 'fa-IR-u-ca-persian-nu-latn' : 'en-GB-u-nu-latn';
      try { _dtf[k] = new Intl.DateTimeFormat(loc, Object.assign({ timeZone: tz }, opts)); }
      catch (e) { _dtf[k] = new Intl.DateTimeFormat(loc, opts); }
    }
    return _dtf[k];
  }
  const p2 = n => String(n).padStart(2, '0');
  function parts(ts, kind, opts) {
    const o = {};
    dtf(kind, opts).formatToParts(new Date(ts)).forEach(p => { o[p.type] = p.value; });
    return o;
  }
  T.time = function (ts, sec) {
    if (!ts) return '—';
    const o = parts(ts, 'g', { hour: '2-digit', minute: '2-digit', second: sec ? '2-digit' : undefined, hourCycle: T.S.cfg.h24 ? 'h23' : 'h12' });
    return `${o.hour}:${o.minute}${sec ? ':' + o.second : ''}${o.dayPeriod ? ' ' + o.dayPeriod : ''}`;
  };
  T.jdate = function (ts, long) {
    if (!ts) return '—';
    const o = parts(ts, 'j', { year: 'numeric', month: long ? 'long' : 'short', day: 'numeric' });
    return `${o.day} ${o.month}${long ? ' ' + o.year : ''}`;
  };
  T.jnum = function (ts) {
    const o = parts(ts, 'j', { year: 'numeric', month: '2-digit', day: '2-digit' });
    return `${o.year}/${o.month}/${o.day}`;
  };
  T.gdate = function (ts, long) {
    if (!ts) return '—';
    const o = parts(ts, 'g', { year: 'numeric', month: 'short', day: 'numeric' });
    return '\u2066' + (long ? `${o.day} ${o.month} ${o.year}` : `${o.day} ${o.month}`) + '\u2069';
  };
  T.wday = ts => parts(ts, 'j', { weekday: 'long' }).weekday || '';
  /** compact date for a point in time, following the user's calendar choice */
  T.date = function (ts, long) {
    const c = T.S.cfg.cal;
    const body = c === 'g' ? T.gdate(ts, long) : c === 'j' ? T.jdate(ts, long) : T.jdate(ts, long) + (long ? ' · ' + T.gdate(ts, true) : '');
    return '\u2067' + body + '\u2069';           // RTL isolate: «۱۷ آبان» reads correctly inside any parent direction
  };
  T.dt = ts => ts ? `${T.date(ts)} ${T.time(ts)}` : '—';
  T.dtFull = ts => ts ? `${T.wday(ts)} ${T.date(ts, true)} ـ ${T.time(ts)}` : '—';
  T.zoneName = () => T.S.cfg.tz === 'local' ? (Intl.DateTimeFormat().resolvedOptions().timeZone || 'local') : T.S.cfg.tz;
  T.nowMs = () => Date.now() + T.S.skew;
  const TFN = { '15m': '۱۵ دقیقه', '1h': '۱ ساعت', '4h': '۴ ساعت', '1d': '۱ روز', '1m': '۱ دقیقه', '5m': '۵ دقیقه' };
  T.tfName = t => TFN[t] || t;
  T.tfMs = t => ({ '1m': 6e4, '5m': 3e5, '15m': 9e5, '1h': 36e5, '4h': 144e5, '1d': 864e5 }[t] || 36e5);
  T.fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
  /** human distance in time: «۲ ساعت و ۱۵ دقیقه دیگر» / «۳ ساعت پیش» */
  T.rel = function (ts, now) {
    now = now || T.nowMs();
    const d = ts - now, a = Math.abs(d), s = Math.round(a / 1000);
    let txt;
    if (s < 45) txt = 'چند ثانیه';
    else if (s < 3600) txt = T.fa(Math.round(s / 60)) + ' دقیقه';
    else if (s < 86400) { const h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60); txt = T.fa(h) + ' ساعت' + (m && h < 6 ? ' و ' + T.fa(m) + ' دقیقه' : ''); }
    else { const dd = Math.floor(s / 86400), h = Math.round((s % 86400) / 3600); txt = T.fa(dd) + ' روز' + (h && dd < 4 ? ' و ' + T.fa(h) + ' ساعت' : ''); }
    return d >= 0 ? txt + ' دیگر' : txt + ' پیش';
  };
  T.dur = function (ms) {
    const s = Math.round(ms / 1000);
    if (s < 3600) return T.fa(Math.round(s / 60)) + ' دقیقه';
    if (s < 86400) return T.fa(+(s / 3600).toFixed(1)) + ' ساعت';
    return T.fa(+(s / 86400).toFixed(1)) + ' روز';
  };
  /** a time cell: absolute date+time and relative distance */
  T.tstamp = (ts, rel) => ts ? `<span class="t" data-tip="${esc(T.dtFull(ts))}">${esc(T.dt(ts))}</span>${rel ? ` <span class="mut xs">(${esc(T.rel(ts))})</span>` : ''}` : '<span class="mut">—</span>';

  /* ── numbers ── */
  T.price = function (v) {
    if (v == null || !isFinite(v)) return '—';
    const a = Math.abs(v), pp = T.p ? (+T.p('prec') || 0) : 0, pf = T.p ? T.p('pfmt') : 'auto';
    if (pf === 'compact' && a >= 1000) return T.big(v);
    if (pp > 0) return Number(v).toLocaleString('en-US', { minimumFractionDigits: pp, maximumFractionDigits: pp, useGrouping: pf !== 'plain' });
    const d = a >= 1000 ? 2 : a >= 10 ? 3 : a >= 1 ? 4 : a >= 0.1 ? 5 : a >= 0.01 ? 6 : a >= 0.0001 ? 7 : 9;
    return Number(v).toLocaleString('en-US', { minimumFractionDigits: Math.min(d, a >= 1000 ? 2 : 2), maximumFractionDigits: d });
  };
  T.pct = (v, d, sign) => (v == null || !isFinite(v)) ? '—' : '\u2066' + (sign !== false && v > 0 ? '+' : '') + Number(v).toFixed(d == null ? 2 : d) + '%\u2069';
  T.n = (v, d) => (v == null || !isFinite(v)) ? '—' : Number(v).toFixed(d == null ? 1 : d);
  T.big = function (v) {
    if (v == null || !isFinite(v)) return '—';
    const a = Math.abs(v);
    return a >= 1e9 ? (v / 1e9).toFixed(2) + 'B' : a >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : a >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : v.toFixed(0);
  };
  T.usd = v => (v == null || !isFinite(v)) ? '—' : (v < 0 ? '−' : '') + '$' + Math.abs(v).toLocaleString('en-US', { maximumFractionDigits: Math.abs(v) < 100 ? 2 : 0 });
  T.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  T.sideFa = s => s === 'LONG' ? 'خرید' : s === 'SHORT' ? 'فروش' : 'انتظار';
  T.sideCls = s => s === 'LONG' ? 'bull' : s === 'SHORT' ? 'bear' : 'warn';
  T.biasCls = b => b > 0 ? 'bull' : b < 0 ? 'bear' : 'mut';
  T.col = { bull: '#35f2c1', bear: '#ff5a86', warn: '#ffc861', info: '#62b0ff', ai: '#a88bff', mut: '#7482b3', gold: '#ffd98a', ink: '#e9efff', ink2: '#a9b6e0', bg: '#0a1235', grid: '#ffffff', up: '', down: '' };   // mutated in place by the Studio (the chart holds this same object)
  T.rgb = hex => { const n = parseInt(String(hex).replace('#', '').slice(0, 6), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
  /** background for a heat cell, score −100..100 */
  T.heat = function (v) {
    if (v == null) return 'background:rgb(var(--tint) / .05)';
    const a = T.clamp(Math.abs(v) / 70, 0.08, 1), c = T.rgb(v >= 0 ? T.col.bull : T.col.bear).join(',');
    return `background:linear-gradient(160deg,rgba(${c},${(0.16 + a * 0.5).toFixed(2)}),rgba(${c},${(0.05 + a * 0.16).toFixed(2)}));color:rgb(${c});box-shadow:0 0 ${Math.round(a * 16 * (T.S.fx ? T.S.fx.gk : 1))}px rgba(${c},${(a * 0.4).toFixed(2)})`;
  };

  /* ── icons (24px stroke) ── */
  const IC = {
    home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
    grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
    candles: 'M6 3v4M6 17v4M4 7h4v10H4zM12 6v3M12 19v2M10 9h4v10h-4zM18 2v4M18 14v4M16 6h4v8h-4z',
    target: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7a5 5 0 100 10 5 5 0 000-10zM12 11a1 1 0 100 2 1 1 0 000-2z',
    wallet: 'M3 7a2 2 0 012-2h13v4M3 7v11a2 2 0 002 2h15V9H5a2 2 0 01-2-2zM16 14h2',
    core: 'M12 2l8 4.5v9L12 20l-8-4.5v-9zM12 2v18M4 6.5l8 4.5 8-4.5',
    gear: 'M12 9a3 3 0 100 6 3 3 0 000-6zM19 12l2-1-1-3-2 .5-1.5-1.5.5-2-3-1-1 2h-2l-1-2-3 1 .5 2L6 8.500 4 8l-1 3 2 1v2l-2 1 1 3 2-.5L7.500 17l-.5 2 3 1 1-2h2l1 2 3-1-.5-2 1.500-1.500 2 .5 1-3-2-1z',
    bell: 'M6 17V11a6 6 0 0112 0v6l2 2H4zM10 21h4',
    up: 'M12 19V5M5 12l7-7 7 7', down: 'M12 5v14M19 12l-7 7-7-7', pause: 'M8 5v14M16 5v14',
    clock: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2', shield: 'M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z',
    bolt: 'M13 2L4 14h7l-1 8 9-12h-7z', brain: 'M9 4a3 3 0 00-3 3 3 3 0 00-2 3 3 3 0 001.500 2.600A3 3 0 009 17a3 3 0 003 2V6a2 2 0 00-3-2zM15 4a3 3 0 013 3 3 3 0 012 3 3 3 0 01-1.500 2.600A3 3 0 0115 17a3 3 0 01-3 2',
    layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5M3 17.500l9 5 9-5', wave: 'M2 12c2-6 4-6 6 0s4 6 6 0 4-6 6 0', radar: 'M12 12L19 5M12 3a9 9 0 109 9M12 7a5 5 0 105 5',
    globe: 'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18', crown: 'M3 18l2-11 5 5 2-8 2 8 5-5 2 11zM3 21h18',
    spark: 'M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z', flask: 'M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3', db: 'M4 6c0-1.500 3.500-3 8-3s8 1.500 8 3-3.500 3-8 3-8-1.500-8-3zM4 6v6c0 1.500 3.500 3 8 3s8-1.500 8-3V6M4 12v6c0 1.500 3.500 3 8 3s8-1.500 8-3v-6',
    ledger: 'M5 3h12a2 2 0 012 2v16H7a2 2 0 01-2-2zM9 8h6M9 12h6M9 16h4', cone: 'M3 12L21 4v16zM9 10l12-3', shapes: 'M12 3l5 8H7zM4 14h7v7H4zM17.500 17.500a3.500 3.500 0 100 .01',
    pulse: 'M3 12h4l2-7 4 14 2-7h6', cube: 'M12 2l9 5v10l-9 5-9-5V7zM12 12l9-5M12 12v10M12 12L3 7', plus: 'M12 5v14M5 12h14', x: 'M6 6l12 12M18 6L6 18', check: 'M5 12l5 5 9-10',
    refresh: 'M20 11a8 8 0 10-2.300 5.600M20 4v7h-7', search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5', zin: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5M11 8v6M8 11h6', zout: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5M8 11h6',
    alert: 'M12 3l10 18H2zM12 10v5M12 18v.5', info: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 11v6M12 7.500v.5', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z',
    calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4', flag: 'M5 21V4M5 4h11l-2 4 2 4H5', trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13', play: 'M7 4l13 8-13 8z', lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3',
    compass: 'M12 3a9 9 0 100 18 9 9 0 000-18zM15.500 8.500l-2 5-5 2 2-5z', activity: 'M3 12h4l3-8 4 16 3-8h4', hist: 'M3 12a9 9 0 109-9M3 4v5h5M12 8v4l3 2', coins: 'M8 8a5 3 0 100 .01M3 8v4c0 1.700 2.200 3 5 3s5-1.300 5-3V8M13 11a5 3 0 100 .01M13 11v6c0 1.700 2.200 3 5 3s3-1.300 3-3v-6',
    list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01', ruler: 'M3 17L17 3l4 4L7 21zM8 8l2 2M11 5l2 2M5 11l2 2', book: 'M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM5 17a3 3 0 013-3h11', cpu: 'M7 7h10v10H7zM9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4'
  };
  T.ic = (n, cls) => `<svg viewBox="0 0 24 24"${cls ? ` class="${cls}"` : ''} aria-hidden="true"><path d="${IC[n] || IC.cube}"/></svg>`;

  /* ── small graphic builders (return HTML strings) ── */
  T.sideBadge = s => `<span class="side ${s}">${T.ic(s === 'LONG' ? 'up' : s === 'SHORT' ? 'down' : 'pause')}${T.sideFa(s)}<span class="xs" style="opacity:.7">${s}</span></span>`;
  T.grade = g => `<span class="grade ${esc(g || '—')}">${esc(g || '—')}</span>`;
  T.chip = (t, c, ic) => `<span class="chip ${c || ''}">${ic ? T.ic(ic) : ''}${t}</span>`;
  T.kpi = (label, val, o) => { o = o || {}; if (typeof val === 'string' && /^[+\-−]?[\d.,]+[%٪]?$/.test(val.trim())) val = '\u200E' + val.trim(); return `<div class="kpi" style="--kc:${o.c || '#62b0ff'}"><small>${o.ic ? T.ic(o.ic) : ''}${label}</small><b class="${o.cls || ''}">${val}</b>${o.sub ? `<span class="xs mut">${o.sub}</span>` : ''}</div>`; };
  T.bar = (v, o) => { o = o || {}; const p = T.clamp(v, 0, 100); return `<div class="bar ${o.cls || ''} ${o.tall ? 'tall' : ''}"><i style="width:${p.toFixed(1)}%"></i></div>`; };
  /** bipolar glowing bar for −max..+max */
  T.bi = (v, max) => { max = max || 100; const p = T.clamp(Math.abs(v) / max, 0, 1) * 50; return `<div class="bi"><i class="${v >= 0 ? 'p' : 'n'}" style="${v >= 0 ? 'left:50%' : 'right:50%'};width:${p.toFixed(1)}%"></i></div>`; };
  T.lights = (v, n, color) => { n = n || 10; const on = Math.round(T.clamp(v, 0, 1) * n); let h = ''; for (let i = 0; i < n; i++) h += `<i class="${i < on ? 'on' : ''}"></i>`; return `<div class="seglights" style="--c:${color || '#35f2c1'}">${h}</div>`; };
  /** ring gauge 0..100 (value shown inside) */
  T.gauge = function (v, o) {
    o = o || {}; if (o.label && (o.size || 92) < 80 && !o._in) { return `<div class="gw">${T.gauge(v, Object.assign({}, o, { _in: 1 }))}<small class="xs mut">${o.label}</small></div>`; }
    const s = o.size || 92, sw = o.sw || 9, r = (s - sw) / 2 - 2, C = 2 * Math.PI * r, p = T.clamp(v == null ? 0 : v, 0, 100), col = o.color || (p >= 66 ? T.col.bull : p >= 40 ? T.col.warn : T.col.bear);
    const id = 'g' + Math.random().toString(36).slice(2, 7);
    return `<div class="gauge" style="width:${s}px;height:${s}px;--gs:${o.fs || Math.round(s / 4.2)}px"><svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}"><defs><filter id="${id}" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="3.2"/></filter></defs>
      <circle cx="${s / 2}" cy="${s / 2}" r="${r}" fill="none" stroke="${T.col.ink}" stroke-opacity=".12" stroke-width="${sw}"/>
      <circle cx="${s / 2}" cy="${s / 2}" r="${r}" fill="none" stroke="${col}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${(C * p / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 ${s / 2} ${s / 2})" filter="url(#${id})" opacity="${T.S.fx ? Math.min(1, .25 + .6 * T.S.fx.gk) : .85}"/>
      <circle cx="${s / 2}" cy="${s / 2}" r="${r}" fill="none" stroke="${col}" stroke-width="${sw - 3}" stroke-linecap="round" stroke-dasharray="${(C * p / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 ${s / 2} ${s / 2})"/></svg>
      <div class="gv"><b style="color:${col}">${o.text != null ? o.text : (v == null ? '—' : Math.round(p))}</b>${o.label && s >= 80 ? `<small>${o.label}</small>` : ''}</div></div>`;
  };
  /** half-circle mood meter, −100..100 (bear → bull) */
  T.dial = function (v, o) {
    o = o || {}; const w = o.w || 190, h = w * 0.62, cx = w / 2, cy = h - 8, r = w / 2 - 14, a = Math.PI * (1 - (T.clamp(v, -100, 100) + 100) / 200);
    const px = cx + r * Math.cos(a), py = cy - r * Math.sin(a), id = 'd' + Math.random().toString(36).slice(2, 6);
    return `<svg class="dial" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="width:100%;max-width:${w}px;height:auto"><defs><linearGradient id="${id}" x1="0" x2="1"><stop offset="0" stop-color="${T.col.bear}"/><stop offset=".5" stop-color="${T.col.warn}"/><stop offset="1" stop-color="${T.col.bull}"/></linearGradient></defs>
      <path d="M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}" fill="none" stroke="${T.col.ink}" stroke-opacity=".12" stroke-width="12" stroke-linecap="round"/>
      <path d="M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}" fill="none" stroke="url(#${id})" stroke-width="12" stroke-linecap="round" opacity=".9"/>
      <line x1="${cx}" y1="${cy}" x2="${px.toFixed(1)}" y2="${py.toFixed(1)}" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="7" fill="${T.col.ink}"/><circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="5" fill="#fff" style="filter:drop-shadow(0 0 6px #fff)"/></svg>`;
  };
  T.spark = function (arr, o) {
    o = o || {}; arr = (arr || []).filter(x => x != null);
    const w = o.w || 120, h = o.h || 36;
    if (arr.length < 2) return `<svg width="${w}" height="${h}"></svg>`;
    const mn = Math.min(...arr), mx = Math.max(...arr), rg = (mx - mn) || 1, col = o.color || (arr[arr.length - 1] >= arr[0] ? T.col.bull : T.col.bear), id = 's' + Math.random().toString(36).slice(2, 7);
    const pts = arr.map((v, i) => [i / (arr.length - 1) * w, h - 3 - (v - mn) / rg * (h - 8)]);
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
    return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="overflow:visible"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
      <path d="${d}L${w} ${h}L0 ${h}Z" fill="url(#${id})"/><path d="${d}" fill="none" stroke="${col}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" style="filter:drop-shadow(0 0 4px ${col})"/></svg>`;
  };
  T.empty = (txt, ic) => `<div class="empty">${T.ic(ic || 'cube')}<div>${txt}</div></div>`;
  T.skel = (n, h) => Array.from({ length: n || 3 }, () => `<div class="skel" style="min-height:${h || 70}px"></div>`).join('');
  T.callout = (txt, kind, ic) => `<div class="callout ${kind || 'info'}">${T.ic(ic || (kind === 'bad' ? 'alert' : kind === 'good' ? 'check' : 'info'))}<div>${txt}</div></div>`;
  T.panel = (title, ic, body, o) => { o = o || {}; return `<section class="glass pn ${o.cls || ''}" ${o.id ? `id="${o.id}"` : ''}><h3 class="ph">${ic ? T.ic(ic) : ''}${title}${o.sub ? `<span class="sub">${o.sub}</span>` : ''}</h3>${body}</section>`; };

  /* ── toast + tooltip (event delegation on [data-tip]) ── */
  T.toast = function (msg, kind) {
    if (kind !== 'err' && T.p && T.byIdReady && !T.p('toasts')) return;
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || ''); el.textContent = msg;
    $('#toasts').appendChild(el); setTimeout(() => el.remove(), kind === 'err' ? 6000 : 3500);
  };
  document.addEventListener('mouseover', e => {
    const t = e.target.closest && e.target.closest('[data-tip]'); const tip = $('#tip');
    if (!t) { tip.hidden = true; return; }
    tip.innerHTML = t.getAttribute('data-tip').replace(/\n/g, '<br>'); tip.hidden = false;
    const r = t.getBoundingClientRect(), tw = tip.offsetWidth;
    tip.style.top = Math.max(8, r.top - tip.offsetHeight - 8) + 'px';
    tip.style.left = T.clamp(r.left + r.width / 2 - tw / 2, 8, innerWidth - tw - 8) + 'px';
  });
  document.addEventListener('scroll', () => { const t = $('#tip'); if (t) t.hidden = true; }, true);

  /* ── tiny helpers ── */
  /** delegated listener. Registering the same (root, selector, event) again REPLACES the old handler — views re-mount and re-render
   *  constantly, and stacked duplicates used to fire several times per click (a toggle clicked twice = no change). */
  const _on = new WeakMap();
  T.on = function (root, sel, ev, fn) {
    if (!root) return;
    const reg = _on.get(root) || {}; _on.set(root, reg); const key = ev + '|' + sel;
    if (reg[key]) root.removeEventListener(ev, reg[key]);
    reg[key] = e => { const t = e.target.closest && e.target.closest(sel); if (t && root.contains(t)) fn(e, t); };
    root.addEventListener(ev, reg[key]);
  };
  /** drop every T.on handler of a root (a view leaving the screen) */
  T.offAll = function (root) { const reg = _on.get(root); if (!reg) return; Object.keys(reg).forEach(k => root.removeEventListener(k.split('|')[0], reg[k])); _on.delete(root); };
  T.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  T.coinColor = sym => { let h = 0; for (const c of sym) h = (h * 31 + c.charCodeAt(0)) % 360; return `linear-gradient(140deg,hsl(${h} 80% 52%),hsl(${(h + 50) % 360} 80% 38%))`; };
  T.base = sym => String(sym || '').replace(/USDT$/, '');
  T.cfgInit = function (ui) {
    const c = T.S.cfg;
    if (ui && typeof ui === 'object') {
      ['tz', 'cal', 'h24'].forEach(k => { if (ui[k] != null) c[k] = ui[k]; });
      if (ui.layers) Object.assign(c.layers, ui.layers);
      if (ui.last) Object.assign(c.last, ui.last);
      if (ui.p && typeof ui.p === 'object') c.p = ui.p;
      if (Array.isArray(ui.dash)) c.dash = ui.dash;
    }
    T.S.sym = c.last.sym || 'BTCUSDT'; T.S.tf = c.last.tf || '1h';
  };
})(window);
