/* TITAN · views B: remaining workspace tabs, signals ledger, paper trading, central core, settings. */
(function (W) {
  'use strict';
  const T = W.TT, esc = T.esc, S = T.S, V = T.V, TABS = T.TABS, view = () => T.$('#view');
  const kv = (a, b, c) => `<div class="row sb sm" style="padding:3px 0"><span class="mut">${a}</span><b class="mono ${c || ''}">${b}</b></div>`;
  const txt = x => typeof x === 'string' ? x : x == null ? '' : (x.t || x.text || x.name || x.note || JSON.stringify(x));
  const li = a => (a || []).map(x => `<li>${esc(txt(x))}</li>`).join('') || '<li class="mut">—</li>';

  /* ── tab: levels ── */
  TABS.levels = {
    title: 'سطوح و ساختار', ic: 'ruler', build(D, w) {
      const c = D.coin, s = c.signal || {}, lv = s.levels || {}, ind = s.indicators || {}, px = (c.ticker || {}).price || s.entry, smc = (s.extras || {}).smc || {}, refs = lv.refs || {};
      const items = [];
      (lv.zones || []).forEach(z => items.push({ p: z.p, n: (z.kind === 'R' ? 'مقاومت' : 'حمایت') + ' ×' + T.fa(z.n), cls: z.kind === 'R' ? 'bear' : 'bull' }));
      [['EMA 9', ind.ema9], ['EMA 21', ind.ema21], ['EMA 50', ind.ema50], ['EMA 200', ind.ema200], ['VWAP', ind.vwap], ['بولینگر بالا', (lv.bb || {}).upper], ['بولینگر وسط', (lv.bb || {}).mid], ['بولینگر پایین', (lv.bb || {}).lower], ['دانچین سقف', ind.donch_hi], ['دانچین کف', ind.donch_lo], ['کانال رگرسیون ↑', refs.lr_upper], ['کانال رگرسیون ↓', refs.lr_lower]].forEach(([n, p]) => p && items.push({ p, n, cls: 'info' }));
      if (smc.nearest_ob && smc.nearest_ob.hi) items.push({ p: (smc.nearest_ob.hi + smc.nearest_ob.lo) / 2, n: 'Order Block (' + smc.nearest_ob.type + ')', cls: 'ai' });
      items.push({ p: px, n: 'قیمت اکنون', cls: 'warn', now: 1 }); items.sort((a, b) => b.p - a.p);
      const mx = Math.max(...items.map(i => Math.abs(i.p / px - 1))) || 0.01;
      const lad = items.map(i => `<div class="row" style="gap:10px;padding:5px 0;${i.now ? 'background:#ffc86112;border-radius:10px;padding:8px 6px' : ''}"><span style="width:130px" class="sm ${i.cls}">${esc(i.n)}</span><b class="mono" style="width:104px">${T.price(i.p)}</b><div style="flex:1"><div class="bar thin ${i.cls === 'bear' ? 'bear' : i.cls === 'warn' ? 'warn' : i.cls === 'info' ? 'info' : i.cls === 'ai' ? 'ai' : ''}"><i style="width:${i.now ? 100 : Math.max(4, Math.abs(i.p / px - 1) / mx * 100)}%"></i></div></div><span class="mono xs ${T.biasCls(i.p - px)}" style="width:62px;text-align:left">${i.now ? '' : T.pct((i.p / px - 1) * 100)}</span></div>`).join('');
      return `<div class="grid g2">${T.panel('نردبان قیمت: حمایت، مقاومت و میانگین‌ها', 'ruler', lad, { cls: 'span2', sub: 'فاصلهٔ هر سطح تا قیمت اکنون' })}
        ${T.panel('ناحیهٔ ورود', 'target', lv.entry_zone && lv.entry_zone.lo ? `${kv('از', T.price(lv.entry_zone.lo))}${kv('تا', T.price(lv.entry_zone.hi))}${T.callout(esc(lv.entry_zone.note || ''), lv.entry_zone.now_ok ? 'good' : 'warn')}` : T.empty('ناحیهٔ ورود برای حالت انتظار تعریف نمی‌شود.', 'target'))}
        ${T.panel('SMC (بلوک سفارش / شکاف)', 'layers', `${smc.nearest_ob ? kv('نزدیک‌ترین Order Block', esc(smc.nearest_ob.type || '—')) + kv('محدوده', T.price(smc.nearest_ob.lo) + ' – ' + T.price(smc.nearest_ob.hi)) : '<div class="mut sm">بلوک سفارش قابل‌توجهی نزدیک قیمت نیست.</div>'}${smc.nearest_fvg ? kv('نزدیک‌ترین FVG', esc(smc.nearest_fvg.type || '—')) + kv('محدوده', T.price(smc.nearest_fvg.lo) + ' – ' + T.price(smc.nearest_fvg.hi)) : ''}`)}</div>
        ${(lv.tp_notes || []).length ? `<div style="margin-top:12px" class="col">${lv.tp_notes.map(n => T.callout(esc(n), 'warn')).join('')}</div>` : ''}`;
    }
  };

  /* ── tab: indicators ── */
  TABS.indicators = {
    title: 'اندیکاتورها', ic: 'pulse', build(D) {
      const s = D.coin.signal || {}, i = s.indicators || {}, comps = s.components || [];
      const g = (v, l, o) => `<div class="glass pn" style="padding:12px;display:grid;place-items:center">${T.gauge(v, Object.assign({ size: 84, label: l }, o || {}))}</div>`;
      const GR = { trend: 'روند', momentum: 'مومنتوم', volume: 'حجم', structure: 'ساختار', revert: 'بازگشت به میانگین', pattern: 'الگو', volatility: 'نوسان' };
      const by = {}; comps.forEach(c => (by[c.g] = by[c.g] || []).push(c));
      return `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(130px,1fr))">${g(i.rsi, 'RSI', { color: i.rsi > 70 ? T.col.bear : i.rsi < 30 ? T.col.bull : T.col.info })}${g(i.adx, 'ADX قدرت روند', { color: T.col.ai })}${g(i.stoch_k, 'استوکاستیک')}${g(i.mfi, 'MFI جریان پول')}${g((i.bb_pos || 0) * 100, 'جای قیمت در بولینگر', { color: T.col.warn })}${g(Math.min(100, (i.vol_ratio || 0) * 50), 'نسبت حجم', { text: (i.vol_ratio || 0).toFixed(2) + '×', color: T.col.info })}${g(Math.min(100, (i.atr_pct || 0) * 20), 'ATR٪', { text: T.n(i.atr_pct, 2), color: T.col.warn })}${g(50 + (i.cmf || 0) * 100, 'CMF', { text: T.n(i.cmf, 2), color: i.cmf >= 0 ? T.col.bull : T.col.bear })}</div>
        <div class="row wrap" style="margin:14px 0;gap:8px">${T.chip('رژیم: ' + esc({ trend: 'روندی', range: 'رنج', neutral: 'گذار' }[s.regime] || s.regime), 'info', 'compass')}${T.chip('SuperTrend: ' + (i.supertrend > 0 ? 'صعودی' : 'نزولی'), i.supertrend > 0 ? 'bull' : 'bear')}${i.squeeze ? T.chip('فشردگی بولینگر', 'warn', 'alert') : ''}${T.chip('هم‌سویی ' + Math.round((s.agree || 0) * 100) + '٪', 'ai')}${T.chip('کیفیت بازار ' + Math.round((s.levels || {}).quality || 0), 'info')}</div>
        <div class="grid gB">${Object.entries(by).map(([k, arr]) => T.panel(GR[k] || k, 'layers', `<div class="col" style="gap:7px">${arr.map(c => `<div><div class="row sb xs"><span class="ink2">${esc(c.n)}</span><b class="mono ${T.biasCls(c.s)}">${c.s > 0 ? '+' : ''}${c.s.toFixed(2)}</b></div>${T.bi(c.s * 100)}<div class="xs mut">${esc(c.t)}</div></div>`).join('')}</div>`)).join('')}</div>`;
    }
  };

  /* ── tab: micro (order book / derivatives / market context) ── */
  TABS.micro = {
    title: 'بازار خرد', ic: 'wave', build(D, w) { return `<div id="micro">${T.skel(3, 110)}</div>`; },
    async after(root, D, w) {
      const [m, cx] = await Promise.all([T.api('/api/micro/' + w.sym).catch(() => ({})), T.api('/api/context/' + w.sym).catch(() => ({}))]); const el = T.$('#micro'); if (!el || S.sub !== 'micro') return;
      const dp = m.depth || {}, dv = m.derivs || {}, tot = (dp.bid_usd_1pct || 0) + (dp.ask_usd_1pct || 0);
      el.innerHTML = `<div class="grid g3">${T.panel('عمق دفتر سفارش ±۱٪', 'layers', dp.ok ? `<div class="row sm" style="gap:8px"><span class="bull">خرید ${T.usd(dp.bid_usd_1pct)}</span><span class="spacer"></span><span class="bear">فروش ${T.usd(dp.ask_usd_1pct)}</span></div><div class="bi" style="margin:8px 0"><i class="${dp.imb_1pct >= 0 ? 'p' : 'n'}" style="${dp.imb_1pct >= 0 ? 'left:50%' : 'right:50%'};width:${Math.abs(dp.imb_1pct) * 50}%"></i></div>${kv('اسپرد', T.n(dp.spread_pct, 3) + '٪')}${kv('عدم‌تعادل', T.n(dp.imb_1pct, 2))}` : T.empty('دفتر سفارش در دسترس نیست', 'layers'))}
        ${T.panel('مشتقات (فیوچرز)', 'bolt', dv.ok ? `${kv('فاندینگ سالانه', T.n(dv.funding_apr, 1) + '٪', dv.funding_apr > 20 ? 'bear' : dv.funding_apr < -20 ? 'bull' : '')}${dv.ls_buy != null ? kv('نسبت حساب‌های لانگ', Math.round(dv.ls_buy * 100) + '٪') + T.bar(dv.ls_buy * 100, { cls: dv.ls_buy > .55 ? 'bear' : '' }) : ''}${kv('تغییر OI ۲۴س', T.pct(dv.oi_chg_24h))}${kv('OI', T.big(dv.oi_usd))}${kv('بیس', T.pct(dv.basis_pct))}` : T.empty('دادهٔ مشتقات برای این ارز نیست', 'bolt'))}
        ${T.panel('بافت کلی بازار', 'globe', cx.parts ? `<div class="row" style="gap:12px">${T.gauge(50 + cx.bias * 50, { size: 72, text: (cx.bias > 0 ? '+' : '') + cx.bias.toFixed(2), label: 'سوگیری' })}<div class="col xs">${cx.fng != null ? '<span>ترس/طمع: <b class="mono">' + cx.fng + '</b> ' + esc(cx.fng_label || '') + '</span>' : ''}${cx.btc_dom != null ? '<span>دامیننس BTC: <b class="mono">' + cx.btc_dom + '٪</b></span>' : ''}<span>${cx.liq_ok === false ? '<b class="bear">نقدینگی نامناسب</b>' : '<b class="bull">نقدینگی مناسب</b>'}</span></div></div><div class="col" style="margin-top:8px;gap:6px">${cx.parts.map(p => `<div class="xs">${esc(p.t)}${T.bi(p.v * 100)}</div>`).join('')}</div>` : T.empty('بافت بازار هنوز آماده نیست', 'globe'))}</div>`;
    }
  };

  /* ── tab: AI + lab report ── */
  TABS.ai = {
    title: 'هوش مصنوعی و گزارش', ic: 'spark', build() { return `<div id="aibox">${T.skel(3, 110)}</div>`; },
    async after(root, D, w) {
      const [ai, rp] = await Promise.all([T.api('/api/ai/' + w.sym + '?tf=' + w.tf).catch(() => ({})), T.api('/api/report/' + w.sym + '?tf=' + w.tf).catch(() => ({}))]); const el = T.$('#aibox'); if (!el || S.sub !== 'ai') return;
      const bt = rp.backtest || {};
      el.innerHTML = `<div class="grid g2">${T.panel('نظر هوش مصنوعی', 'spark', ai.summary ? `<div class="row" style="margin-bottom:8px">${T.sideBadge(ai.side)}${T.chip(ai.source === 'gemini' ? 'Gemini' : ai.source === 'local' ? 'تحلیل محلی' : 'خطا', ai.source === 'gemini' ? 'ai' : 'warn')}<span class="sm mut">اطمینان ${Math.round((ai.confidence || 0) * 100)}٪</span></div><div class="sm" style="line-height:2">${esc(ai.summary)}</div><ul class="sm" style="padding-inline-start:18px;line-height:1.9">${li(ai.bullets)}</ul>${ai.risk_note ? T.callout(esc(ai.risk_note), 'warn') : ''}` : T.empty('نظر هوش مصنوعی در دسترس نیست', 'spark'))}
        ${T.panel('جمع‌بندی آزمایشگاه ارز', 'flask', rp.ok === false ? T.empty(esc(rp.error || 'گزارش آماده نیست'), 'flask') : `<div class="row" style="margin-bottom:8px">${T.sideBadge(rp.final)}${T.grade(rp.grade)}<span class="chip">${esc(rp.action || '')}</span></div><div class="sm">${esc(rp.action_why || '')}</div><div class="kpis" style="margin-top:10px">${T.kpi('اطمینان', Math.round(rp.confidence || 0) + '٪', { c: T.col.ai })}${T.kpi('امتیاز یکپارچه', T.n(rp.unified_score, 0), { cls: T.biasCls(rp.unified_score) })}</div>`)}
        ${T.panel('ریسک‌ها و تعارض‌ها', 'shield', `<ul class="sm" style="padding-inline-start:18px;line-height:1.9;margin:0">${li(rp.risks)}${(rp.conflicts || []).map(x => `<li class="warn">${esc(txt(x))}</li>`).join('')}</ul>`)}
        ${T.panel('بک‌تست همین تایم‌فریم', 'hist', bt.n ? `<div class="kpis">${T.kpi('تعداد معامله', T.fa(bt.n))}${T.kpi('نرخ برد', T.n(bt.win_rate, 0) + '٪', { c: T.col.bull })}${T.kpi('میانگین R', T.n(bt.avg_r, 2), { cls: T.biasCls(bt.avg_r) })}${T.kpi('PF', T.n(bt.pf, 2))}</div>${T.callout(bt.significant ? 'نتیجه از نظر آماری معنادار است.' : 'نمونه/برتری از نظر آماری معنادار نیست؛ به عدد به‌تنهایی اعتماد نکنید.', bt.significant ? 'good' : 'warn')}` : T.empty('بک‌تست آماده نیست', 'hist'))}</div>
        ${T.panel('روایت تحلیل', 'book', `<ul class="sm" style="padding-inline-start:18px;line-height:2;margin:0">${li(rp.narrative)}</ul>`)}`;
    }
  };

  /* ═════════ SIGNALS ═════════ */
  V.signals = {
    async mount() { view().innerHTML = '<div id="sg">' + T.skel(4, 110) + '</div>'; await this.tick(); },
    async tick() {
      const [lg, ln, rd, ev] = await Promise.all(['/api/signals/log', '/api/learn', '/api/readiness', '/api/evidence'].map(p => T.api(p).catch(() => ({})))); const el = T.$('#sg'); if (!el) return; S.siglog = lg;
      const st = lg.stats || {}, pth = lg.path || {}, rel = ln.reliability || {}, CMP = { context: 'بافت', data_trust: 'اعتماد داده', derivatives: 'مشتقات', forecast: 'پیش‌بینی', htf_trend: 'روند HTF', ltf_trigger: 'ماشه LTF', momentum: 'مومنتوم', mtf_setup: 'ستاپ MTF', pattern: 'الگو', structure: 'ساختار', volume_flow: 'حجم', x_layer: 'لایه‌های پیشرفته' };
      const pv = rd.paper && rd.paper.verdict, sv = rd.signals || {};
      el.innerHTML = `<div class="kpis">${T.kpi('کل سیگنال‌های ثبت‌شده', T.fa(lg.total || 0), { ic: 'ledger' })}${T.kpi('سنجیده‌شده (۴ ساعته)', T.fa(lg.resolved || 0), { ic: 'check', c: T.col.info })}${T.kpi('نرخ برد ۴ ساعته', lg.overall ? lg.overall.win + '٪' : '—', { ic: 'target', c: T.col.bull, cls: 'bull' })}${T.kpi('میانگین بازده', lg.overall ? T.pct(lg.overall.avg) : '—', { cls: T.biasCls(lg.overall && lg.overall.avg) })}${T.kpi('رسید به هدف ۱', pth.tp1_rate != null ? pth.tp1_rate + '٪' : '—', { c: T.col.bull })}${T.kpi('خورد به حدضرر', pth.sl_rate != null ? pth.sl_rate + '٪' : '—', { c: T.col.bear, cls: 'bear' })}</div>
        <div class="grid g3" style="margin-top:14px">${T.panel('عملکرد به تفکیک درجه', 'flag', Object.keys(st).length ? `<div class="col">${Object.entries(st).sort().map(([g, v]) => `<div class="row" style="gap:10px">${T.grade(g)}<div style="flex:1">${T.bar(v.win, { cls: v.win >= 50 ? '' : 'bear', tall: 1 })}</div><span class="mono sm">${v.win}٪</span><span class="xs mut">n=${T.fa(v.n)}</span></div>`).join('')}</div>` : T.empty('هنوز نتیجهٔ ۴ ساعته‌ای نیست؛ بعد از ۴ ساعت از اولین سیگنال پر می‌شود.', 'flag'))}
        ${T.panel('یادگیری حاکم (قابل‌اعتماد بودن هر خانواده)', 'brain', `<div class="col" style="gap:6px">${Object.entries(rel).map(([k, v]) => `<div class="row sm" style="gap:8px"><span style="width:84px" class="ink2">${CMP[k] || k}</span><div style="flex:1" class="bar thin ${v >= 1 ? '' : 'warn'}"><i style="width:${T.clamp(v / 1.4 * 100, 4, 100)}%"></i></div><b class="mono xs" style="width:38px">${(+v).toFixed(2)}</b></div>`).join('')}</div><div class="xs mut" style="margin-top:8px">${ln.ready ? 'یادگیری فعال است' : 'هنوز نمونهٔ کافی نیست؛ ضرایب روی ۱٫۰۰ می‌مانند'} · ${T.fa(ln.n_resolved || 0)} نتیجه</div>`)}
        ${T.panel('آمادگی برای پول واقعی', 'shield', `${pv ? T.callout('<b>' + esc(pv.fa) + '</b><br>' + esc(pv.why), pv.level === 'candidate' ? 'good' : 'warn') : ''}<div class="xs mut" style="margin-top:8px;line-height:1.9">${esc(rd.rules || '')}</div>${sv.n != null ? `<div class="xs mut">سیگنال‌های ثبت‌شده: ${T.fa(sv.n)} · هزینهٔ رفت‌وبرگشت ${sv.cost_pct}٪</div>` : ''}`)}</div>
        <div class="sec">${T.ic('ledger')} دفتر سیگنال‌ها (با زمان دقیق)</div><div class="glass pn scroll-x"><table class="tbl"><tr><th>زمان انتشار</th><th>ارز</th><th>حکم</th><th>درجه</th><th>اطمینان</th><th>قیمت ورود</th><th>حدضرر</th><th>هدف ۱</th><th>۱ ساعت</th><th>۴ ساعت</th><th>۲۴ ساعت</th><th>بیشینه سود</th><th>بیشینه افت</th><th>نتیجه</th></tr>
        ${(lg.entries || []).map(e => `<tr class="click" data-open="${e.symbol}"><td>${T.tstamp(e.t * 1000, true)}</td><td><b>${esc(T.base(e.symbol))}</b></td><td>${T.sideBadge(e.verdict)}</td><td>${T.grade(e.grade)}</td><td class="mono">${Math.round(e.confidence || 0)}٪</td><td class="mono">${T.price(e.price)}</td><td class="mono bear">${T.price(e.stop)}</td><td class="mono bull">${T.price(e.tp1)}</td>${['1h', '4h', '24h'].map(k => `<td class="mono ${T.biasCls(e.res && e.res[k])}">${e.res && e.res[k] != null ? T.pct(e.res[k]) : '…'}</td>`).join('')}<td class="mono bull">${T.pct(e.mfe_pct)}</td><td class="mono bear">${T.pct(e.mae_pct)}</td><td>${e.hit === 'TP1' ? T.chip('هدف ۱', 'bull', 'check') : e.hit === 'SL' ? T.chip('حدضرر', 'bear', 'x') : T.chip('باز', 'info', 'clock')}</td></tr>`).join('') || '<tr><td colspan="14" class="mut" style="text-align:center">خالی</td></tr>'}</table></div>
        ${ev.rows && ev.rows.length ? `<div class="sec">${T.ic('flask')} شواهد تاریخی هر ارز</div><div class="glass pn scroll-x"><table class="tbl"><tr><th>ارز</th><th>تعداد</th><th>نرخ برد</th><th>میانگین R</th><th>PF</th><th>t</th><th>افت</th></tr>${ev.rows.map(r => `<tr><td><b>${esc(T.base(r.symbol || r.sym || ''))}</b></td><td class="mono">${r.n}</td><td class="mono">${T.n(r.win, 0)}٪</td><td class="mono ${T.biasCls(r.avg_r)}">${T.n(r.avg_r, 2)}</td><td class="mono">${T.n(r.pf, 2)}</td><td class="mono">${T.n(r.t, 1)}</td><td class="mono bear">${T.n(r.dd, 1)}</td></tr>`).join('')}</table></div>` : ''}`;
      T.on(el, '[data-open]', 'click', (e, t) => T.openCoin(t.dataset.open));
    }
  };

  /* ═════════ TRADING (paper exchange) ═════════ */
  V.trade = {
    pre: null, async mount() { view().innerHTML = '<div id="tr">' + T.skel(3, 110) + '</div>'; this.built = false; await this.tick(); },
    async tick() {
      const [ac, pf, cf, ls] = await Promise.all(['/api/exchange', '/api/exchange/performance', '/api/auto/config', '/api/lessons'].map(p => T.api(p).catch(() => ({})))); const el = T.$('#tr'); if (!el) return;
      const eqs = (ac.equity_log || []).map(x => x.eq), pos = ac.open_positions || [], od = ac.orders || [], hist = (ac.history || []).slice(-30).reverse(), cfg = cf.cfg || {}, modes = cf.modes || {};
      const focus = document.activeElement && el.contains(document.activeElement) && ['INPUT', 'SELECT'].includes(document.activeElement.tagName); if (focus && this.built) return;       // never rebuild while the user types
      this.built = true;
      el.innerHTML = `<div class="kpis">${T.kpi('ارزش کل', T.usd(ac.equity), { ic: 'wallet', c: T.col.info })}${T.kpi('سود/زیان امروز', T.usd(ac.day_pnl), { cls: T.biasCls(ac.day_pnl), c: ac.day_pnl >= 0 ? T.col.bull : T.col.bear })}${T.kpi('سود تحقق‌یافته', T.usd(ac.realized_pnl), { cls: T.biasCls(ac.realized_pnl) })}${T.kpi('سود شناور', T.usd(ac.unrealized_pnl), { cls: T.biasCls(ac.unrealized_pnl) })}${T.kpi('نرخ برد', ac.trades ? Math.round(ac.win_rate) + '٪' : '—', { c: T.col.bull, sub: T.fa(ac.wins || 0) + ' برد از ' + T.fa(ac.trades || 0) })}${T.kpi('بیشترین افت', T.n(ac.max_drawdown_pct, 1) + '٪', { c: T.col.bear })}</div>
        ${ac.paused ? `<div style="margin-top:12px">${T.callout('معاملهٔ خودکار متوقف شده: ' + esc(ac.pause_reason || ''), 'bad')} <button class="btn sm" id="tr-resume" style="margin-top:6px">ادامه</button></div>` : ''}${ac.notice ? `<div style="margin-top:12px">${T.callout(esc(ac.notice), 'warn')}</div>` : ''}
        <div class="grid split" style="margin-top:14px"><div class="col" style="gap:14px">${T.panel('منحنی سرمایه', 'activity', T.spark(eqs.length > 1 ? eqs : [ac.starting, ac.equity], { w: 640, h: 120 }).replace('width="640"', 'width="100%" preserveAspectRatio="none"'), { sub: 'شروع ' + T.usd(ac.starting) })}
          ${T.panel('پوزیشن‌های باز (' + T.fa(pos.length) + ')', 'target', pos.length ? `<div class="col" style="gap:12px">${pos.map(p => this.pos(p)).join('')}</div>` : T.empty('پوزیشن بازی نیست. از تب «سیگنال نهایی» هر ارز می‌توانید ثبت کنید.', 'target'))}
          ${od.length ? T.panel('سفارش‌های در انتظار', 'clock', `<table class="tbl"><tr><th>ارز</th><th>سمت</th><th>نوع</th><th>قیمت</th><th>ایجاد</th><th>انقضا</th><th></th></tr>${od.map(o => `<tr><td><b>${esc(T.base(o.symbol))}</b></td><td>${T.sideBadge(o.side)}</td><td>${o.mode === 'limit' ? 'لیمیت' : 'استاپ'}</td><td class="mono">${T.price(o.price)}</td><td>${T.tstamp(o.created * 1000)}</td><td>${T.tstamp(o.expires * 1000, true)}</td><td><button class="btn sm dng" data-cancel="${o.id}">${T.ic('x')}</button></td></tr>`).join('')}</table>`) : ''}
          ${T.panel('تاریخچهٔ معاملات (۳۰ آخر)', 'hist', hist.length ? `<div class="scroll-x"><table class="tbl"><tr><th>ارز</th><th>سمت</th><th>باز شد</th><th>بسته شد</th><th>مدت</th><th>ورود → خروج</th><th>R</th><th>سود/زیان</th><th>دلیل</th></tr>${hist.map(h => `<tr><td><b>${esc(T.base(h.symbol))}</b></td><td>${T.sideBadge(h.side)}</td><td>${T.tstamp(h.opened_at * 1000)}</td><td>${T.tstamp(h.closed_at * 1000)}</td><td class="mono xs">${esc(T.dur((h.closed_at - h.opened_at) * 1000))}</td><td class="mono xs">${T.price(h.entry)} → ${T.price(h.exit)}</td><td class="mono ${T.biasCls(h.r)}">${h.r > 0 ? '+' : ''}${h.r}R</td><td class="mono ${T.biasCls(h.pnl)}">${T.usd(h.pnl)}</td><td class="xs">${esc(h.reason)}</td></tr>`).join('')}</table></div>` : T.empty('هنوز معامله‌ای بسته نشده.', 'hist'))}</div>
        <div class="col" style="gap:14px">${T.panel('ثبت دستی سفارش', 'plus', this.form())}
          ${T.panel('معامله خودکار', 'bolt', `<div class="row sb" style="margin-bottom:10px"><span>${ac.auto_trade ? '<b class="bull">روشن</b>' : '<b class="mut">خاموش</b>'}</span><div class="sw ${ac.auto_trade ? 'on' : ''}" id="tr-auto" role="switch" tabindex="0"></div></div>
            <label class="xs mut">حالت</label><select class="inp" id="tr-mode" style="width:100%">${Object.entries(modes).map(([k, m]) => `<option value="${k}" ${cfg.mode === k ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>
            <div class="xs mut" style="margin-top:8px;line-height:1.9">حداقل درجه ${esc(cfg.min_grade)} · R:R ≥ ${cfg.min_rr} · ریسک هر معامله ${cfg.risk_pct}٪ · حداکثر ${cfg.max_open} پوزیشن · خروج زمانی ${cfg.time_stop_h} ساعت</div>
            ${(ac.auto_log || []).length ? `<div class="col xs" style="margin-top:8px;max-height:200px;overflow:auto;gap:4px">${ac.auto_log.slice(-12).reverse().map(l => `<div class="${l.ok ? 'bull' : 'mut'}">${l.ok ? '✔' : '✖'} ${l.t ? esc(T.time(l.t * 1000)) + ' · ' : ''}<b>${esc(T.base(l.symbol || ''))}</b> ${esc(l.text || '')}</div>`).join('')}</div>` : ''}`)}
          ${T.panel('حافظهٔ اشتباهات', 'brain', `<div class="sm ink2" style="line-height:1.9;margin-bottom:8px">هر پوزیشن دلیل ورودش را ذخیره می‌کند؛ بعد از بسته‌شدن علت برد/باخت نوشته می‌شود و اشتباهِ تکراری در ورود بعدی مسدود می‌شود.</div>${(ls.rules || []).map(r => T.callout(esc(r.text) + ' (n=' + r.n + ')', 'warn')).join('<div style="height:5px"></div>') || '<div class="mut xs">هنوز قانونی فعال نشده (نیاز به چند معاملهٔ بسته‌شده).</div>'}<div class="col" style="margin-top:8px;gap:6px;max-height:240px;overflow:auto">${(ls.cases || []).slice(0, 6).map(c => `<div class="callout ${c.win ? 'good' : 'bad'}" style="padding:6px 10px;font-size:11.5px">${esc(c.lesson)}</div>`).join('')}</div>`)}
          ${T.panel('عملکرد', 'flag', `${kv('میانگین R', T.n((ac.stats || {}).avg_r, 2))}${kv('امید ریاضی', T.n((ac.stats || {}).expectancy, 2))}${kv('PF', T.n((ac.stats || {}).profit_factor, 2))}${kv('کارمزد پرداختی', T.usd(ac.total_fees))}${kv('بهترین / بدترین', T.usd((ac.stats || {}).best) + ' / ' + T.usd((ac.stats || {}).worst))}<button class="btn dng sm" id="tr-reset" style="margin-top:8px">${T.ic('trash')}ریست حساب</button>`)}</div></div>`;
      this.bind(el);
    },
    pos(p) {
      const d = p.side === 'LONG' ? 1 : -1, risk = Math.abs(p.entry - p.stop0) || 1;
      return `<div class="glass pn" style="padding:12px 14px"><div class="row sb wrap"><div class="row"><b class="lg">${esc(T.base(p.symbol))}</b>${T.sideBadge(p.side)}<span class="chip">${p.leverage}×</span>${p.source === 'auto' ? T.chip('خودکار', 'ai', 'bolt') : ''}${T.chip('مرحله ' + T.fa(p.stage), 'info')}</div><div class="row"><b class="mono ${T.biasCls(p.unrealized)}">${T.usd(p.unrealized)}</b><button class="btn sm dng" data-close="${p.id}">بستن</button></div></div>
        <div class="grid g4 sm" style="gap:8px;margin:8px 0"><div><span class="mut xs">ورود</span><br><b class="mono">${T.price(p.entry)}</b></div><div><span class="mut xs">حدضرر</span><br><b class="mono bear">${T.price(p.stop)}</b></div><div><span class="mut xs">اهداف</span><br><b class="mono bull">${T.price(p.tp1)} · ${T.price(p.tp2)} · ${T.price(p.tp3)}</b></div><div><span class="mut xs">تصفیه</span><br><b class="mono warn">${T.price(p.liq)}</b></div></div>
        <div class="row xs mut" style="gap:14px">${T.ic('clock')}باز شد ${esc(T.dt(p.opened_at * 1000))} (${esc(T.rel(p.opened_at * 1000))})${p.deadline ? ' · خروج زمانی ' + esc(T.dt(p.deadline * 1000)) : ''}</div></div>`;
    },
    form() {
      const pr = this.pre || {};
      return `<div class="col" style="gap:8px"><div class="row"><input class="inp" id="o-sym" placeholder="ارز" value="${esc(pr.symbol || S.sym)}" style="width:50%"><select class="inp" id="o-side"><option>LONG</option><option ${pr.side === 'SHORT' ? 'selected' : ''}>SHORT</option></select></div>
        <div class="row"><select class="inp" id="o-mode" style="flex:1"><option value="market">بازار (فوری)</option><option value="limit">لیمیت</option><option value="stop">استاپ</option></select><input class="inp" id="o-px" placeholder="قیمت (لیمیت/استاپ)" value="${pr.entry ? esc(String(pr.entry)) : ''}" style="flex:1"></div>
        <input class="inp" id="o-sl" placeholder="حدضرر" value="${pr.stop ? esc(String(pr.stop)) : ''}"><div class="row"><input class="inp" id="o-t1" placeholder="هدف ۱" value="${pr.tp1 ? esc(String(pr.tp1)) : ''}" style="width:33%"><input class="inp" id="o-t2" placeholder="هدف ۲" value="${pr.tp2 ? esc(String(pr.tp2)) : ''}" style="width:33%"><input class="inp" id="o-t3" placeholder="هدف ۳" value="${pr.tp3 ? esc(String(pr.tp3)) : ''}" style="width:33%"></div>
        <button class="btn pri" id="o-go">${T.ic('check')}ثبت سفارش</button></div>`;
    },
    bind(el) {
      const act = async (p, b, ok) => { const r = await T.post(p, b).catch(e => ({ ok: false, error: e.message })); if (r && (r.ok === false || r.error)) T.toast(r.error || 'ناموفق', 'err'); else T.toast(ok || 'انجام شد', 'ok'); this.built = false; this.tick(); };
      T.on(el, '[data-close]', 'click', (e, b) => act('/api/exchange/close', { id: b.dataset.close }, 'پوزیشن بسته شد'));
      T.on(el, '[data-cancel]', 'click', (e, b) => act('/api/order/cancel', { id: b.dataset.cancel }, 'سفارش لغو شد'));
      const g = id => T.$('#' + id, el);
      g('o-go') && g('o-go').addEventListener('click', () => {
        let sym = g('o-sym').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); if (sym && !sym.endsWith('USDT')) sym += 'USDT';
        act('/api/order', { symbol: sym, side: g('o-side').value, mode: g('o-mode').value, price: parseFloat(g('o-px').value) || 0, stop: parseFloat(g('o-sl').value), tp1: parseFloat(g('o-t1').value), tp2: parseFloat(g('o-t2').value), tp3: parseFloat(g('o-t3').value) || 0 }, 'سفارش ثبت شد');
      });
      g('tr-auto') && g('tr-auto').addEventListener('click', () => act('/api/exchange/auto', { enabled: !g('tr-auto').classList.contains('on') }, 'تنظیم شد'));
      g('tr-mode') && g('tr-mode').addEventListener('change', e => act('/api/auto/config', { mode: e.target.value }, 'حالت تغییر کرد'));
      g('tr-resume') && g('tr-resume').addEventListener('click', () => act('/api/auto/resume', {}, 'ادامه یافت'));
      g('tr-reset') && g('tr-reset').addEventListener('click', () => { if (!T.p('confirmx') || confirm('حساب کاغذی به ۱۰٬۰۰۰ دلار برگردد و تاریخچه پاک شود؟')) act('/api/exchange/reset', {}, 'حساب ریست شد'); });
    }
  };
  T.prefillOrder = function (plan, sym) { V.trade.pre = Object.assign({ symbol: sym }, plan); T.go('trade'); };

  /* ═════════ CENTRAL CORE ═════════ */
  V.core = {
    async mount() { view().innerHTML = '<div id="cr">' + T.skel(4, 110) + '</div>'; await this.tick(); },
    async tick() {
      const c = await T.api('/api/core').catch(() => null); const el = T.$('#cr'); if (!el || !c) return; S.core = c;
      const ST = { ok: 'سالم', warn: 'هشدار', error: 'خطا', idle: 'منتظر', off: 'خاموش' }, stc = { ok: 'bull', warn: 'warn', error: 'bear', idle: 'mut', off: 'mut' }, by = {}, M = {};
      c.modules.forEach(m => { (by[m.group] = by[m.group] || []).push(m); M[m.id] = m; });
      const sc = c.scan || {}, stor = c.storage || {};
      el.innerHTML = `<div class="grid g4">${T.panel('سلامت کل', 'core', `<div class="row" style="gap:14px">${T.gauge(c.health, { size: 100, label: 'هسته' })}<div class="col xs"><span>زمان کارکرد: <b class="mono">${esc(T.dur(c.uptime * 1000))}</b></span><span>نسخه: <b class="mono">${esc(c.version)}</b></span><span>${sc.scanning ? T.chip('در حال اسکن', 'info', 'radar') : T.chip('بیکار', 'bull', 'check')}</span></div></div>`)}
        ${T.panel('اسکن', 'radar', `${kv('آخرین اسکن', sc.last_scan ? esc(T.dt(sc.last_scan * 1000)) : '—')}${kv('مدت', T.n(sc.duration, 1) + ' ثانیه')}${kv('موفق / خطا', T.fa((sc.progress || {}).ok || 0) + ' / ' + T.fa((sc.progress || {}).err || 0))}<div class="row" style="margin-top:8px"><button class="btn pri sm" id="cr-scan">${T.ic('play')}اسکن فوری</button><button class="btn sm" id="cr-full">${T.ic('refresh')}کامل</button></div>`)}
        ${T.panel('حافظه XXX', 'db', `${kv('پوشه', '<span class="mono">' + esc(stor.dir) + '/</span>')}${kv('حجم', T.n((stor.bytes || 0) / 1024, 1) + ' KB')}${kv('فایل‌ها', T.fa((stor.files || []).length))}<div class="mt-2">${stor.only_here ? T.chip('همهٔ داده فقط در XXX', 'bull', 'lock') : T.chip('مسیر داده بیرون از XXX!', 'bear', 'alert')}</div>`)}
        ${T.panel('صرافی‌های داده', 'wave', `<div class="col xs" style="gap:5px">${Object.entries(c.sources || {}).map(([k, v]) => `<div class="row sb"><span><span class="${v.cooling ? 'bear' : v.last_ok ? 'bull' : 'mut'}">●</span> ${esc(k)}</span><span class="mono mut">${v.lat_ms ? v.lat_ms + 'ms' : '—'} · ${T.fa(v.ok)}✓ ${T.fa(v.fail)}✗</span></div>`).join('')}</div>`)}</div>
        <div class="sec">${T.ic('layers')} مسیر جریان داده — هسته مرکزی همهٔ این مراحل را اجرا، اندازه‌گیری و مدیریت می‌کند</div>
        <div class="glass pn"><div class="pipe">${c.pipeline.map(p => { const m = M[p.mod] || {}; return `<div class="node st-${m.status || 'idle'}">${T.ic(({ market: 'wave', analysis: 'pulse', smc: 'layers', forecast: 'cone', patterns: 'shapes', context: 'globe', governor: 'crown', gemini: 'spark', siglog: 'ledger', learn: 'brain', lessons: 'brain', paper: 'wallet' })[p.mod] || 'cube')}<b class="sm">${esc(p.title)}</b><small>${ST[m.status] || ''} · ${m.avg_ms ? m.avg_ms + 'ms' : '—'}</small></div>`; }).join('')}</div></div>
        ${Object.entries(c.groups).map(([g, name]) => `<div class="sec">${T.ic('cube')} ${esc(name)}</div><div class="grid gB">${(by[g] || []).map(m => `<div class="glass pn mod st-${m.status}"><div class="row sb"><div class="row">${T.ic(m.icon && ({ db: 'db', wave: 'wave', radar: 'radar', pulse: 'pulse', layers: 'layers', cone: 'cone', shapes: 'shapes', globe: 'globe', crown: 'crown', spark: 'spark', ledger: 'ledger', brain: 'brain', flask: 'flask', wallet: 'wallet', bolt: 'bolt', bell: 'bell', brain: 'brain' })[m.icon] ? m.icon : 'cube').replace('<svg', '<svg style="width:22px;height:22px;stroke:var(--nc);fill:none;stroke-width:1.8"')}<b>${esc(m.title)}</b></div><div class="row">${T.chip(ST[m.status], stc[m.status])}${m.controllable ? `<div class="sw ${m.enabled ? 'on' : ''}" data-mod="${m.id}" role="switch" tabindex="0" data-tip="${m.enabled ? 'خاموش‌کردن توسط هسته' : 'روشن‌کردن'}"></div>` : ''}</div></div>
          <div class="sm ink2" style="margin:6px 0">${esc(m.role)}</div><ul class="tasks">${m.tasks.map(t => `<li>${esc(t)}</li>`).join('')}</ul>
          <div class="row wrap xs mut" style="gap:12px;margin-top:8px"><span>فراخوانی: <b class="mono">${T.fa(m.calls)}</b></span><span>خطا: <b class="mono ${m.errors ? 'bear' : ''}">${T.fa(m.errors)}</b></span><span>میانگین: <b class="mono">${m.avg_ms}ms</b></span><span>آخرین اجرا: ${m.last_ok ? esc(T.time(m.last_ok, true)) : '—'}</span></div>${m.deps.length ? `<div class="xs mut" style="margin-top:4px">وابسته به: ${m.deps.map(d => esc((M[d] || {}).title || d)).join('، ')}</div>` : ''}${m.last_err ? `<div class="xs bear" style="margin-top:4px">آخرین خطا: ${esc(m.last_err)}</div>` : ''}</div>`).join('')}</div>`).join('')}
        <div class="sec">${T.ic('list')} رویدادهای هسته</div><div class="glass pn"><div class="col xs" style="gap:4px;max-height:260px;overflow:auto">${c.events.map(e => `<div class="row" style="gap:10px"><span class="mono mut">${esc(T.time(e.t, true))}</span><span class="chip ${e.level === 'err' ? 'bear' : 'info'}">${esc((M[e.mod] || {}).title || e.mod)}</span><span>${esc(e.text)}</span></div>`).join('') || '<span class="mut">رویدادی نیست</span>'}</div></div>
        ${(stor.files || []).length ? `<div class="sec">${T.ic('db')} فایل‌های حافظه</div><div class="glass pn"><table class="tbl">${stor.files.map(f => `<tr><td class="mono">XXX/${esc(f.name)}</td><td class="mono">${T.n(f.size / 1024, 1)} KB</td><td>${T.tstamp(f.mtime, true)}</td></tr>`).join('')}</table></div>` : ''}`;
      T.on(el, '[data-mod]', 'click', async (e, b) => { const r = await T.post('/api/core/toggle', { mod: b.dataset.mod, enabled: !b.classList.contains('on') }); r.ok === false ? T.toast(r.error, 'err') : T.toast('اعمال شد', 'ok'); this.tick(); });
      const sc1 = T.$('#cr-scan'), sc2 = T.$('#cr-full'); sc1 && sc1.addEventListener('click', () => T.scan(false)); sc2 && sc2.addEventListener('click', () => T.scan(true));
    }
  };

  /* ═════════ SETTINGS ═════════ */
  V.settings = {
    async mount() {
      const [st, al] = await Promise.all([T.api('/api/settings'), T.api('/api/alerts').catch(() => ({ alerts: [] }))]);
      this.wl = st.watchlist.slice(); 
      const now = T.nowMs();
      view().innerHTML = `<div class="grid g2">${T.panel('ظاهر، زمان و تاریخ', 'spark', `<div class="col" style="gap:10px"><div class="sm ink2" style="line-height:2">همهٔ گزینه‌های ظاهر (تم، رنگ، چیدمان، افکت‌ها)، منطقهٔ زمانی، تقویم شمسی/میلادی و ساعت ۲۴ساعته در «استودیو» هستند.</div><button class="btn pri" data-go="studio">${T.ic('spark')}باز کردن استودیو شخصی‌سازی</button><div class="callout info" id="s-prev">${esc(T.dtFull(now))}</div></div>`)}
        ${T.panel('اسکن', 'radar', `<div class="col" style="gap:10px"><div class="row sb"><span class="sm">فاصلهٔ اسکن خودکار</span><b class="mono" id="s-scan-v">${st.scan_sec}s</b></div><input type="range" id="s-scan" min="30" max="900" step="15" value="${st.scan_sec}" style="width:100%"><div class="xs mut">کمتر از ۳۰ ثانیه مجاز نیست تا صرافی‌ها محدود نکنند.</div></div>`)}
        ${T.panel('فهرست پیگیری ارزها', 'coins', `<div class="row wrap" id="s-wl" style="gap:6px;margin-bottom:10px"></div><div class="row"><input class="inp" id="s-add" placeholder="مثلاً ARB یا ARBUSDT" style="flex:1"><button class="btn pri" id="s-addb">${T.ic('plus')}افزودن</button></div><div class="xs mut" style="margin-top:6px">حداکثر ۳۰ ارز. بعد از ذخیره، اسکن تازه اجرا می‌شود.</div>`, { cls: 'span2' })}
        ${T.panel('هشدارها', 'bell', `<div id="s-al"></div><div class="row wrap" style="margin-top:10px;gap:8px"><input class="inp" id="a-sym" placeholder="ارز" style="width:110px"><select class="inp" id="a-op"><option value=">">بالاتر از</option><option value="<">پایین‌تر از</option></select><input class="inp" id="a-px" placeholder="قیمت" style="width:120px"><button class="btn" id="a-add">${T.ic('plus')}هشدار قیمت</button><button class="btn" id="a-sig">${T.ic('bolt')}هشدار سیگنال درجه B+ (همهٔ ارزها)</button></div>`)}
        ${T.panel('داده و کلید هوش مصنوعی', 'lock', `<div class="sm" style="line-height:2">همهٔ داده‌ها، حافظه، لاگ‌ها و تنظیمات فقط در پوشهٔ <b class="mono">${esc(S.status && S.status.data_name || 'XXX')}</b> کنار برنامه ذخیره می‌شود.<br>کلید Gemini را در فایل <b class="mono">XXX/secret/gemini_api_key.txt</b> بگذارید؛ بدون کلید، تحلیل محلی نمایش داده می‌شود.</div>`)}</div>`;
      const sv = T.$('#s-scan'); sv.addEventListener('input', () => { T.$('#s-scan-v').textContent = sv.value + 's'; }); sv.addEventListener('change', () => T.post('/api/settings', { scan_sec: +sv.value }).then(() => T.toast('ذخیره شد', 'ok')));
      const drawWl = () => { T.$('#s-wl').innerHTML = this.wl.map(s => `<span class="chip info" style="padding:4px 4px 4px 12px">${esc(T.base(s))}<button class="btn sm" data-rm="${s}" style="padding:0 6px;border-radius:8px">${T.ic('x')}</button></span>`).join(''); };
      drawWl();
      const saveWl = async () => { const r = await T.post('/api/settings', { watchlist: this.wl }); if (r.error) T.toast(r.error, 'err'); else { this.wl = r.watchlist; drawWl(); T.toast('فهرست ذخیره شد', 'ok'); T.scan(true); } };
      T.on(view(), '[data-rm]', 'click', (e, b) => { this.wl = this.wl.filter(x => x !== b.dataset.rm); saveWl(); });
      T.$('#s-addb').addEventListener('click', () => { let v = T.$('#s-add').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); if (!v) return; if (!v.endsWith('USDT')) v += 'USDT'; if (!this.wl.includes(v)) this.wl.push(v); T.$('#s-add').value = ''; saveWl(); });
      const drawAl = async () => { const a = (await T.api('/api/alerts')).alerts || []; T.$('#s-al').innerHTML = a.length ? a.map(x => `<div class="row sb sm" style="padding:6px 0;border-bottom:1px solid var(--gl2)"><span>${x.type === 'price' ? T.ic('bell').replace('<svg', '<svg style="width:15px;height:15px;display:inline;stroke:currentColor;fill:none;stroke-width:2"') + ' ' + esc(T.base(x.symbol)) + ' ' + (x.op === '>' ? 'بالاتر از ' : 'پایین‌تر از ') + '<b class="mono">' + x.price + '</b>' : 'سیگنال درجه ' + esc(x.min_grade) + '+ · ' + (x.symbol === '*' ? 'همهٔ ارزها' : esc(T.base(x.symbol)))}</span><span>${x.fired ? T.chip('فعال شد ' + esc(T.dt(x.fired.t * 1000)), 'bull', 'check') : T.chip('منتظر', 'info', 'clock')}<button class="btn sm dng" data-ad="${x.id}">${T.ic('trash')}</button></span></div>`).join('') : '<div class="mut sm">هشداری تعریف نشده.</div>'; };
      drawAl(); T.on(view(), '[data-ad]', 'click', async (e, b) => { await T.del('/api/alerts/' + b.dataset.ad); drawAl(); });
      const addA = async b => { const r = await T.post('/api/alerts', b); r.error ? T.toast(r.error, 'err') : (T.toast('هشدار ثبت شد', 'ok'), drawAl()); };
      T.$('#a-add').addEventListener('click', () => addA({ type: 'price', symbol: T.$('#a-sym').value, op: T.$('#a-op').value, price: parseFloat(T.$('#a-px').value) }));
      T.$('#a-sig').addEventListener('click', () => addA({ type: 'signal', symbol: '*', min_grade: 'B' }));
    },
    tick() { }
  };
})(window);
