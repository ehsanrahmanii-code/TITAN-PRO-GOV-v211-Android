/* TITAN · boot: navigation, router, polling, live clock. */
(function (W) {
  'use strict';
  const T = W.TT, S = T.S, V = T.V, esc = T.esc;
  const NAV = [['تحلیل', [['dash', 'home', 'داشبورد'], ['market', 'grid', 'بازار'], ['work', 'candles', 'تحلیل ارز']]], ['اجرا', [['signals', 'target', 'سیگنال‌ها'], ['trade', 'wallet', 'معاملات']]], ['سیستم', [['core', 'core', 'هسته'], ['studio', 'spark', 'استودیو'], ['settings', 'gear', 'تنظیمات']]]];
  const TITLE = { dash: 'داشبورد', market: 'بازار و ارزها', work: 'تحلیل ارز', signals: 'سیگنال‌ها و ارزیابی', trade: 'معاملات کاغذی', core: 'هسته مرکزی', studio: 'استودیو شخصی‌سازی', settings: 'تنظیمات' };
  let cur = null;

  T.go = function (route) {
    if (!V[route]) route = 'dash';
    if (cur && V[cur] && V[cur].unmount) V[cur].unmount();
    T.offAll(T.$('#view'));
    S.route = cur = route; history.replaceState(null, '', '#' + route);
    drawNav(); T.$('#view').scrollTop = 0; T.$('#view').innerHTML = ''; V[route].mount(); setTimeout(() => T.P && T.P.fx && T.P.fx.after(T.$('#view')), 700);
    const t = T.$('#top-title'); if (t) t.innerHTML = `${TITLE[route]}<small>TITAN PRO · حاکم مرکزی · ذخیره‌سازی فقط در ${esc((S.status && S.status.data_name) || 'XXX')}</small>`;
  };
  function drawNav() {
    const grp = T.p ? !!T.p('railgroups') : true;
    const btn = ([k, ic, n]) => `<button class="nav ${S.route === k ? 'on' : ''}" data-go="${k}" aria-label="${n}">${T.ic(ic)}<span>${n}</span></button>`;
    const html = NAV.map(([g, items], i) => (grp ? `${i ? '<div class="rail-sep"></div>' : ''}<div class="rail-cap">${g}</div>` : '') + items.map(btn).join('')).join('');
    T.$('#rail').innerHTML = `<div class="logo"><svg viewBox="0 0 48 48"><defs><linearGradient id="lg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="${T.col.bull}"/><stop offset="1" stop-color="${T.col.info}"/></linearGradient></defs><rect x="3" y="3" width="42" height="42" rx="13" fill="${T.col.bg}" stroke="url(#lg)" stroke-width="1.5"/><path d="M10 31l6-15 8 10 5-14 9 19" fill="none" stroke="url(#lg)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg><b>TITAN</b></div>${html}<div class="rail-foot"><span class="pulse ${S.status && S.status.scanning ? '' : 'off'}" id="rail-dot"></span><span>v${esc(String((S.status && S.status.version) || '').split('-')[0])}</span></div>`;
    T.$('#dock').innerHTML = NAV.flatMap(g => g[1]).filter(x => x[0] !== 'studio' || true).slice(0, 7).map(btn).join('');
  }
  T.drawNav = drawNav;
  document.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) T.go(b.dataset.go); });

  T.scan = async function (full) {
    const r = await T.post('/api/scan' + (full ? '?full=1' : '')).catch(() => ({}));
    T.toast(r.status === 'busy' ? 'اسکن در حال اجراست' : 'اسکن شروع شد', 'ok'); pollStatus();
  };

  function drawTop() {
    T.$('#top').innerHTML = `<h1 id="top-title"></h1><div class="scanpill" id="scanpill"><span class="pulse off" id="sp-dot"></span><span id="sp-txt">در انتظار اولین اسکن…</span><div class="bar" id="sp-bar" hidden><i style="width:0"></i></div></div>
      <div class="clock" title="ساعت و تاریخ بر اساس تنظیمات"><b class="num" id="clk-t">--:--</b><span id="clk-d"></span></div><button class="btn" id="top-scan">${T.ic('refresh')}<span>اسکن</span></button>`;
    T.$('#top-scan').addEventListener('click', () => T.scan(true));
  }
  function tickClock() {
    const n = T.nowMs(), t = T.$('#clk-t'); if (t) { t.textContent = T.time(n, true); T.$('#clk-d').textContent = innerWidth < 560 ? T.wday(n) + ' ' + T.jdate(n, false) : T.wday(n) + ' ' + T.date(n, true); }
    const d = T.$('#dclock'); if (d) { d.textContent = T.time(n, true); T.$('#ddate').textContent = T.wday(n) + ' ' + T.date(n, true); }
    const cd = T.$('#wk-cd'); if (cd) { const c = +cd.dataset.close; if (c) { const s = Math.max(0, Math.round((c - n) / 1000)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60; cd.textContent = (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(ss).padStart(2, '0'); } }
  }

  async function pollStatus() {
    try {
      const st = await T.api('/api/status'); S.status = st; if (st.now) S.skew = st.now - Date.now();
      if (S.core) S.core.health = st.core_health;
      const pr = st.progress || {}, sp = T.$('#sp-txt'); if (sp) {
        T.$('#sp-dot').className = 'pulse ' + (st.scanning ? '' : st.errors && st.errors.length && !st.last_scan ? 'bad' : '');
        const bar = T.$('#sp-bar'); bar.hidden = !st.scanning; if (st.scanning) bar.firstElementChild.style.width = (pr.total ? pr.done / pr.total * 100 : 0) + '%';
        sp.textContent = st.scanning ? `در حال اسکن ${T.fa(pr.done || 0)} از ${T.fa(pr.total || 0)}` : st.last_scan ? 'آخرین اسکن ' + T.time(st.last_scan * 1000, true) : 'در انتظار اولین اسکن…';
      }
      const rd = T.$('#rail-dot'); if (rd) rd.className = 'pulse ' + (st.scanning ? '' : 'off');
      if (!S.matrix || st.scanning) pollMatrix();
    } catch (e) { const sp = T.$('#sp-txt'); if (sp) sp.textContent = 'ارتباط با سرور قطع است'; const d = T.$('#sp-dot'); if (d) d.className = 'pulse bad'; }
  }
  let lastM = 0;
  async function pollMatrix() {
    try {
      const m = await T.api('/api/matrix'); const prevM = S.matrix && S.matrix.matrix; S.matrix = m; lastM = Date.now();
      if (prevM) Object.values(m.matrix).forEach(r => { const o = prevM[r.symbol]; if (o && o.verdict !== r.verdict && r.verdict !== 'WAIT') { T.toast(`${T.base(r.symbol)}: سیگنال ${T.sideFa(r.verdict)} (${r.grade})`, 'ok'); if (T.p('snd') && T.P.fx) T.P.fx.beep(r.verdict === 'LONG'); } });
      if (cur === 'dash' || cur === 'market') V[cur].tick();
    } catch (e) { /* keep last */ }
  }
  async function pollSlow() {
    try { S.market = await T.api('/api/market'); } catch (e) { /* ignore */ }
    try { S.siglog = await T.api('/api/signals/log'); } catch (e) { /* ignore */ }
    try { S.exchange = await T.api('/api/exchange'); } catch (e) { /* ignore */ }
    try { S.lessons = await T.api('/api/lessons'); } catch (e) { /* ignore */ }
    if (cur === 'dash') V.dash.tick();
  }

  async function boot() {
    drawTop();
    try { const st = await T.api('/api/settings'); T.cfgInit(st.ui); S.status = S.status || { symbols: st.watchlist }; } catch (e) { /* defaults */ }
    T.P.apply(); if (!S.subSet) S.sub = T.p('wtab') || 'trend';
    const h = (location.hash || '').slice(1); drawNav(); T.go(V[h] ? h : (T.p('startpage') || 'dash'));
    await pollStatus(); pollMatrix(); pollSlow();
    setInterval(tickClock, 1000); tickClock();
    const loopStatus = () => { pollStatus().finally(() => setTimeout(loopStatus, Math.max(2, +T.p('poll') || 4) * 1000)); }; setTimeout(loopStatus, 4000);
    setInterval(() => { if (Date.now() - lastM > 9000) pollMatrix(); }, 3000);
    setInterval(pollSlow, 30000);
    setInterval(() => { const v = V[cur]; if (v && v.tick && !['dash', 'market'].includes(cur)) { if (cur === 'work' ? !document.hidden : !document.hidden) v.tick(); } }, 15000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { pollStatus(); pollMatrix(); } });
  }
  boot();
})(window);
