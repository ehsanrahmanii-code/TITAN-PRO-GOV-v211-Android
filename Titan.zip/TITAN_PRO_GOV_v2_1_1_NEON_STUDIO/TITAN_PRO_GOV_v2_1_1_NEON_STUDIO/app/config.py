"""TITAN PRO GOV — configuration. All persistent data lives ONLY under XXX/."""
from __future__ import annotations
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ── ALL data (cache, memory, logs, settings, secrets) must live inside XXX only ──
DATA_NAME = "XXX"
LEGACY_DATA_NAMES = ("YYY", "WWW", "LLL", "JJJ")          # older folder names, migrated once into XXX
DATA_DIR = Path(os.getenv("TITAN_DATA", str(ROOT / DATA_NAME))).expanduser()
SECRET_DIR = Path(os.getenv("TITAN_SECRET", str(DATA_DIR / "secret"))).expanduser()


def _migrate_legacy() -> list[str]:
    """Move the files of an older data folder (YYY/WWW/LLL/JJJ/TTT or a loose `secret/`) into XXX once. Never overwrites."""
    moved: list[str] = []
    import shutil
    sources = [(ROOT / n, DATA_DIR) for n in LEGACY_DATA_NAMES + ("TTT",)] + [(ROOT / "secret", SECRET_DIR)]
    for old, target in sources:
        if not old.is_dir() or old.resolve() == target.resolve() or old.resolve() == DATA_DIR.resolve():
            continue
        for f in sorted(old.rglob("*")):
            if not f.is_file():
                continue
            dst = target / f.relative_to(old)
            if dst.exists():
                continue
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), str(dst))
                moved.append(str(dst.relative_to(DATA_DIR)) if DATA_DIR in dst.parents else str(dst))
            except OSError:
                pass
        if not any(x.is_file() for x in old.rglob("*")):          # nothing left → remove the empty old folder
            shutil.rmtree(old, ignore_errors=True)
    return moved


for _d in (DATA_DIR, SECRET_DIR):
    _d.mkdir(parents=True, exist_ok=True)
_migrate_legacy()

HOST = os.getenv("TITAN_HOST", "127.0.0.1")
PORT = int(os.getenv("TITAN_PORT", "8080"))
VERSION = "2.1.1-NEON-STUDIO"

# ── indicators ─────────────────────────────────────────────────────────────
ADV_INDICATORS = os.getenv("TITAN_ADV", "1") != "0"

DEFAULT_COINS = [
    "BTC/USDT", "ETH/USDT", "BNB/USDT", "XRP/USDT", "SOL/USDT",
    "ADA/USDT", "DOGE/USDT", "AVAX/USDT", "LINK/USDT", "NEAR/USDT",
    "SUI/USDT", "TAO/USDT", "AAVE/USDT", "BCH/USDT", "XLM/USDT",
    "TRX/USDT", "SHIB/USDT", "PEPE/USDT", "WIF/USDT", "FLOKI/USDT",
    "CAKE/USDT", "HYPE/USDT", "ZEC/USDT", "XAUT/USDT",
]
SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,14}USDT$")


def to_symbol(coin: str) -> str:
    return str(coin).replace("/", "").replace("-", "").strip().upper()


def to_base(coin: str) -> str:
    c = str(coin).upper()
    if "/" in c:
        return c.split("/")[0]
    return c[:-4] if c.endswith("USDT") else c


def valid_symbol(sym: str) -> bool:
    return bool(SYMBOL_RE.match(to_symbol(sym)))


DEFAULT_SYMBOLS = [to_symbol(c) for c in DEFAULT_COINS]
MAX_WATCHLIST = 30

# ── timeframes ─────────────────────────────────────────────────────────────
TIMEFRAMES = ["15m", "1h", "4h", "1d"]
TF_PRIORITY = ["1h", "4h", "1d", "15m"]
TF_WEIGHT = {"15m": 0.15, "1h": 0.28, "4h": 0.32, "1d": 0.25}

KLINE_LIMIT = 300
CHART_KLINES = 220                # past candles shipped to the chart (each carries its open time)
FORECAST_CANDLES = 48             # future candles drawn for EVERY timeframe
EDGE_HORIZON = 16                 # bars used for the TP/SL first-passage statistics (trade horizon, not display horizon)
MC_PATHS = 400                  # Monte-Carlo paths (lighter than 600)
SIDE_THRESHOLD = 18.0

TF_SEC = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400}
TF_MS = {k: v * 1000 for k, v in TF_SEC.items()}
TF_FA = {"1m": "۱ دقیقه", "5m": "۵ دقیقه", "15m": "۱۵ دقیقه", "1h": "۱ ساعت", "4h": "۴ ساعت", "1d": "۱ روز"}
# how many bars of the signal's own timeframe a fresh signal / entry stays actionable
SIGNAL_VALID_BARS = {"15m": 6, "1h": 6, "4h": 4, "1d": 3}
ENTRY_VALID_BARS = {"15m": 2, "1h": 2, "4h": 1, "1d": 1}

# ── risk & paper / live readiness ──────────────────────────────────────────
STARTING_CAPITAL = 10_000.0
DEFAULT_LEVERAGE = 3
MAX_LEVERAGE = 10                    # conservative for real readiness
FEE_TAKER = 0.0006
FEE_MAKER = 0.0002
SLIPPAGE = 0.0005
RISK_PER_TRADE_PCT = 0.8
MAX_RISK_PCT_PER_TRADE = 1.5
MAX_OPEN_POSITIONS = 4
MAX_MARGIN_PCT_PER_POS = 20.0
MAX_TOTAL_MARGIN_PCT = 50.0
DAILY_LOSS_LIMIT_PCT = 4.0
PARTIALS = (0.40, 0.35, 0.25)

# auto-trade gates (stricter for real readiness)
AUTO_MIN_CONF = 62.0
AUTO_MIN_RR = 1.6
AUTO_COOLDOWN_SEC = 240
AUTO_MIN_GRADE = "B"

# ── scan & network ─────────────────────────────────────────────────────────
SCAN_INTERVAL_SEC = 45
CPU_WORKERS = int(os.getenv("TITAN_CPU_WORKERS", "4"))
CONNECT_TIMEOUT = 1.2
READ_TIMEOUT = 2.6
RACE_BUDGET = 4.0
SOURCE_ORDER = ["okx", "mexc", "bybit", "gate", "binance"]

# ── Gemini only (no other AI providers) ────────────────────────────────────
GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-flash-latest",
]
AI_TIMEOUT_SEC = 12

# ── storage limits (keep memory light) ─────────────────────────────────────
SIGLOG_MAX = 400                 # max signal log entries kept
PAPER_HISTORY_MAX = 300          # max closed trades kept
EQUITY_LOG_MAX = 400
ALERTS_MAX = 80
CACHE_MAX_SYMBOLS = 40
