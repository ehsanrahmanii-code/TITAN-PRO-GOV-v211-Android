"""Forward-test evaluation: is there statistical evidence that this system makes money AFTER costs?

Reads only what the app recorded itself (XXX/paper_state.json trades and XXX/siglog.json signal outcomes) and answers with
numbers that do not flatter: sample size, mean R, t-stat, bootstrap 95 % CI, profit factor, max drawdown in R and a verdict.
The verdict can never be "ready for real money" - the best label is a candidate for a TINY live trial.

It also feeds back into decisions (self-correction): `track_gate()` blocks automatic trading for a grade/side whose OWN forward
record is clearly negative.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

COST_PCT = 0.12            # round-trip fee + slippage assumption for directional signal returns (siglog)


def _stats(x: list[float]) -> dict:
    n = len(x)
    if n == 0:
        return {"n": 0}
    a = np.asarray(x, dtype=float)
    mean = float(a.mean())
    sd = float(a.std(ddof=1)) if n > 1 else 0.0
    t = mean / (sd / math.sqrt(n)) if sd > 0 else 0.0
    gp, gl = float(a[a > 0].sum()), float(-a[a < 0].sum())
    pf = gp / gl if gl > 0 else (99.0 if gp > 0 else 0.0)
    ci = [None, None]
    if n >= 8:
        rng = np.random.default_rng(7)
        bs = rng.choice(a, size=(1000, n), replace=True).mean(axis=1)
        ci = [round(float(np.percentile(bs, 2.5)), 3), round(float(np.percentile(bs, 97.5)), 3)]
    eq = np.cumsum(a)
    dd = float((np.maximum.accumulate(eq) - eq).max()) if n else 0.0
    streak = cur = 0
    for v in a:
        cur = cur + 1 if v <= 0 else 0
        streak = max(streak, cur)
    return {"n": n, "mean": round(mean, 3), "sd": round(sd, 3), "t": round(t, 2), "win": round(float((a > 0).mean() * 100), 1), "pf": round(pf, 2),
            "ci95": ci, "max_dd": round(dd, 2), "worst_streak": streak, "total": round(float(a.sum()), 2)}


def verdict(st: dict) -> dict:
    n, t, mean, pf, dd, ci = st.get("n", 0), st.get("t", 0.0), st.get("mean", 0.0), st.get("pf", 0.0), st.get("max_dd", 0.0), st.get("ci95") or [None, None]
    if n < 30:
        return {"level": "insufficient", "fa": "نمونه ناکافی", "why": f"فقط {n} معامله بسته؛ حداقل ۳۰ برای هر قضاوتی و ۱۰۰ برای تصمیم جدی لازم است."}
    if mean <= 0 or t < 1.0:
        return {"level": "not_ready", "fa": "شواهد سودآوری وجود ندارد", "why": f"میانگین {mean:+.2f}R با t={t:+.1f} از نویز قابل تشخیص نیست."}
    if n >= 100 and t >= 2.0 and (ci[0] or 0) > 0 and pf >= 1.3 and dd <= 10:
        return {"level": "candidate", "fa": "کاندید آزمایش زندهٔ بسیار کوچک", "why": f"{n} معامله، میانگین {mean:+.2f}R، t={t:.1f}، PF {pf}، حداکثر افت {dd}R؛ هنوز تضمین نیست."}
    return {"level": "promising", "fa": "امیدوارکننده ولی ناکافی", "why": f"میانگین {mean:+.2f}R و t={t:.1f}؛ برای جدی‌گرفتن به ≥۱۰۰ معامله و t≥۲ نیاز است."}


def _paper_r() -> list[dict]:
    try:
        from app.exchange import paper
        return [h for h in paper.history_all() if h.get("risk_usd")]
    except Exception:                                         # noqa: BLE001
        return []


def _siglog_rows() -> list[dict]:
    try:
        from app.engine import siglog
        return siglog.entries_copy()
    except Exception:                                         # noqa: BLE001
        return []


def assess() -> dict:
    trades = _paper_r()
    rs = [float(t["r"]) for t in trades]
    total = _stats(rs)
    by_grade, by_side, by_reason = defaultdict(list), defaultdict(list), defaultdict(list)
    for t in trades:
        by_grade[t.get("grade") or "—"].append(float(t["r"]))
        by_side[t.get("side") or "?"].append(float(t["r"]))
        by_reason[t.get("reason") or "?"].append(float(t["r"]))
    sig = _siglog_rows()
    sg: dict = {}
    for h in ("1h", "4h", "24h"):
        mv = [(float(e["res"][h]) - COST_PCT) for e in sig if h in (e.get("res") or {})]
        sg[h] = _stats(mv)
    path = [e["hit"] for e in sig if e.get("hit")]
    tp1, sl = path.count("TP1"), path.count("SL")
    return {"paper": {"stats": total, "verdict": verdict(total),
                      "by_grade": {k: _stats(v) for k, v in sorted(by_grade.items())}, "by_side": {k: _stats(v) for k, v in by_side.items()},
                      "by_reason": {k: _stats(v) for k, v in by_reason.items()}},
            "signals": {"horizon_after_costs_pct": sg, "path": {"tp1": tp1, "sl": sl, "p_tp1": round(tp1 / (tp1 + sl), 3) if tp1 + sl else None},
                        "n": len(sig), "cost_pct": COST_PCT},
            "rules": "معیار پذیرش: ≥۱۰۰ معامله بسته، میانگین R مثبت پس از هزینه، t≥۲، کران پایین بازه ۹۵٪ بالای صفر، PF≥۱٫۳. حتی در این حالت فقط آزمایش زنده با مبلغ بسیار کوچک و بدون اهرم."}


def track_gate(grade: str, side: str, min_n: int = 15) -> tuple[bool, str]:
    """Self-correction: block auto-trading for a grade (or side) whose own forward record is clearly negative."""
    trades = _paper_r()
    for label, rows in ((f"درجه {grade}", [float(t["r"]) for t in trades if (t.get("grade") or "—") == grade]),
                        (f"جهت {side}", [float(t["r"]) for t in trades if t.get("side") == side])):
        st = _stats(rows)
        if st["n"] >= min_n and st["mean"] < -0.25 and st["t"] <= -1.0:
            return False, f"کارنامهٔ زندهٔ {label}: {st['n']} معامله، میانگین {st['mean']:+.2f}R (t {st['t']:+.1f}) → متوقف"
    return True, ""
