"""TITAN PRO Clean — Central Governor (PRO V84 logic + V84.3 hardened gates).

Single decision authority:
  upstream modules = evidence only
  Governor = sole publisher of LONG / SHORT / WAIT

Improvements from full TITAN PRO V84 (edge_lab / canonical / evidence fusion):
  - Asymmetric SHORT thresholds (shorts need stronger edge & margin)
  - Higher data_trust & pattern weights (calibrated PRO defaults)
  - Independent support count + contradiction score
  - Min independent confirmations before publish
  - Confidence formula that penalizes contradiction and low support
  - Regime / structure soft conflict awareness
  - x10 quality + timing gates retained and tightened

Fast, pure-python, no heavy runtime layers or DB learning loop.
"""
from __future__ import annotations
from typing import Any

try:
    from app.engine import learn as _learn
except Exception:  # noqa: BLE001
    _learn = None
try:
    from app.analysis import smc as _smc
except Exception:  # noqa: BLE001
    _smc = None

VERSION = "PRO-CLEAN-GOVERNOR-1.7.2-UI-OVERLAP-SMC"

# Calibrated from PRO V84 central_governor + edge_lab defaults
# (htf best; ltf/forecast weaker; data_trust high)
WEIGHTS = {
    "htf_trend": 1.55,      # 4h + 1d direction
    "mtf_setup": 1.05,      # 1h structure/setup
    "ltf_trigger": 0.55,    # 15m timing
    "momentum": 0.90,       # RSI / ADX / score strength
    "structure": 1.25,      # EMA stack, VWAP, regime
    "volume_flow": 0.70,    # x10 klinger/vortex + x11 rvol + force (raised)
    "derivatives": 0.85,    # funding / OI bias
    "pattern": 0.70,        # raised toward V84 (was 0.55)
    "forecast": 0.45,       # mild
    "context": 0.90,        # F&G, liq, crowd
    "x_layer": 0.75,        # x10 timing + x12 complementary (raised)
    "data_trust": 1.35,     # V84 weight
}

# Asymmetric thresholds (V84 edge_lab / central_governor style)
MIN_EDGE_LONG = 0.15
MIN_EDGE_SHORT = 0.18          # shorts require clearer edge
MIN_MARGIN = 0.09
MIN_MARGIN_SHORT = 0.12        # extra margin for shorts
MIN_TRUST = 52.0
MIN_SUPPORT = 2                # at least 2 independent evidence families must agree
MAX_CONTRADICTION = 0.62       # above this → force WAIT even if edge is ok
MIN_GRADE_FOR_PUBLISH = {"A", "B"}

# Strong evidence threshold for support/oppose counting
STRONG_EV = 0.18


def _clip(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _tf_side_score(side: str, score: float) -> float:
    """Map a TF signal to [-1, +1]."""
    s = (score or 0.0) / 100.0
    if side == "LONG":
        return _clip(max(0.05, s) if score > 0 else 0.15)
    if side == "SHORT":
        return _clip(min(-0.05, -abs(s)) if score < 0 else -0.15)
    return 0.0


def _evidence_from_tfs(sigs: dict[str, dict]) -> dict[str, float]:
    """Build HTF / MTF / LTF evidence from multi-TF signals."""
    def one(tf: str) -> float:
        s = sigs.get(tf) or {}
        return _tf_side_score(str(s.get("side") or "WAIT"), float(s.get("score") or 0.0))

    htf = 0.55 * one("1d") + 0.45 * one("4h")
    mtf = one("1h")
    ltf = one("15m")
    # hard HTF veto softener: if both 1d and 4h oppose mtf strongly, crush mtf
    if htf * mtf < 0 and abs(htf) > 0.25:
        mtf *= 0.25
    return {"htf_trend": _clip(htf), "mtf_setup": _clip(mtf), "ltf_trigger": _clip(ltf)}


def _momentum_ev(sigs: dict[str, dict]) -> float:
    vals = []
    for tf, s in sigs.items():
        ind = s.get("indicators") or {}
        rsi = ind.get("rsi")
        adx = ind.get("adx")
        score = float(s.get("score") or 0.0)
        v = score / 80.0
        if rsi is not None:
            if rsi >= 70:
                v -= 0.15
            elif rsi <= 30:
                v += 0.10 if score > 0 else -0.05
        if adx is not None and adx < 15:
            v *= 0.6  # weak trend
        vals.append(_clip(v))
    return sum(vals) / len(vals) if vals else 0.0


def _structure_ev(sigs: dict[str, dict]) -> float:
    """Regime + agreement across TFs."""
    sides = [str((s or {}).get("side") or "WAIT") for s in sigs.values()]
    long_n = sides.count("LONG")
    short_n = sides.count("SHORT")
    n = max(1, len(sides))
    if long_n == 0 and short_n == 0:
        return 0.0
    dominant = "LONG" if long_n >= short_n else "SHORT"
    agree = (long_n if dominant == "LONG" else short_n) / n
    base = (agree - 0.5) * 2.0  # 0.5→0, 1.0→1
    if dominant == "SHORT":
        base = -abs(base)
    # regime boost
    regimes = [str((s or {}).get("regime") or "") for s in sigs.values()]
    if regimes.count("trend") >= 2:
        base *= 1.15
    return _clip(base)


def _deriv_ev(ctx: dict | None) -> float:
    if not ctx:
        return 0.0
    v = 0.0
    # funding: positive funding → slight short bias (longs pay)
    fr = ctx.get("funding_pct")
    if fr is not None:
        try:
            fr = float(fr)
            if fr > 0.05:
                v -= min(0.35, fr / 20.0)
            elif fr < -0.02:
                v += min(0.30, abs(fr) / 15.0)
        except (TypeError, ValueError):
            pass
    oi = ctx.get("oi_chg_4h") or ctx.get("oi_chg_24h")
    if oi is not None:
        try:
            oi = float(oi)
            v += _clip(oi / 40.0, -0.25, 0.25)
        except (TypeError, ValueError):
            pass
    return _clip(v)


def _context_ev(ctx: dict | None) -> float:
    if not ctx:
        return 0.0
    bias = float(ctx.get("bias") or 0.0)
    return _clip(bias)


def _forecast_ev(fcs: dict[str, dict], side_hint: str) -> float:
    if not fcs:
        return 0.0
    votes = []
    for tf, f in fcs.items():
        d = str((f or {}).get("direction") or "").upper()
        if d in ("UP", "LONG", "BULL"):
            votes.append(1.0)
        elif d in ("DOWN", "SHORT", "BEAR"):
            votes.append(-1.0)
        else:
            votes.append(0.0)
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes) * 0.8)


def _data_trust(sigs: dict[str, dict], ctx: dict | None) -> float:
    """0..1 trust. Penalize missing TFs / bad liquidity / low coverage."""
    n = len(sigs)
    trust = min(1.0, n / 4.0) * 0.7 + 0.3
    if ctx is not None and ctx.get("liq_ok") is False:
        trust *= 0.75
    if ctx is not None and float(ctx.get("coverage") or 1.0) < 0.3:
        trust *= 0.85
    # extra penalty if primary TF missing
    if "1h" not in sigs and "4h" not in sigs:
        trust *= 0.80
    return max(0.0, min(1.0, trust))


def _primary_sig(sigs: dict[str, dict]) -> dict:
    for tf in ("1h", "4h", "15m", "1d"):
        if tf in sigs and isinstance(sigs[tf], dict):
            return sigs[tf]
    return next(iter(sigs.values()), {}) if sigs else {}


def _x10_quality(sigs: dict[str, dict]) -> float | None:
    s = _primary_sig(sigs)
    x = ((s.get("extras") or {}).get("x10") or {})
    q = x.get("quality")
    try:
        return float(q) if q is not None else None
    except (TypeError, ValueError):
        return None


def _volume_flow_ev(sigs: dict[str, dict]) -> float:
    """From x10 klinger/vortex + x11 rvol — real participation, not zero placeholder."""
    s = _primary_sig(sigs)
    ex = s.get("extras") or {}
    x10 = (ex.get("x10") or {}).get("items") or {}
    x11 = (ex.get("x11") or {}).get("items") or {}
    votes = []
    for k in ("klinger", "vortex"):
        it = x10.get(k) or {}
        if it.get("s") is not None:
            votes.append(float(it["s"]))
    rvol = x11.get("rvol") or {}
    if rvol.get("s") is not None:
        votes.append(float(rvol["s"]) * 0.8)
    # force index from x12
    x12 = (ex.get("x12") or {}).get("items") or {}
    if (x12.get("force") or {}).get("s") is not None:
        votes.append(float(x12["force"]["s"]) * 0.7)
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes))


def _pattern_ev(sigs: dict[str, dict]) -> float:
    s = _primary_sig(sigs)
    ps = ((s.get("extras") or {}).get("pat") or {})
    sc = ps.get("score")
    try:
        sc = float(sc)
    except (TypeError, ValueError):
        return 0.0
    return _clip(sc / 100.0)


def _x_layer_ev(sigs: dict[str, dict]) -> float:
    """Blend x10 timing (direction-aware strength) and x12 complementary score."""
    s = _primary_sig(sigs)
    ex = s.get("extras") or {}
    x10 = ex.get("x10") or {}
    x12 = ex.get("x12") or {}
    votes = []
    try:
        timing = float(x10.get("timing") or 0.0)
        votes.append(_clip(timing / 100.0))
    except (TypeError, ValueError):
        pass
    try:
        flow = float(x10.get("flow") or 0.0)
        votes.append(_clip(flow / 100.0) * 0.6)
    except (TypeError, ValueError):
        pass
    try:
        sc12 = float(x12.get("score") or 0.0)
        votes.append(_clip(sc12 / 100.0))
    except (TypeError, ValueError):
        pass
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes))


def _support_and_contradiction(ev: dict[str, float], side: str) -> tuple[int, int, float]:
    """Count independent strong evidence families for/against candidate side.

    Returns (support_count, oppose_count, contradiction_score 0..1).
    """
    if side not in ("LONG", "SHORT"):
        return 0, 0, 0.0
    support = 0
    oppose = 0
    families = (
        "htf_trend", "mtf_setup", "ltf_trigger", "momentum", "structure",
        "volume_flow", "derivatives", "pattern", "context", "x_layer",
    )
    for k in families:
        v = float(ev.get(k, 0.0) or 0.0)
        if abs(v) < STRONG_EV:
            continue
        agrees = (v > 0 and side == "LONG") or (v < 0 and side == "SHORT")
        if agrees:
            support += 1
        else:
            oppose += 1
    total = support + oppose
    contrad = (oppose / total) if total > 0 else 0.0
    return support, oppose, contrad


def govern(
    sigs: dict[str, dict],
    fcs: dict[str, dict] | None = None,
    ctx: dict | None = None,
    grade: dict | None = None,
    symbol: str | None = None,
) -> dict[str, Any]:
    """Central decision.

    Returns published side, edge, margin, trust, components, reasons, vetoes,
    plus support / contradiction diagnostics (V84-style).
    """
    fcs = fcs or {}
    grade = grade or {}
    ev: dict[str, float] = {}
    ev.update(_evidence_from_tfs(sigs))
    ev["momentum"] = _momentum_ev(sigs)
    ev["structure"] = _structure_ev(sigs)
    ev["volume_flow"] = _volume_flow_ev(sigs)
    ev["derivatives"] = _deriv_ev(ctx)
    ev["pattern"] = _pattern_ev(sigs)
    ev["forecast"] = _forecast_ev(fcs, "")
    ev["context"] = _context_ev(ctx)
    ev["x_layer"] = _x_layer_ev(sigs)
    trust = _data_trust(sigs, ctx)
    # quality from x10: choppy markets reduce trust
    q = _x10_quality(sigs)
    if q is not None:
        trust *= 0.75 + 0.25 * (q / 100.0)
    ev["data_trust"] = (trust - 0.5) * 2.0  # map to [-1,1] contribution channel

    # Weighted edge in [-1, +1] — optional soft tilt from lightweight learning
    weights = dict(WEIGHTS)
    if _learn is not None:
        try:
            weights = _learn.apply_tilts(weights)
        except Exception:  # noqa: BLE001
            pass
    num = 0.0
    den = 0.0
    for k, w in weights.items():
        if k not in ev:
            continue
        num += w * float(ev[k])
        den += w
    edge = (num / den) if den else 0.0
    edge = _clip(edge)

    # Long vs short scores for margin
    long_score = max(0.0, edge)
    short_score = max(0.0, -edge)
    margin = abs(long_score - short_score)

    side = "WAIT"
    reasons: list[str] = []
    vetoes: list[str] = []

    # Publish gates — asymmetric (V84)
    long_ok = edge >= MIN_EDGE_LONG and margin >= MIN_MARGIN and trust * 100 >= MIN_TRUST
    short_ok = edge <= -MIN_EDGE_SHORT and margin >= MIN_MARGIN_SHORT and trust * 100 >= MIN_TRUST

    if long_ok:
        side = "LONG"
        reasons.append(f"لبه صعودی {edge:+.2f} با حاشیه {margin:.2f}")
    elif short_ok:
        side = "SHORT"
        reasons.append(f"لبه نزولی {edge:+.2f} با حاشیه {margin:.2f}")
    else:
        if abs(edge) < (MIN_EDGE_LONG if edge >= 0 else MIN_EDGE_SHORT):
            vetoes.append(f"لبه ناکافی ({edge:+.2f})")
        need_m = MIN_MARGIN if edge >= 0 else MIN_MARGIN_SHORT
        if margin < need_m:
            vetoes.append(f"حاشیه کم ({margin:.2f} < {need_m})")
        if trust * 100 < MIN_TRUST:
            vetoes.append(f"اعتماد داده پایین ({trust*100:.0f})")

    # Independent support + contradiction (from V84 Canonical / Evidence Fusion)
    support, oppose, contrad = _support_and_contradiction(ev, side)
    if side != "WAIT":
        if support < MIN_SUPPORT:
            vetoes.append(f"پشتیبانی مستقل ناکافی ({support} < {MIN_SUPPORT})")
            side = "WAIT"
        elif contrad >= MAX_CONTRADICTION:
            vetoes.append(f"تضاد شواهد بالا ({contrad:.0%})")
            side = "WAIT"
        else:
            if support >= 4:
                reasons.append(f"پشتیبانی قوی ({support} خانواده)")
            elif support >= 3:
                reasons.append(f"پشتیبانی خوب ({support})")

    # Grade gate
    g = str(grade.get("grade") or "")
    if side != "WAIT" and g and g not in MIN_GRADE_FOR_PUBLISH:
        vetoes.append(f"درجه {g} برای انتشار کافی نیست")
        side = "WAIT"

    # Soft RR / friction awareness (validated_decisions spirit, no hard DB)
    # If grade carries an effective R:R and it is weak while edge is only moderate → WAIT
    try:
        rr = float(grade.get("rr") or 0.0)
    except (TypeError, ValueError):
        rr = 0.0
    if side != "WAIT" and rr > 0 and rr < 1.25 and abs(edge) < 0.30:
        vetoes.append(f"R:R ضعیف ({rr:.2f}) با لبه متوسط")
        side = "WAIT"
    if side != "WAIT" and rr > 0 and rr < 1.08:
        vetoes.append(f"R:R زیر کف قابل قبول ({rr:.2f})")
        side = "WAIT"

    # Soft same-side overlap / cooldown (V84 edge_lab spirit via siglog)
    if side != "WAIT" and _learn is not None and symbol:
        try:
            ov = _learn.same_side_overlap(symbol, side)
            if not ov.get("ok", True):
                vetoes.append(str(ov.get("reason") or "همپوشانی همان‌سمت"))
                side = "WAIT"
        except Exception:  # noqa: BLE001
            pass

    # BTC correlation filter (V84 technicals_core — high-vol high-beta alts)
    if side != "WAIT" and _smc is not None and ctx and symbol:
        try:
            bf = _smc.apply_btc_filter(
                symbol,
                side,
                float(ctx.get("atr_pct") or 0.0),
                str(ctx.get("btc_side") or "WAIT"),
                ctx.get("btc_corr") if isinstance(ctx.get("btc_corr"), dict) else None,
            )
            if bf.get("blocked"):
                vetoes.append(str(bf.get("reason") or "فیلتر همبستگی BTC"))
                side = "WAIT"
        except Exception:  # noqa: BLE001
            pass

    # Context hard veto
    if side != "WAIT" and ctx:
        bias = float(ctx.get("bias") or 0.0)
        if side == "LONG" and bias <= -0.55:
            vetoes.append("بافت بازار به‌شدت مخالف LONG")
            side = "WAIT"
        if side == "SHORT" and bias >= 0.55:
            vetoes.append("بافت بازار به‌شدت مخالف SHORT")
            side = "WAIT"
        if ctx.get("liq_ok") is False and abs(edge) < 0.35:
            vetoes.append("نقدینگی ضعیف")
            side = "WAIT"

    # HTF hard oppose
    htf = ev.get("htf_trend", 0.0)
    if side == "LONG" and htf <= -0.30:
        vetoes.append("تایم‌فریم بزرگ مخالف LONG")
        side = "WAIT"
    if side == "SHORT" and htf >= 0.30:
        vetoes.append("تایم‌فریم بزرگ مخالف SHORT")
        side = "WAIT"

    # Structure/regime soft conflict (inspired by V84 soft weights)
    struct = ev.get("structure", 0.0)
    if side == "LONG" and struct <= -0.35 and abs(edge) < 0.32:
        vetoes.append("ساختار/رژیم مخالف LONG")
        side = "WAIT"
    if side == "SHORT" and struct >= 0.35 and abs(edge) < 0.32:
        vetoes.append("ساختار/رژیم مخالف SHORT")
        side = "WAIT"

    # x10 quality gate — do not publish trend trades in pure chop
    if side != "WAIT" and q is not None and q < 28:
        vetoes.append(f"کیفیت بازار پایین (x10={q:.0f}) → سیگنال روندی معتبر نیست")
        side = "WAIT"

    # timing conflict: strong opposite timing from x10 → WAIT on weak edge
    s1 = _primary_sig(sigs)
    try:
        timing = float(((s1.get("extras") or {}).get("x10") or {}).get("timing") or 0.0)
    except (TypeError, ValueError):
        timing = 0.0
    if side == "LONG" and timing <= -40 and abs(edge) < 0.28:
        vetoes.append(f"زمان‌بندی ورود مخالف LONG (timing={timing:.0f})")
        side = "WAIT"
    if side == "SHORT" and timing >= 40 and abs(edge) < 0.28:
        vetoes.append(f"زمان‌بندی ورود مخالف SHORT (timing={timing:.0f})")
        side = "WAIT"

    # Confidence (V84 Canonical style: edge + trust + support − contradiction − quality)
    conf = (
        abs(edge) * 100 * 0.55
        + trust * 22
        + support * 5.5
        - oppose * 3.5
        - contrad * 22
        + abs(ev.get("x_layer", 0)) * 10
    )
    conf = max(0.0, min(95.0, conf))
    if side == "WAIT":
        conf = min(conf, 48.0)
    elif q is not None:
        conf = min(95.0, conf * (0.82 + 0.18 * (q / 100.0)))
    # timing alignment boost
    if side == "LONG" and timing >= 25:
        conf = min(95.0, conf + 4)
        reasons.append(f"زمان‌بندی x10 هم‌جهت ({timing:.0f})")
    elif side == "SHORT" and timing <= -25:
        conf = min(95.0, conf + 4)
        reasons.append(f"زمان‌بندی x10 هم‌جهت ({timing:.0f})")

    # Component breakdown for UI
    components = {k: round(float(ev.get(k, 0.0)), 3) for k in WEIGHTS}
    top = sorted(components.items(), key=lambda x: abs(x[1]), reverse=True)[:4]
    for k, v in top:
        if abs(v) >= 0.12:
            reasons.append(f"{k}: {v:+.2f}")

    return {
        "version": VERSION,
        "side": side,
        "edge": round(edge, 4),
        "margin": round(margin, 4),
        "trust": round(trust * 100, 1),
        "confidence": round(conf, 1),
        "support": support,
        "oppose": oppose,
        "contradiction": round(contrad, 3),
        "components": components,
        "reasons": reasons[:7],
        "vetoes": vetoes[:7],
        "published": side in ("LONG", "SHORT"),
    }
