"""Background multi-TF scanner. Non-blocking (thread), bulk tickers, shared closed-candle
frame cache (deep analysis never refetches), wick-aware paper-exchange marking."""
from __future__ import annotations
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from app import settings
from app.config import (TIMEFRAMES, TF_PRIORITY, KLINE_LIMIT, CHART_KLINES, CPU_WORKERS, FORECAST_CANDLES, SCAN_INTERVAL_SEC, to_base, to_symbol)
from app.data.market import fetch_klines, fetch_tickers, closed_only, source_status
from app.analysis.technicals import analyze
from app.analysis.forecast import build_forecast, _last_open_ms
from app.analysis.deep import deep_analyze
from app.analysis.grade import fuse, grade_from
from app.analysis import patterns as pat
from app.engine import alerts, evidence, siglog, context, readiness, lessons
from app.engine import learn as learn_mod
from app.analysis import smc as smc_mod
from app.engine.decision import final_voice
from app.engine.governor import govern
from app.analysis import pro_core
from app.analysis import forecast as fc_mod, planner
from app.exchange import policy
from app import core
import numpy as np
import pandas as pd
from app.exchange import paper as exchange

_CACHE: dict[str, dict] = {}
_FRAMES: dict[str, object] = {}
_TICKERS: dict[str, dict] = {}
_LOCK = threading.RLock()
_S = {"scanning": False, "last_scan": 0.0, "duration": 0.0, "errors": [], "progress": {"done": 0, "total": 0, "ok": 0, "err": 0}}
_IV_MS = {"15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000}


def _key(sym: str, tf: str) -> str:
    return f"{sym.upper()}:{tf}"


def _round6(v):
    return float(f"{v:.6g}")


def _kl_list(full) -> list:
    return [{"t": int(t.timestamp() * 1000), "o": float(o), "h": float(h), "l": float(l), "c": float(c), "v": float(v)}
            for t, o, h, l, c, v in full.tail(CHART_KLINES)[["open_time", "open", "high", "low", "close", "volume"]].itertuples(index=False)]


def _reusable(prev: dict | None, last_open: int, live: float) -> bool:
    """The expensive analysis only depends on the CLOSED candles and (weakly) on the live price: reuse it while the same
    candle is the newest closed one and price has not moved more than 0.15 ATR since it was computed (max 15 min)."""
    if not prev or "signal" not in prev or prev.get("last_closed_open") != last_open:
        return False
    atr = float(((prev["signal"].get("indicators") or {}).get("atr")) or 0)
    px0 = prev.get("live_px")
    if not atr or not px0 or time.time() - prev.get("analysed", 0) > 900:
        return False
    return abs(live - px0) <= 0.15 * atr


def _scan_one(sym: str, tf: str, ticker: dict | None) -> dict:
    t0 = time.time()
    try:
        full = fetch_klines(sym, tf, KLINE_LIMIT)
        df = closed_only(full, tf)
        live = (ticker or {}).get("price") or float(full["close"].iloc[-1])
        tk = ticker or {"symbol": sym, "price": live, "change_pct": 0.0, "high": 0, "low": 0, "volume": 0, "quote_volume": 0}
        last_open = _last_open_ms(df)
        with _LOCK:
            prev = _CACHE.get(_key(sym, tf))
            _FRAMES[_key(sym, tf)] = df
        stale = bool(full.attrs.get("stale") or df.attrs.get("stale"))
        forming = int(full["open_time"].iloc[-1].timestamp() * 1000)
        if _reusable(prev, last_open, live):
            core.record("analysis", (time.time() - t0) * 1000, True)
            it = dict(prev)
            it.update(ticker=tk, klines=_kl_list(full), updated=time.time(), forming_open=forming, stale=stale, reused=True)
            return it
        sig = analyze(df, sym, tf, price=live)
        lv = {"entry": sig.entry, "stop": sig.stop, "tp1": sig.tp1, "tp2": sig.tp2, "tp3": sig.tp3} if sig.side != "WAIT" else None
        fc = build_forecast(df, sig.side, tf, sym, lv)                       # 48 candles, each with open/close time
        sd = sig.to_dict()
        sd["timing"] = fc.get("timing")
        core.record("analysis", (time.time() - t0) * 1000, True)
        return {"signal": sd, "forecast": fc, "ticker": tk, "klines": _kl_list(full), "updated": time.time(), "tf": tf, "live_px": live,
                "analysed": time.time(), "last_closed_open": last_open, "forming_open": forming, "stale": stale, "reused": False}
    except Exception as e:                                   # noqa: BLE001
        core.record("analysis", (time.time() - t0) * 1000, False, str(e))
        return {"error": str(e)[:160], "symbol": sym, "timeframe": tf}


def scan_one(sym: str, tf: str, ticker: dict | None = None) -> dict:
    """Public single (symbol, timeframe) analysis; raises on failure (used by the API for on-demand coins)."""
    res = _scan_one(sym, tf, ticker)
    if "error" in res:
        raise RuntimeError(res["error"])
    return res


def _range_fn(sym: str, since: float, opened_at: float):
    for tf in ("15m", "1h"):
        item = _CACHE.get(_key(sym, tf))
        if not item or "klines" not in item:
            continue
        ms, o_ms = _IV_MS[tf], opened_at * 1000
        sel = [k for k in item["klines"] if k["t"] >= o_ms and k["t"] + ms > since * 1000]
        if sel:
            return min(k["l"] for k in sel), max(k["h"] for k in sel)
    return None


def get_frames(sym: str) -> dict:
    with _LOCK:
        return {tf: _FRAMES.get(_key(sym, tf)) for tf in TIMEFRAMES if _FRAMES.get(_key(sym, tf)) is not None}


_DEEP: dict = {}
_SNAP = None


def _snap_path():
    from app.config import DATA_DIR
    return DATA_DIR / "snapshot.json.gz"


def save_snapshot() -> None:
    """Persist the scan cache in XXX so the dashboard is full the instant the app starts (and analysis can be reused)."""
    import gzip, json, os
    with _LOCK:
        items = {k: v for k, v in _CACHE.items() if isinstance(v, dict) and "signal" in v}
        payload = {"ts": time.time(), "last_scan": _S["last_scan"], "items": items}
    tmp = _snap_path().with_suffix(".tmp")
    with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=3) as f:
        json.dump(payload, f, default=lambda o: float(o) if hasattr(o, "__float__") else str(o), ensure_ascii=False)
    os.replace(tmp, _snap_path())


def load_snapshot() -> int:
    import gzip, json
    try:
        with gzip.open(_snap_path(), "rt", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception:                                            # noqa: BLE001
        return 0
    n = 0
    wl = set(settings.get_watchlist())
    with _LOCK:
        for k, v in (payload.get("items") or {}).items():
            if k.split(":")[0] in wl and k not in _CACHE:
                v["restored"] = True
                _CACHE[k] = v
                n += 1
        if n and not _S["last_scan"]:
            _S["last_scan"] = float(payload.get("last_scan") or payload.get("ts") or 0)
    if n:
        core.log("info", "storage", f"{n} نتیجهٔ آخرین اسکن از XXX بازیابی شد (نمایش فوری)")
    return n


def _gen(sym: str) -> tuple:
    """Fingerprint of everything a deep analysis of `sym` depends on (scan items + market context)."""
    with _LOCK:
        return tuple((_CACHE.get(_key(sym, tf)) or {}).get("updated") for tf in TIMEFRAMES) + (id(context.get(sym)),)


def build_deep(sym: str, primary_tf: str = "1h", fetch_missing: bool = True) -> dict:
    sym = to_symbol(sym)
    gen = _gen(sym)
    hit = _DEEP.get((sym, primary_tf))
    if hit and hit[0] == gen and gen[0] is not None:                  # nothing changed since the last computation
        d = dict(hit[1])
        d["now"] = int(time.time() * 1000)
        return d
    frames = get_frames(sym)
    if fetch_missing:
        for tf in TIMEFRAMES:
            if tf not in frames:
                try:
                    frames[tf] = closed_only(fetch_klines(sym, tf, KLINE_LIMIT), tf)
                except Exception:                            # noqa: BLE001
                    pass
    prices = {tf: (_CACHE.get(_key(sym, tf)) or {}).get("ticker", {}).get("price") for tf in TIMEFRAMES}
    live = next((p for p in prices.values() if p), None)
    with _LOCK:
        pre_s = {tf: _CACHE[_key(sym, tf)]["signal"] for tf in frames if _key(sym, tf) in _CACHE and "signal" in _CACHE[_key(sym, tf)]}
        pre_f = {tf: _CACHE[_key(sym, tf)].get("forecast") or {} for tf in pre_s}
    _t0 = time.time()
    d = deep_analyze(frames, sym, primary_tf, {tf: live for tf in frames} if live else None, ctx=context.get(sym), pre_sigs=pre_s, pre_fcs=pre_f)
    core.record("governor", (time.time() - _t0) * 1000, True)
    if d.get("verdict") in ("LONG", "SHORT"):
        d["active"] = siglog.active_entry(sym, d["verdict"])           # when this verdict went live (time of the logged signal)
    d["now"] = int(time.time() * 1000)
    if len(pre_s) == len(TIMEFRAMES):
        if len(_DEEP) > 400:
            _DEEP.clear()
        _DEEP[(sym, primary_tf)] = (gen, d)
    return d


def _run(symbols: list[str], tfs: list[str]) -> None:
    t0 = time.time()
    core.log("info", "scanner", f"اسکن {len(symbols)} ارز × {len(tfs)} تایم‌فریم شروع شد")
    try:
        tickers = fetch_tickers(symbols, max_age=5)
        with _LOCK:
            _TICKERS.update(tickers)
        order = sorted(tfs, key=lambda t: TF_PRIORITY.index(t) if t in TF_PRIORITY else 9)
        tasks = [(s, tf) for tf in order for s in symbols]
        with ThreadPoolExecutor(max_workers=max(CPU_WORKERS, 8)) as ex:
            futs = {ex.submit(_scan_one, s, tf, tickers.get(s)): (s, tf) for s, tf in tasks}
            for fut in as_completed(futs):
                s, tf = futs[fut]
                res = fut.result()
                with _LOCK:
                    p = _S["progress"]
                    p["done"] += 1
                    if "error" in res:
                        p["err"] += 1
                        _S["errors"] = ([f"{s} {tf}: {res['error']}"] + _S["errors"])[:12]
                    else:
                        p["ok"] += 1
                        _CACHE[_key(s, tf)] = res
        core.guard("context", context.refresh, symbols, lambda sy: (tickers.get(sy) or {}).get("change_pct"))
        prices = {s: t["price"] for s, t in tickers.items()}
        for s in symbols:                                    # fall back to last candle for missing tickers
            if s not in prices:
                it = _CACHE.get(_key(s, "1h"))
                if it:
                    prices[s] = it["ticker"]["price"]
        try:
            core.guard("paper", exchange.mark_to_market, prices, _range_fn)
            core.guard("evidence", evidence.refresh_async, symbols)
            if exchange.is_auto() and core.enabled("auto"):
                core.guard("auto", _auto_pass, symbols, prices)
        except Exception as e:                               # noqa: BLE001
            with _LOCK:
                _S["errors"] = [f"exchange: {e}"] + _S["errors"][:11]
        try:
            core.guard("patterns", _refresh_pattern_stats, symbols)
            core.guard("alerts", alerts_tick)
            rows_ = {}
            for sy in symbols:
                r_ = _row_fusion(sy)
                if r_.get("verdict") in ("LONG", "SHORT") and siglog.is_new(sy, r_["verdict"]):
                    lv_ = (build_deep(sy, "1h", fetch_missing=False).get("signal") or {})
                    if lv_.get("side") == r_["verdict"]:
                        r_["stop"], r_["tp1"] = lv_.get("stop"), lv_.get("tp1")
                rows_[sy] = r_
            core.guard("siglog", siglog.tick, rows_, {sy: (_CACHE.get(_key(sy, '1h')) or {}).get('ticker', {}).get('price') for sy in symbols})
            core.guard("learn", learn_mod.refresh_from_siglog)
        except Exception as e:                               # noqa: BLE001
            with _LOCK:
                _S["errors"] = [f"patterns: {e}"] + _S["errors"][:11]
    finally:
        with _LOCK:
            _S.update(scanning=False, last_scan=time.time(), duration=round(time.time() - t0, 1))
        core.record("scanner", (time.time() - t0) * 1000, _S["progress"]["err"] <= _S["progress"]["total"] // 2, f"{_S['progress']['err']} خطا در اسکن")
        core.guard("storage", save_snapshot)


def start_scan(symbols=None, timeframes=None) -> dict:
    wl = settings.get_watchlist()
    symbols = [to_symbol(s) for s in (symbols or wl)]
    tfs = [t for t in (timeframes or TIMEFRAMES) if t in TIMEFRAMES]
    with _LOCK:
        if _S["scanning"]:
            return {"status": "busy", "progress": dict(_S["progress"])}
        _S["scanning"] = True
        _S["progress"] = {"done": 0, "total": len(symbols) * len(tfs), "ok": 0, "err": 0}
    threading.Thread(target=_run, args=(symbols, tfs), daemon=True, name="titan-scan").start()
    return {"status": "started", "progress": dict(_S["progress"])}


def wait_idle(timeout: float = 120) -> None:
    t0 = time.time()
    while _S["scanning"] and time.time() - t0 < timeout:
        time.sleep(0.05)


def get_cache_item(sym: str, tf: str) -> dict | None:
    with _LOCK:
        return _CACHE.get(_key(sym, tf))


def put_cache_item(sym: str, tf: str, item: dict) -> None:
    with _LOCK:
        _CACHE[_key(sym, tf)] = item


_PAT: dict = {}
_HOURS: dict = {}


def _refresh_pattern_stats(symbols) -> None:
    """Pool every past occurrence of each pattern over all watched coins, per timeframe (cheap: vectorised)."""
    new = {}
    for tf in TIMEFRAMES:
        frames = [_FRAMES[_key(s, tf)] for s in symbols if _key(s, tf) in _FRAMES]
        if frames:
            new[tf] = pat.pooled_stats(frames)
    hrs = {}
    fr = [_FRAMES[_key(s, "1h")] for s in symbols if _key(s, "1h") in _FRAMES]
    if fr:
        rng, vol, cnt = np.zeros(24), np.zeros(24), np.zeros(24)
        for df in fr:
            h = df["open_time"].dt.hour.values
            r = ((df["high"] - df["low"]) / df["close"]).values * 100
            v = df["volume"].values / (pd_mean(df["volume"]) or 1)
            for hh in range(24):
                m = h == hh
                rng[hh] += r[m].sum(); vol[hh] += v[m].sum(); cnt[hh] += m.sum()
        cnt = np.where(cnt == 0, 1, cnt)
        hrs = {"range": [round(float(x), 3) for x in rng / cnt], "vol": [round(float(x), 2) for x in vol / cnt], "n": int(cnt.sum())}
    with _LOCK:
        _PAT.clear(); _PAT.update(new); _HOURS.clear(); _HOURS.update(hrs)


def pd_mean(s):
    return float(s.tail(200).mean())


def pattern_stats(tf: str) -> dict:
    with _LOCK:
        return _PAT.get(tf, {})


def hour_stats() -> dict:
    with _LOCK:
        return dict(_HOURS)


def alerts_tick() -> list:
    syms = settings.get_watchlist()

    def price_of(sym):
        t = _TICKERS.get(sym)
        if t and t.get("price"):
            return t["price"]
        it = _CACHE.get(_key(sym, "1h"))
        return it["ticker"]["price"] if it and it.get("ticker") else None
    with _LOCK:
        pass
    return alerts.check(price_of, lambda s: _row_fusion(s), syms)


def _ohlc(item: dict, n=40):
    return [[_round6(k["o"]), _round6(k["h"]), _round6(k["l"]), _round6(k["c"])] for k in item.get("klines", [])[-n:]]


def _fcc(item: dict):
    return [[_round6(c["open"]), _round6(c["high"]), _round6(c["low"]), _round6(c["close"])] for c in ((item.get("forecast") or {}).get("candles") or [])]


def _spark(item: dict, n=36):
    cl = [k["c"] for k in item.get("klines", [])][-n:]
    return [_round6(c) for c in cl]


def _aligned_returns(a, b, n: int):
    """Log-returns of two frames joined on open_time (never on row position), last n+1 common bars."""
    m = a[["open_time", "close"]].merge(b[["open_time", "close"]], on="open_time", suffixes=("_a", "_b")).tail(n + 1)
    if len(m) < 40:
        return None, None
    return (np.diff(np.log(m["close_a"].values.astype(float))), np.diff(np.log(m["close_b"].values.astype(float))))


def _btc_stats(sym: str) -> dict:
    """Correlation / beta / 24-candle relative strength vs BTC on the 1h frame (None when unavailable)."""
    a, b = _FRAMES.get(_key(sym, "1h")), _FRAMES.get(_key("BTCUSDT", "1h"))
    if a is None or b is None or len(a) < 60 or len(b) < 60:
        return {}
    ra, rb = _aligned_returns(a, b, 120)
    if ra is None or ra.std() == 0 or rb.std() == 0:
        return {}
    if ra.std() < 1e-12 or rb.std() < 1e-12:
        return {}
    with np.errstate(invalid="ignore", divide="ignore"):
        corr = float(np.corrcoef(ra, rb)[0, 1])
        var_b = float(rb.var(ddof=1))
        beta = float(np.cov(ra, rb)[0, 1] / var_b) if var_b > 1e-18 else 0.0
    if corr != corr:  # NaN
        return {}
    return {"corr": round(corr, 2), "beta": round(beta, 2), "rs24": round(float((ra[-24:].sum() - rb[-24:].sum()) * 100), 2)}


def _row_fusion(sym: str, ptf: str = "1h") -> dict:
    sigs = {tf: _CACHE[_key(sym, tf)]["signal"] for tf in TIMEFRAMES if _key(sym, tf) in _CACHE and "signal" in _CACHE[_key(sym, tf)]}
    if not sigs:
        return {}
    fcs = {tf: _CACHE[_key(sym, tf)].get("forecast") or {} for tf in sigs}
    ctx = dict(context.get(sym) or {})
    # BTC correlation + side (lightweight V84 filter) when frames available
    try:
        if sym.upper().replace("/", "") not in ("BTCUSDT", "BTC"):
            btc_key = _key("BTCUSDT", "1h")
            alt_key = _key(sym, "1h")
            btc_df = _FRAMES.get(btc_key)
            alt_df = _FRAMES.get(alt_key)
            if btc_df is not None and alt_df is not None and len(btc_df) >= 30 and len(alt_df) >= 30:
                corr = smc_mod.btc_corr_from_closes(alt_df["close"], btc_df["close"])
                ctx["btc_corr"] = corr
                btc_sig = (_CACHE.get(btc_key) or {}).get("signal") or {}
                ctx["btc_side"] = btc_sig.get("side") or "WAIT"
                atr_pct = float((sigs.get(ptf) or sigs.get("1h") or {}).get("indicators", {}).get("atr_pct") or 0)
                ctx["atr_pct"] = atr_pct
    except Exception:
        pass
    cons, side_fuse, note = fuse({tf: x["score"] for tf, x in sigs.items()}, (ctx or {}).get("bias", 0.0))
    g = grade_from(sigs, fcs, side_fuse, cons, ptf if ptf in sigs else next(iter(sigs)), ctx)
    # PRO Central Governor = sole publisher
    _t0 = time.time()
    gov = govern(sigs, fcs, ctx, g if isinstance(g, dict) else {}, symbol=sym)
    core.record("governor", (time.time() - _t0) * 1000, True)
    side = gov["side"]
    voice = final_voice(
        side=side,
        consensus=cons,
        grade=g if isinstance(g, dict) else {},
        ctx=ctx,
        plan=None,
        gemini=None,
        readiness=None,
    )
    # Governor overrides fuse side when it vetoes
    if not gov.get("published"):
        side = "WAIT"
        voice["side"] = "WAIT"
        voice["action"] = "AVOID" if gov.get("vetoes") else "WAIT"
    cons_r = round(float(cons), 1)
    act = siglog.active_entry(sym, side) if side in ("LONG", "SHORT") else None
    return {
        "since": (act or {}).get("t"),
        "side": side,
        "verdict": side,                    # alias for siglog / matrix / auto
        "consensus": cons_r,
        "cons": cons_r,                     # alias
        "grade": (g.get("grade") if isinstance(g, dict) else None) or voice.get("grade"),
        "note": note or (g.get("note") if isinstance(g, dict) else None),
        "score": g.get("score") if isinstance(g, dict) else None,
        "rr": g.get("rr") if isinstance(g, dict) else None,
        "reasons": gov.get("reasons") or voice.get("reasons"),
        "vetoes": (gov.get("vetoes") or []) + (voice.get("vetoes") or []),
        "action": voice.get("action"),
        "confidence": gov.get("confidence") or voice.get("confidence"),
        "edge": gov.get("edge"),
        "margin": gov.get("margin"),
        "trust": gov.get("trust"),
        "support": gov.get("support"),
        "oppose": gov.get("oppose"),
        "contradiction": gov.get("contradiction"),
        "governor": gov.get("version"),
        "components": gov.get("components"),
        "ctx": (ctx or {}).get("bias"),
        "ctx_liq_ok": (ctx or {}).get("liq_ok", True),
    }


def get_matrix() -> dict:
    now = time.time()
    with _LOCK:
        m = {}
        for sym in settings.get_watchlist():
            row = {"symbol": sym, "base": to_base(sym), "tfs": {}, "ticker": None, "spark": [], "fc": None, "age": None}
            for tf in TIMEFRAMES:
                d = _CACHE.get(_key(sym, tf))
                if not d:
                    continue
                s, f = d["signal"], d.get("forecast") or {}
                ind, e = s.get("indicators") or {}, f.get("edge") or {}
                row["tfs"][tf] = {"side": s["side"], "score": s["score"], "confidence": s["confidence"], "entry": s["entry"],
                                  "stop": s["stop"], "tp1": s["tp1"], "tp2": s["tp2"], "tp3": s["tp3"], "rr": s["risk_reward"],
                                  "regime": s.get("regime"), "bias": s.get("bias"), "forecast": f.get("direction"),
                                  "move": f.get("expected_move_pct"), "prob_up": f.get("prob_up"), "rsi": ind.get("rsi"),
                                  "adx": ind.get("adx"), "atr_pct": ind.get("atr_pct"), "vol_ratio": ind.get("vol_ratio"),
                                  "squeeze": ind.get("squeeze"), "agree": s.get("agree"), "ev_r": e.get("ev_r"),
                                  "p_tp1": e.get("p_tp1"), "warns": len(s.get("warnings") or []),
                                  "quality": (s.get("levels") or {}).get("quality"), "timing": (s.get("levels") or {}).get("timing"),
                                  "valid_until": (s.get("timing") or {}).get("valid_until"), "as_of": (s.get("timing") or {}).get("as_of"),
                                  "name": (s.get("timing") or {}).get("tf")}
                if tf == "1h":
                    row["spark"] = _spark(d)
                    row["ohlc"], row["fcc"] = _ohlc(d), _fcc(d)
                    b = f.get("bands") or {}
                    if b:
                        row["fc"] = {k: [_round6(x) for x in b[k]] for k in ("p10", "p50", "p90")}
                    row["age"] = int(now - d["updated"])
                    row["stale"] = d.get("stale", False)
                if d.get("ticker") and (not row["ticker"] or tf == "1h"):
                    row["ticker"] = d["ticker"]
            fus = _row_fusion(sym) or {}
            if not fus.get("side"):
                fus.setdefault("side", "WAIT")
                fus.setdefault("grade", "—")
                fus.setdefault("action", "WAIT")
            row.update(fus)
            row.update(_btc_stats(sym))
            m[sym] = row
        return {"matrix": m, "timeframes": TIMEFRAMES, "at": _S["last_scan"], "scanning": _S["scanning"],
                "progress": dict(_S["progress"])}


def market_overview() -> dict:
    """Breadth, movers, volatility and correlation computed purely from the scan cache."""
    with _LOCK:
        syms = settings.get_watchlist()
        per_tf = {}
        for tf in TIMEFRAMES:
            n = a50 = a200 = lg = sh = 0
            rs, ad, sc = [], [], []
            for sym in syms:
                d = _CACHE.get(_key(sym, tf))
                if not d:
                    continue
                sg = d["signal"]; ind = sg.get("indicators") or {}
                px = (d.get("ticker") or {}).get("price") or sg["entry"]
                n += 1; a50 += px > ind.get("ema50", 1e99); a200 += px > ind.get("ema200", 1e99)
                lg += sg["side"] == "LONG"; sh += sg["side"] == "SHORT"
                rs.append(ind.get("rsi", 50)); ad.append(ind.get("adx", 0)); sc.append(sg["score"])
            if n:
                per_tf[tf] = {"n": n, "above50": round(a50 / n * 100), "above200": round(a200 / n * 100), "long": lg, "short": sh,
                              "rsi": round(float(np.mean(rs)), 1), "adx": round(float(np.mean(ad)), 1), "score": round(float(np.mean(sc)), 1)}
        rows = []
        for sym in syms:
            d = _CACHE.get(_key(sym, "1h"))
            if not d:
                continue
            tk, sg = d.get("ticker") or {}, d["signal"]
            fu = _row_fusion(sym)
            rows.append({"symbol": sym, "base": to_base(sym), "chg": tk.get("change_pct", 0), "qv": tk.get("quote_volume", 0),
                         "atr": (sg.get("indicators") or {}).get("atr_pct", 0), "cons": fu.get("cons", 0), "grade": fu.get("grade", "—"),
                         "verdict": fu.get("verdict", "WAIT"), "squeeze": (sg.get("indicators") or {}).get("squeeze", False),
                         "vol_pct": ((sg.get("extras") or {}).get("stats") or {}).get("vol_pct")})
        top_vol = sorted(rows, key=lambda r: -r["qv"])[:10]
        corr = {}
        names = [r["symbol"] for r in top_vol if _FRAMES.get(_key(r["symbol"], "1h")) is not None and len(_FRAMES[_key(r["symbol"], "1h")]) >= 100]
        if len(names) >= 3:
            wide = pd.concat({x: _FRAMES[_key(x, "1h")].set_index("open_time")["close"] for x in names}, axis=1).dropna().tail(101)
            if len(wide) >= 60:
                with np.errstate(all="ignore"):
                    c = np.nan_to_num(np.corrcoef(np.diff(np.log(wide.values.astype(float)), axis=0).T))
                corr = {"names": [to_base(x) for x in names], "m": [[round(float(v), 2) for v in row] for row in c]}
        avg_cons = float(np.mean([r["cons"] for r in rows])) if rows else 0.0
        return {"per_tf": per_tf, "gainers": sorted(rows, key=lambda r: -r["chg"])[:5], "losers": sorted(rows, key=lambda r: r["chg"])[:5],
                "volume": top_vol[:6], "volatile": sorted(rows, key=lambda r: -r["atr"])[:5], "squeeze": [r for r in rows if r["squeeze"]][:8],
                "best": sorted([r for r in rows if r["verdict"] != "WAIT"], key=lambda r: (-"DCBA".find(r["grade"]) if r["grade"] in "ABCD" else 9, -abs(r["cons"])))[:8],
                "corr": corr, "mood": int(max(0, min(100, 50 + avg_cons / 2))), "avg_cons": round(avg_cons, 1), "n": len(rows)}


def get_status() -> dict:
    with _LOCK:
        return {"cached": len(_CACHE), "last_scan": _S["last_scan"], "scanning": _S["scanning"], "duration": _S["duration"],
                "progress": dict(_S["progress"]), "errors": list(_S["errors"]), "sources": source_status()}


def start_background() -> None:
    def loop():
        core.guard("storage", load_snapshot)
        time.sleep(0.2)
        start_scan(None, ["1h"])
        wait_idle()
        start_scan()
        while True:
            time.sleep(settings.get_scan_sec())
            try:
                start_scan()
            except Exception:                                # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="titan-bg").start()


def _pair_corr(a: str, b: str) -> float:
    fa, fb = _FRAMES.get(_key(a, "1h")), _FRAMES.get(_key(b, "1h"))
    if fa is None or fb is None or len(fa) < 60 or len(fb) < 60:
        return 0.0
    ra, rb = _aligned_returns(fa, fb, 100)
    if ra is None or ra.std() == 0 or rb.std() == 0:
        return 0.0
    return float(np.corrcoef(ra, rb)[0, 1])


_LAST_LOG: dict = {}


def plan_lab(sym: str, tf: str, df, sig: dict, px: float) -> dict:
    """Entry/stop/target laboratory for both sides on one shared simulation (also used by /api/plan)."""
    ind, ex, zones = sig["indicators"], sig.get("extras") or {}, (sig.get("levels") or {}).get("zones", [])
    sim = fc_mod.simulate(df, 32, 600, f"{sym}{tf}")
    if not sim:
        return {}
    atr = float(ind["atr"]) or px * 0.01
    return {"long": planner.run(sim, "LONG", px, atr, ind, ex, zones), "short": planner.run(sim, "SHORT", px, atr, ind, ex, zones), "atr": atr, "price": px}


def make_snap(d: dict, px: float | None = None) -> dict:
    """The reasons a position is opened for (stored with it; used by the post-mortem and the mistake gate)."""
    sig = d.get("signal") or {}
    ind = sig.get("indicators") or {}
    ctx = d.get("ctx") or {}
    fc = d.get("forecast") or {}
    px = px or sig.get("entry") or 0
    atr = float(ind.get("atr") or 0) or (px * 0.01 if px else 1.0)
    side = d.get("verdict") if d.get("verdict") in ("LONG", "SHORT") else sig.get("side")
    dirn = 1 if side == "LONG" else -1
    return {"fams": {k: round(float(v), 3) for k, v in ((d.get("governor") or {}).get("components") or {}).items()},
            "cons": d.get("consensus_score"), "regime": d.get("regime"), "conviction": d.get("conviction"), "grade": (d.get("grade") or {}).get("grade"),
            "fc_prob_up": fc.get("prob_up"), "ctx_bias": ctx.get("bias"), "rsi": ind.get("rsi"), "agree": sig.get("agree"),
            "ext_atr": round((px - float(ind.get("ema21") or px)) * dirn / atr, 2) if px else None,
            "quality": (sig.get("levels") or {}).get("quality"), "hour_utc": time.gmtime().tm_hour, "tf": d.get("primary_tf", "1h")}


def _auto_pass(symbols, prices) -> None:
    cfg = policy.effective()
    ps = exchange.pause_state(prices)
    if ps["paused"]:
        if _LAST_LOG.get("*") != ps["reason"]:
            _LAST_LOG["*"] = ps["reason"]; exchange.log_auto({"symbol": "*", "ok": False, "text": ps["reason"]})
        return
    acc = exchange.get_account(prices)
    open_pos, orders, eq = acc["open_positions"], acc["orders"], max(acc["equity"], 1.0)
    # Include pending-order risk so simultaneous fills cannot breach heat limits
    risk_open = sum(p["risk_usd"] for p in open_pos if p["stage"] == 0) / eq * 100
    for od in orders:
        risk_open += float(od.get("risk_pct") or 0)
    btc = _row_fusion("BTCUSDT").get("cons") if "BTCUSDT" in symbols else None
    for o in orders:                                     # drop resting orders whose idea has been reversed
        if o["source"] == "auto":
            d = build_deep(o["symbol"], "1h", fetch_missing=False)
            if d.get("verdict") in ("LONG", "SHORT") and d["verdict"] != o["side"]:
                exchange.cancel_order(o["id"]); exchange.log_auto({"symbol": o["symbol"], "ok": False, "text": "سفارش لغو شد: جهت سیگنال برعکس شد"})
    for s in symbols:
        d = build_deep(s, "1h", fetch_missing=False)
        v = d.get("verdict")
        for p in open_pos:                               # early exit when the multi-timeframe view flipped against an unproven trade
            if p["symbol"] == s and p["source"] == "auto" and v in ("LONG", "SHORT") and v != p["side"] and p["stage"] == 0 and (d.get("conviction") or 0) >= 0.4:
                r_now = (prices.get(s, p["entry"]) - p["entry"]) * (1 if p["side"] == "LONG" else -1) / (abs(p["entry"] - p["stop0"]) or 1e-9)
                if r_now < 0.3:
                    exchange.close_position(p["id"], prices.get(s, p["entry"]), "signal_flip")
        if v not in ("LONG", "SHORT") or not d.get("signal"):
            continue
        if any(o["symbol"] == s for o in orders) or any(p["symbol"] == s for p in open_pos):
            continue
        it, df, px = _CACHE.get(_key(s, "1h")), _FRAMES.get(_key(s, "1h")), prices.get(s)
        if not it or df is None or not px:
            continue
        if it.get("stale") or time.time() - it.get("updated", 0) > max(600.0, 3.0 * settings.get_scan_sec()):
            if _LAST_LOG.get(s) != "stale":
                _LAST_LOG[s] = "stale"; exchange.log_auto({"symbol": s, "ok": False, "text": "داده قدیمی است؛ ثبت خودکار انجام نشد"})
            continue
        sig = d["signal"]; ind = sig["indicators"]; atr = float(ind["atr"]) or px * 0.01
        lab = plan_lab(s, "1h", df, sig, px)
        plan = (lab.get(v.lower()) or {}).get("best")
        dirn = 1 if v == "LONG" else -1
        x = {"symbol": s, "side": v, "verdict": v, "grade": (d.get("grade") or {}).get("grade", "—"), "cons": d.get("consensus_score", 0), "agree": sig.get("agree", 0),
             "plan": plan, "ext_atr": (px - ind["ema21"]) * dirn / atr, "rsi_extreme": (v == "LONG" and ind["rsi"] > 74) or (v == "SHORT" and ind["rsi"] < 26),
             "qv": (it.get("ticker") or {}).get("quote_volume", 0), "evidence": evidence.get(s), "open": open_pos, "n_orders": len(orders), "risk_open_pct": risk_open,
             "quality": (sig.get("levels") or {}).get("quality"), "timing_fit": (sig.get("levels") or {}).get("timing_fit"),
             "corr": lambda o, s=s: _pair_corr(s, o), "btc_cons": btc, "vol_hot": ((sig.get("extras") or {}).get("stats") or {}).get("vol_pct", 0) > 90}
        ctx = d.get("ctx") or {}
        cb = ctx.get("bias", 0.0) * dirn
        x["ctx_ok"] = ctx.get("liq_ok", True) is not False and cb > -0.6
        x["ctx_text"] = ("نقدینگی/اسپرد نامناسب" if ctx.get("liq_ok") is False else f"بافت بازار به‌شدت مخالف ({cb:+.2f})" if cb <= -0.6 else f"بافت بازار {cb:+.2f}") if ctx else "داده بافت بازار موجود نیست"
        x["track_ok"], x["track_text"] = readiness.track_gate(x["grade"], v)
        dec = policy.evaluate(cfg, x)
        snap = make_snap(d, px)
        if dec["ok"] and core.enabled("lessons"):                                  # mistake memory: never repeat a proven mistake
            les = lessons.check(s, v, snap, x["grade"])
            if not les["ok"]:
                dec = {**dec, "ok": False, "fails": ["حافظهٔ اشتباهات: " + f_ for f_ in les["fails"]] + list(dec.get("fails") or [])}
        txt = ("ثبت: " + plan["name"]) if dec["ok"] and plan else " · ".join(dec["fails"][:3])
        if dec["ok"] or _LAST_LOG.get(s) != txt:
            _LAST_LOG[s] = txt
            exchange.log_auto({"symbol": s, "verdict": v, "grade": x["grade"], "ok": dec["ok"], "text": txt})
        if not (dec["ok"] and plan):
            continue
        common = dict(leverage=10, risk_pct=dec["risk_pct"], source="auto", prices=prices, score=float(sig.get("score", 0)), regime=sig.get("regime", ""), grade=x["grade"], plan=plan["name"], snap=snap)
        if plan["mode"] == "market":
            r = exchange.open_position(s, v, px, plan["stop"], plan["tp1"], plan["tp2"], plan["tp3"], deadline_sec=cfg["time_stop_h"] * 3600, **common)
        else:
            r = exchange.place_order({"symbol": s, "side": v, "mode": plan["mode"], "price": plan["p"], "stop": plan["stop"], "tp1": plan["tp1"], "tp2": plan["tp2"], "tp3": plan["tp3"],
                                      "valid_h": cfg["valid_h"], "deadline_h": cfg["time_stop_h"], "leverage": 10, "risk_pct": dec["risk_pct"], "source": "auto", "grade": x["grade"],
                                      "plan": plan["name"], "score": float(sig.get("score", 0)), "regime": sig.get("regime", ""), "snap": snap})
        if not r.get("ok"):
            exchange.log_auto({"symbol": s, "ok": False, "text": "ثبت ناموفق: " + str(r.get("error"))})
        else:
            open_pos = exchange.get_account(prices)["open_positions"]; orders = exchange.get_account(prices)["orders"]; risk_open += dec["risk_pct"]


def get_item(sym: str, tf: str) -> dict | None:
    with _LOCK:
        return _CACHE.get(_key(sym, tf))


_REP: dict = {}


def build_report(sym: str, primary_tf: str = "1h", micro: dict | None = None, bt_res: dict | None = None) -> dict:
    """Coin Lab: deep multi-section / multi-timeframe report. Cached 30 s per (symbol, tf, with-micro)."""
    from app.analysis import lab
    sym = to_symbol(sym)
    key = (sym, primary_tf, bool(micro))
    hit = _REP.get(key)
    if hit and time.time() - hit[0] < 30:
        return hit[1]
    deep = build_deep(sym, primary_tf)
    if not deep.get("all_tf"):
        return {"ok": False, "symbol": sym, "error": "داده کافی برای تحلیل عمیق نیست"}
    frames = get_frames(sym)
    ptf = deep.get("primary_tf", primary_tf)
    df = frames.get(ptf)
    if df is None:
        df = closed_only(fetch_klines(sym, ptf, KLINE_LIMIT), ptf)
    prices = [(_CACHE.get(_key(sym, t)) or {}).get("ticker", {}).get("price") for t in TIMEFRAMES]
    px = next((p for p in prices if p), None) or float(df["close"].iloc[-1])
    lab_plan = {}
    try:
        sg = deep.get("signal") or deep["all_tf"][ptf]
        lab_plan = plan_lab(sym, ptf, df, sg, px) or {}
    except Exception:                                        # noqa: BLE001 - the plan laboratory is optional
        lab_plan = {}
    rep = lab.build(sym, deep["all_tf"], deep.get("all_forecasts") or {}, deep, micro=micro, evidence=evidence.get(sym), plan_lab=lab_plan, price=px, bt=bt_res)
    rep["updated"] = time.time()
    rep["ticker"] = (_CACHE.get(_key(sym, "1h")) or {}).get("ticker")
    rep["btc"] = _btc_stats(sym)
    if len(_REP) > 60:
        _REP.clear()
    _REP[key] = (time.time(), rep)
    return rep


# ───────────────────────── pattern view + timeline (all with exact times) ─────────────────────────
_PV: dict = {}


def _frame(sym: str, tf: str):
    with _LOCK:
        df = _FRAMES.get(_key(sym, tf))
    if df is None:
        df = closed_only(fetch_klines(sym, tf, KLINE_LIMIT), tf)
    return df


def pattern_view(sym: str, tf: str) -> dict:
    """Candlestick + structural patterns of one coin/timeframe, each with start, end, validity window, state and empirical stats."""
    sym = to_symbol(sym)
    df = _frame(sym, tf)
    key = (sym, tf, str(df["open_time"].iloc[-1]))
    hit = _PV.get(key)
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    t0 = time.time()
    item = get_cache_item(sym, tf)
    zones = ((item or {}).get("signal", {}).get("levels") or {}).get("zones") or []
    pooled = pattern_stats(tf) or pat.pooled_stats([df])
    own = pat.pooled_stats([df])
    clk = pat.clock(df, tf, 80, zones)
    for r in clk["recent"]:
        info = pat.INFO[r["k"]]
        r.update(meaning=info[2], expect=info[3], confirm=info[4], stat=pooled.get(r["k"]), own=own.get(r["k"]), verdict=pat.verdict(pooled.get(r["k"]), r["bias"]))
    summ = pat.summarize(clk["recent"], clk["structs"], pooled, tf)
    top = []
    for k, v in pooled.items():
        h8 = (v.get("h") or {}).get("8") if k != "_base" else None
        if h8 and h8["n"] >= 15:
            top.append({"k": k, "fa": pat.INFO[k][0], "bias": pat.BIAS[pat.INFO[k][1]], "n": h8["n"], "win": h8["win"], "mean": h8["mean"], "t": h8["t"]})
    top.sort(key=lambda z: -abs(z["t"]))
    out = {"symbol": sym, "tf": tf, "recent": clk["recent"][:60], "structs": clk["structs"], "summary": summ, "auto": clk.get("auto"), "base": pooled.get("_base"), "top": top[:12],
           "sample": {"pooled_tf": tf, "coins": len(settings.get_watchlist())}, "hours": hour_stats(), "n": len(df), "now": clk["now"], "bar_ms": clk["bar_ms"]}
    if len(_PV) > 80:
        _PV.clear()
    _PV[key] = (time.time(), out)
    core.record("patterns", (time.time() - t0) * 1000, True)
    return out


def build_timeline(sym: str) -> dict:
    """One schedule for a coin: per timeframe the signal window, the 48-candle projection window, level ETAs and live patterns."""
    sym = to_symbol(sym)
    now = int(time.time() * 1000)
    lanes = []
    for tf in TIMEFRAMES:
        it = get_cache_item(sym, tf)
        if not it or "signal" not in it:
            continue
        sg, fc = it["signal"], it.get("forecast") or {}
        tm = sg.get("timing") or fc.get("timing") or {}
        lane = {"tf": tf, "side": sg.get("side"), "score": sg.get("score"), "confidence": sg.get("confidence"), "timing": tm,
                "forecast": {"from": fc.get("valid_from"), "until": fc.get("valid_until"), "bars": fc.get("valid_bars"), "direction": fc.get("direction"),
                             "prob_up": fc.get("prob_up"), "edge_until": fc.get("edge_until")},
                "patterns": []}
        try:
            pv = pattern_view(sym, tf)
            for r in pv["recent"]:
                if r.get("alive") and r["bias"] != 0:
                    lane["patterns"].append({"k": r["k"], "fa": r["fa"], "bias": r["bias"], "t_start": r["t_start"], "t_end": r["t_end"], "valid_until": r["valid_until"],
                                             "state": r["state"], "state_fa": r["state_fa"], "strength": r["strength"], "kind": "candle"})
            for r in pv["structs"]:
                if r.get("alive"):
                    lane["patterns"].append({"k": r["k"], "fa": r["fa"], "bias": r["bias"], "t_start": r["t_start"], "t_end": r["t_end"], "valid_until": r["valid_until"],
                                             "state": r["state"], "state_fa": r["state_fa"], "strength": r["conf"], "kind": "struct"})
        except Exception as e:                                   # noqa: BLE001
            lane["patterns_error"] = str(e)[:100]
        lanes.append(lane)
    return {"symbol": sym, "now": now, "lanes": lanes}


_TREND: dict = {}


def trend_view(sym: str) -> dict:
    """Numeric trend of one coin over all timeframes (cached per scan generation)."""
    from app.analysis import trend as trend_mod
    sym = to_symbol(sym)
    gen = _gen(sym)
    hit = _TREND.get(sym)
    if hit and hit[0] == gen and gen[0] is not None:
        return hit[1]
    frames = {}
    for tf in TIMEFRAMES:
        try:
            frames[tf] = _frame(sym, tf)
        except Exception:                                        # noqa: BLE001
            pass
    sigs, fcs = {}, {}
    for tf in TIMEFRAMES:
        it = get_cache_item(sym, tf)
        if it and "signal" in it:
            sigs[tf], fcs[tf] = it["signal"], it.get("forecast") or {}
    out = trend_mod.build(sym, frames, sigs, fcs, build_deep(sym, "1h", fetch_missing=False))
    out["now"] = int(time.time() * 1000)
    if len(_TREND) > 200:
        _TREND.clear()
    _TREND[sym] = (gen, out)
    return out
