"""Per-coin walk-forward evidence for the auto-trader (background, cached). Uses the same engine as the live signals."""
from __future__ import annotations
import threading
import time

from app.analysis import backtest as bt
from app.data.market import fetch_klines, closed_only

_LOCK = threading.Lock()
_DATA: dict[str, dict] = {}
_BUSY = {"on": False}
TTL = 3 * 3600


def get(sym: str) -> dict | None:
    d = _DATA.get(sym)
    return d if d and time.time() - d["ts"] < TTL * 2 else None


def all_rows() -> dict:
    return dict(_DATA)


def refresh_async(symbols: list[str], tf: str = "1h") -> None:
    with _LOCK:
        if _BUSY["on"]:
            return
        todo = [s for s in symbols if not _DATA.get(s) or time.time() - _DATA[s]["ts"] > TTL]
        if not todo:
            return
        _BUSY["on"] = True
    threading.Thread(target=_work, args=(todo, tf), daemon=True).start()


def _work(todo: list[str], tf: str) -> None:
    try:
        for s in todo:
            try:
                df = closed_only(fetch_klines(s, tf, 500), tf)
                r = bt.run(df, s, tf, step=3)
                _DATA[s] = {"ts": time.time(), "n": r.get("n", 0), "avg_r": r.get("avg_r", 0.0), "win": r.get("win_rate", 0.0), "pf": r.get("pf", 0.0),
                            "t": r.get("t_stat", 0.0), "total_r": r.get("total_r", 0.0), "dd": r.get("max_dd_r", 0.0), "sig": bool(r.get("significant")), "tf": tf}
            except Exception:                              # noqa: BLE001 - one coin failing must not stop the rest
                continue
    finally:
        _BUSY["on"] = False


def aggregate() -> dict:
    rows = [v for v in _DATA.values() if v["n"] > 0]
    if not rows:
        return {}
    n = sum(r["n"] for r in rows)
    return {"coins": len(rows), "trades": n, "avg_r": round(sum(r["avg_r"] * r["n"] for r in rows) / n, 3), "win": round(sum(r["win"] * r["n"] for r in rows) / n, 1),
            "positive": sum(1 for r in rows if r["avg_r"] > 0), "significant": sum(1 for r in rows if r["sig"])}
