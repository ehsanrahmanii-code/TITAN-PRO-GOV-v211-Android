"""Price / signal alerts. Persisted atomically; evaluated against the scan cache (no extra network)."""
from __future__ import annotations
import json, os, threading, time, uuid
from app.config import DATA_DIR, ALERTS_MAX, to_symbol, valid_symbol

_FILE = DATA_DIR / "alerts.json"
_LOCK = threading.RLock()
MAX_ALERTS = 60


def _load() -> list:
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []
    except Exception:                                      # noqa: BLE001
        return []


def _save(items: list) -> None:
    tmp = _FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, _FILE)


def list_all() -> list:
    with _LOCK:
        return _load()


def add(body: dict) -> dict:
    kind = body.get("type", "price")
    sym = "*" if body.get("symbol") == "*" else to_symbol(str(body.get("symbol", "")))
    if sym != "*" and sym and not sym.endswith("USDT"):
        sym += "USDT"
    if sym != "*" and not valid_symbol(sym):
        raise ValueError("نماد نامعتبر")
    item = {"id": uuid.uuid4().hex[:10], "type": kind, "symbol": sym, "created": int(time.time()), "fired": None, "note": str(body.get("note", ""))[:80]}
    if kind == "price":
        if sym == "*" or not sym:
            raise ValueError("هشدار قیمت به یک ارز مشخص نیاز دارد")
        op, price = body.get("op"), float(body.get("price", 0))
        if op not in (">", "<") or not (price > 0) or price != price or price == float("inf"):
            raise ValueError("شرط یا قیمت نامعتبر")
        item.update(op=op, price=price)
    elif kind == "signal":
        g = body.get("min_grade", "B")
        if g not in ("A", "B", "C"):
            raise ValueError("درجه نامعتبر")
        item.update(min_grade=g, last="WAIT")
    else:
        raise ValueError("نوع هشدار نامعتبر")
    with _LOCK:
        items = _load()
        if len(items) >= MAX_ALERTS:
            raise ValueError("سقف تعداد هشدار پر شده است")
        items.append(item)
        _save(items)
    return item


def remove(aid: str) -> bool:
    with _LOCK:
        items = _load()
        n = [x for x in items if x.get("id") != aid]
        if len(n) == len(items):
            return False
        _save(n)
        return True


def check(price_of, fusion_of, symbols) -> list:
    """price_of(sym)->float|None, fusion_of(sym)->dict. Returns newly fired alerts (also persisted)."""
    fired = []
    with _LOCK:
        items = _load()
        dirty = False
        for it in items:
            try:
                if it["type"] == "price" and not it.get("fired"):
                    px = price_of(it["symbol"])
                    if px and ((it["op"] == ">" and px >= it["price"]) or (it["op"] == "<" and px <= it["price"])):
                        it["fired"] = {"t": int(time.time()), "msg": f"{it['symbol'].replace('USDT', '')} {'بالاتر' if it['op'] == '>' else 'پایین‌تر'} از {it['price']:g} شد (قیمت {px:g})"}
                        fired.append(it); dirty = True
                elif it["type"] == "signal":
                    for s in (symbols if it["symbol"] == "*" else [it["symbol"]]):
                        f = fusion_of(s) or {}
                        v, g = f.get("verdict", "WAIT"), f.get("grade", "—")
                        key = f"{s}:{v}"
                        ok = v in ("LONG", "SHORT") and g in "ABC"[:"ABC".index(it["min_grade"]) + 1] and g != "—"
                        last = it.setdefault("seen", {})
                        if ok and last.get(s) != key:
                            it["fired"] = {"t": int(time.time()), "msg": f"{s.replace('USDT', '')}: سیگنال {'خرید' if v == 'LONG' else 'فروش'} درجه {g}"}
                            fired.append(dict(it)); dirty = True
                        last[s] = key if ok else "WAIT"
            except Exception:                              # noqa: BLE001
                continue
        if dirty or any(it["type"] == "signal" for it in items):
            _save(items)
    return fired
