"""Resilient multi-source market data — speed-optimised for TITAN PRO Clean.
Source order based on real telemetry: OKX → MEXC → Bybit → Gate → Binance.
Short timeouts, circuit breakers, TTL cache, closed-candle helper.
"""
from __future__ import annotations
import threading
import time
from typing import Any

import pandas as pd
import requests

from app.config import CONNECT_TIMEOUT, READ_TIMEOUT, SOURCE_ORDER
from app import core

_SESSION = requests.Session()
_SESSION.headers.update({"User-Agent": "Mozilla/5.0 (compatible; TitanProClean/1.0)", "Accept": "application/json"})
_ADAPTER = requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=40, max_retries=0)
_SESSION.mount("https://", _ADAPTER)
_SESSION.mount("http://", _ADAPTER)

_ALIASES = {"XAUTUSDT": ["XAUTUSDT", "PAXGUSDT"], "MATICUSDT": ["POLUSDT", "MATICUSDT"]}
_IV_SEC = {"1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "4h": 14400, "1d": 86400}
_MEXC_IV = {"1h": "60m"}
_BYBIT_IV = {"1m": "1", "5m": "5", "15m": "15", "30m": "30", "1h": "60", "4h": "240", "1d": "D"}
_OKX_IV = {"1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1H", "4h": "4H", "1d": "1D"}
_TTL = {"1m": 10, "5m": 20, "15m": 35, "1h": 75, "4h": 200, "1d": 500}
_STALE_MAX = 720.0

SOURCES = SOURCE_ORDER[:]  # okx, mexc, bybit, gate, binance


class NoSymbol(Exception):
    pass


# ── health / circuit breaker ───────────────────────────────────────────────
_H_LOCK = threading.Lock()
_HEALTH: dict[str, dict] = {s: {"ok": 0, "fail": 0, "streak": 0, "cool_until": 0.0,
                                "last_ok": 0.0, "last_err": "", "lat_ms": 0} for s in SOURCES}


def _cooling(name: str) -> bool:
    return _HEALTH.get(name, {}).get("cool_until", 0) > time.time()


def _mark(name: str, ok: bool, lat: float = 0.0, err: str = "") -> None:
    with _H_LOCK:
        h = _HEALTH.setdefault(name, {"ok": 0, "fail": 0, "streak": 0, "cool_until": 0.0,
                                       "last_ok": 0.0, "last_err": "", "lat_ms": 0})
        if ok:
            h.update(ok=h["ok"] + 1, streak=0, cool_until=0.0, last_ok=time.time(), lat_ms=int(lat * 1000))
        else:
            h["fail"] += 1
            h["streak"] += 1
            h["last_err"] = err[:120]
            if h["streak"] >= 3:
                h["cool_until"] = time.time() + min(120, 15 * h["streak"])


def source_status() -> dict[str, dict]:
    with _H_LOCK:
        now = time.time()
        return {k: {**v, "cooling": v["cool_until"] > now} for k, v in _HEALTH.items()}


def _get(url: str, params: dict | None = None, timeout: tuple | None = None) -> Any:
    timeout = timeout or (CONNECT_TIMEOUT, READ_TIMEOUT)
    r = _SESSION.get(url, params=params, timeout=timeout)
    if r.status_code in (400, 404):
        raise NoSymbol(f"HTTP {r.status_code}")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.json()


def _finish(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    df = df.sort_values("open_time").drop_duplicates("open_time").reset_index(drop=True)
    for c in ("open", "high", "low", "close", "volume"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open", "high", "low", "close"])
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    return df


def _parse_binance(raw: list) -> pd.DataFrame:
    rows = [{"open_time": int(i[0]), "open": i[1], "high": i[2], "low": i[3],
             "close": i[4], "volume": i[5]} for i in raw if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _parse_bybit(raw: dict) -> pd.DataFrame:
    lst = ((raw or {}).get("result") or {}).get("list") or []
    rows = [{"open_time": int(i[0]), "open": i[1], "high": i[2], "low": i[3],
             "close": i[4], "volume": i[5]} for i in lst if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _parse_gate(raw: list) -> pd.DataFrame:
    rows = [{"open_time": int(float(i[0])) * 1000, "open": i[5], "high": i[3], "low": i[4],
             "close": i[2], "volume": i[6] if len(i) > 6 else i[1]} for i in raw if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _parse_okx(raw: dict) -> pd.DataFrame:
    lst = ((raw or {}).get("data") or [])
    rows = [{"open_time": int(i[0]), "open": i[1], "high": i[2], "low": i[3],
             "close": i[4], "volume": i[5]} for i in lst if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _cands(symbol: str) -> list[str]:
    s = symbol.upper().replace("/", "")
    return _ALIASES.get(s, [s])


# ── klines cache ───────────────────────────────────────────────────────────
_KCACHE: dict[tuple, tuple[float, pd.DataFrame, int]] = {}
_KLOCKS: dict[tuple, threading.Lock] = {}
_KL_GUARD = threading.Lock()


def _klock(key: tuple) -> threading.Lock:
    with _KL_GUARD:
        lk = _KLOCKS.get(key)
        if lk is None:
            lk = _KLOCKS[key] = threading.Lock()
        return lk


def _download(sym: str, interval: str, limit: int) -> pd.DataFrame | None:
    base = sym[:-4]
    sources = [
        ("okx", "https://www.okx.com/api/v5/market/candles",
         {"instId": f"{base}-USDT", "bar": _OKX_IV.get(interval, interval), "limit": str(min(limit, 300))}, "okx"),
        ("mexc", "https://api.mexc.com/api/v3/klines",
         {"symbol": sym, "interval": _MEXC_IV.get(interval, interval), "limit": limit}, "binance"),
        ("bybit", "https://api.bybit.com/v5/market/kline",
         {"category": "spot", "symbol": sym, "interval": _BYBIT_IV.get(interval, ""), "limit": limit}, "bybit"),
        ("gate", "https://api.gateio.ws/api/v4/spot/candlesticks",
         {"currency_pair": f"{base}_USDT", "interval": interval, "limit": limit}, "gate"),
        ("binance", "https://data-api.binance.vision/api/v3/klines",
         {"symbol": sym, "interval": interval, "limit": limit}, "binance"),
    ]
    # respect configured order & cooling
    order_map = {name: i for i, name in enumerate(SOURCE_ORDER)}
    sources = sorted(sources, key=lambda s: order_map.get(s[0], 99))
    live = [s for s in sources if not _cooling(s[0])] or sources

    for name, url, params, kind in live:
        if params.get("interval") == "" or params.get("bar") == "":
            continue
        t0 = time.time()
        try:
            raw = _get(url, params, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
            if kind == "binance":
                df = _parse_binance(raw) if isinstance(raw, list) else pd.DataFrame()
            elif kind == "bybit":
                df = _parse_bybit(raw) if isinstance(raw, dict) else pd.DataFrame()
            elif kind == "okx":
                df = _parse_okx(raw) if isinstance(raw, dict) else pd.DataFrame()
            else:
                df = _parse_gate(raw) if isinstance(raw, list) else pd.DataFrame()
            if len(df) >= 30:
                _mark(name, True, time.time() - t0)
                return df
        except NoSymbol:
            continue
        except Exception as e:
            _mark(name, False, err=str(e))
    return None


@core.track("market")
def fetch_klines(symbol: str, interval: str = "1h", limit: int = 300) -> pd.DataFrame:
    sym = symbol.upper().replace("/", "")
    key = (sym, interval)
    now = time.time()
    ttl = _TTL.get(interval, 60)
    hit = _KCACHE.get(key)
    if hit and now - hit[0] < ttl and hit[2] >= limit:
        return hit[1].copy()

    with _klock(key):
        hit = _KCACHE.get(key)
        if hit and now - hit[0] < ttl and hit[2] >= limit:
            return hit[1].copy()
        df = None
        for cand in _cands(sym):
            df = _download(cand, interval, limit)
            if df is not None and len(df) >= 30:
                break
        if df is None or df.empty:
            if hit and now - hit[0] < _STALE_MAX:
                out = hit[1].copy()
                out.attrs["stale"] = True
                return out
            return pd.DataFrame()
        df.attrs["stale"] = False
        _KCACHE[key] = (now, df, limit)
        return df.copy()


def closed_only(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    """Return only fully closed candles (drop the still-forming last bar)."""
    if df is None or df.empty:
        return df
    sec = _IV_SEC.get(interval, 3600)
    last_ts = df["open_time"].iloc[-1]
    if hasattr(last_ts, "timestamp"):
        age = time.time() - last_ts.timestamp()
    else:
        age = 0
    if age < sec - 2:                      # the candle is only closed once its full interval has elapsed
        out = df.iloc[:-1].copy()
        out.attrs.update(getattr(df, "attrs", {}))
        return out
    return df


# ── tickers / prices ───────────────────────────────────────────────────────
_TCACHE: dict[str, tuple[float, dict]] = {}
_TLOCK = threading.Lock()


def fetch_tickers(symbols: list[str] | None = None, max_age: float | None = None) -> dict[str, dict]:
    """Bulk ticker fetch — tries fastest sources first.
    max_age: if set, return cache when younger than this many seconds (default 8).
    """
    now = time.time()
    ttl = 8.0 if max_age is None else float(max_age)
    with _TLOCK:
        if _TCACHE and now - next(iter(_TCACHE.values()))[0] < ttl:
            return {k: v[1] for k, v in _TCACHE.items()}

    out: dict[str, dict] = {}
    # OKX bulk
    try:
        t0 = time.time()
        raw = _get("https://www.okx.com/api/v5/market/tickers", {"instType": "SPOT"}, timeout=(1.5, 3.0))
        for d in (raw or {}).get("data") or []:
            inst = d.get("instId", "")
            if not inst.endswith("-USDT"):
                continue
            sym = inst.replace("-", "")
            last = float(d.get("last") or 0)
            if last <= 0:
                continue
            open24 = float(d.get("open24h") or last)
            chg = (last / open24 - 1) * 100 if open24 else 0.0
            out[sym] = {"symbol": sym, "price": last, "change_pct": round(chg, 3),
                        "high": float(d.get("high24h") or 0), "low": float(d.get("low24h") or 0),
                        "volume": float(d.get("vol24h") or 0), "quote_volume": float(d.get("volCcy24h") or 0),
                        "source": "okx"}
        _mark("okx", True, time.time() - t0)
    except Exception as e:
        _mark("okx", False, err=str(e))

    # MEXC fallback for missing
    if len(out) < 10:
        try:
            t0 = time.time()
            raw = _get("https://api.mexc.com/api/v3/ticker/24hr", timeout=(1.5, 3.5))
            for d in raw if isinstance(raw, list) else []:
                sym = d.get("symbol", "")
                if not sym.endswith("USDT") or sym in out:
                    continue
                last = float(d.get("lastPrice") or 0)
                if last <= 0:
                    continue
                out[sym] = {"symbol": sym, "price": last, "change_pct": float(d.get("priceChangePercent") or 0),
                            "high": float(d.get("highPrice") or 0), "low": float(d.get("lowPrice") or 0),
                            "volume": float(d.get("volume") or 0), "quote_volume": float(d.get("quoteVolume") or 0),
                            "source": "mexc"}
            _mark("mexc", True, time.time() - t0)
        except Exception as e:
            _mark("mexc", False, err=str(e))

    with _TLOCK:
        ts = time.time()
        for k, v in out.items():
            _TCACHE[k] = (ts, v)
    return out


def fetch_prices(symbols: list[str] | None = None) -> dict[str, float]:
    t = fetch_tickers(symbols)
    return {k: v["price"] for k, v in t.items() if v.get("price")}


def fetch_ticker(symbol: str) -> dict:
    sym = symbol.upper().replace("/", "")
    all_t = fetch_tickers()
    if sym in all_t:
        return all_t[sym]
    # single fallback
    for name, url, params in [
        ("okx", "https://www.okx.com/api/v5/market/ticker", {"instId": f"{sym[:-4]}-USDT"}),
        ("mexc", "https://api.mexc.com/api/v3/ticker/24hr", {"symbol": sym}),
    ]:
        try:
            raw = _get(url, params, timeout=(1.2, 2.5))
            if name == "okx":
                d = ((raw or {}).get("data") or [{}])[0]
                last = float(d.get("last") or 0)
                open24 = float(d.get("open24h") or last)
                return {"symbol": sym, "price": last, "change_pct": (last / open24 - 1) * 100 if open24 else 0,
                        "high": float(d.get("high24h") or 0), "low": float(d.get("low24h") or 0),
                        "volume": float(d.get("vol24h") or 0), "source": "okx"}
            last = float(raw.get("lastPrice") or 0)
            return {"symbol": sym, "price": last, "change_pct": float(raw.get("priceChangePercent") or 0),
                    "high": float(raw.get("highPrice") or 0), "low": float(raw.get("lowPrice") or 0),
                    "volume": float(raw.get("volume") or 0), "source": "mexc"}
        except Exception:
            continue
    return {"symbol": sym, "price": 0.0, "change_pct": 0.0}


# ── order book depth (light) ───────────────────────────────────────────────
_DEPTH_CACHE: dict[str, tuple[float, dict]] = {}


def fetch_depth(symbol: str, limit: int = 10) -> dict:
    sym = symbol.upper().replace("/", "")
    hit = _DEPTH_CACHE.get(sym)
    if hit and time.time() - hit[0] < 12:
        return hit[1]
    base = sym[:-4]
    for name, url, params in [
        ("okx", "https://www.okx.com/api/v5/market/books", {"instId": f"{base}-USDT", "sz": str(limit)}),
        ("mexc", "https://api.mexc.com/api/v3/depth", {"symbol": sym, "limit": limit}),
    ]:
        try:
            t0 = time.time()
            raw = _get(url, params, timeout=(1.0, 2.0))
            if name == "okx":
                data = ((raw or {}).get("data") or [{}])[0]
                bids = [[float(p), float(q)] for p, q, *_ in (data.get("bids") or [])[:limit]]
                asks = [[float(p), float(q)] for p, q, *_ in (data.get("asks") or [])[:limit]]
            else:
                bids = [[float(p), float(q)] for p, q in (raw.get("bids") or [])[:limit]]
                asks = [[float(p), float(q)] for p, q in (raw.get("asks") or [])[:limit]]
            mid = (bids[0][0] + asks[0][0]) / 2 if bids and asks else 0
            spread = (asks[0][0] - bids[0][0]) / mid * 10000 if mid else 0  # bps
            bid_vol = sum(q for _, q in bids)
            ask_vol = sum(q for _, q in asks)
            imb = (bid_vol - ask_vol) / (bid_vol + ask_vol) if (bid_vol + ask_vol) else 0
            depth_usd = mid * (bid_vol + ask_vol) if mid else 0
            spread_pct = (asks[0][0] - bids[0][0]) / mid * 100 if mid else 0
            # approx 1% band liquidity from top levels (conservative)
            band = mid * 0.01
            bid_1 = sum(q * p for p, q in bids if p >= mid - band)
            ask_1 = sum(q * p for p, q in asks if p <= mid + band)
            m = {"ok": True, "bids": bids, "asks": asks,
                 "spread_bps": round(spread, 2), "spread_pct": round(spread_pct, 4),
                 "imbalance": round(imb, 3), "imb_1pct": round(imb, 3),
                 "depth_usd": round(depth_usd, 0),
                 "bid_usd_1pct": round(bid_1, 0), "ask_usd_1pct": round(ask_1, 0),
                 "source": name}
            _mark(name, True, time.time() - t0)
            _DEPTH_CACHE[sym] = (time.time(), m)
            return m
        except Exception as e:
            _mark(name, False, err=str(e))
    return hit[1] if hit else {"ok": False}


# ── derivatives (Bybit linear) ─────────────────────────────────────────────
_DERIV_CACHE: dict[str, tuple[float, dict]] = {}



def fetch_derivs(symbol: str) -> dict:
    """Perpetual funding / OI / basis. Tries Bybit linear first, then OKX SWAP."""
    sym = symbol.upper().replace("/", "")
    base = sym[:-4] if sym.endswith("USDT") else sym
    hit = _DERIV_CACHE.get(sym)
    if hit and time.time() - hit[0] < 40:
        return hit[1]
    out: dict = {"ok": False}

    # --- Bybit linear ---
    try:
        raw = _get("https://api.bybit.com/v5/market/tickers", {"category": "linear", "symbol": sym},
                   timeout=(1.5, 3.0))
        lst = ((raw or {}).get("result") or {}).get("list") or []
        if lst:
            d = lst[0]
            fr = float(d.get("fundingRate") or 0)
            fi_h = float(d.get("fundingIntervalHour") or 8) or 8.0
            mark, idx = float(d.get("markPrice") or 0), float(d.get("indexPrice") or 0)
            out = {"ok": True, "source": "bybit",
                   "funding_pct": round(fr * 100, 4),
                   "funding_apr": round(fr * (24 / fi_h) * 365 * 100, 1),
                   "oi_usd": round(float(d.get("openInterestValue") or 0)),
                   "mark": mark, "index": idx,
                   "basis_pct": round((mark / idx - 1) * 100, 4) if idx else 0.0,
                   "next_funding": int(d.get("nextFundingTime") or 0),
                   "turnover_24h": round(float(d.get("turnover24h") or 0))}
            try:
                lr = _get("https://api.bybit.com/v5/market/account-ratio",
                          {"category": "linear", "symbol": sym, "period": "1h", "limit": 12},
                          timeout=(1.2, 2.5))
                rows = ((lr or {}).get("result") or {}).get("list") or []
                hist = [float(x["buyRatio"]) for x in reversed(rows) if "buyRatio" in x]
                if hist:
                    out["ls_buy"], out["ls_hist"] = round(hist[-1], 4), [round(x, 4) for x in hist]
            except Exception:
                pass
            try:
                oi = _get("https://api.bybit.com/v5/market/open-interest",
                          {"category": "linear", "symbol": sym, "intervalTime": "1h", "limit": 25},
                          timeout=(1.2, 2.5))
                rows = ((oi or {}).get("result") or {}).get("list") or []
                vals = [float(x.get("openInterest") or 0) for x in rows if float(x.get("openInterest") or 0) > 0]
                if len(vals) >= 5:
                    out["oi_chg_4h"] = round((vals[0] / vals[4] - 1) * 100, 2)
                if len(vals) >= 24:
                    out["oi_chg_24h"] = round((vals[0] / vals[min(24, len(vals) - 1)] - 1) * 100, 2)
            except Exception:
                pass
            _mark("bybit", True)
    except Exception as e:
        _mark("bybit", False, err=str(e))

    # --- OKX SWAP fallback ---
    if not out.get("ok"):
        try:
            inst = f"{base}-USDT-SWAP"
            fr_raw = _get("https://www.okx.com/api/v5/public/funding-rate", {"instId": inst}, timeout=(1.5, 3.0))
            fr_row = ((fr_raw or {}).get("data") or [{}])[0]
            t_raw = _get("https://www.okx.com/api/v5/market/ticker", {"instId": inst}, timeout=(1.5, 3.0))
            t_row = ((t_raw or {}).get("data") or [{}])[0]
            fr = float(fr_row.get("fundingRate") or 0)
            mark = float(t_row.get("last") or t_row.get("markPx") or 0)
            # OKX open interest
            oi_usd = 0.0
            try:
                oi_raw = _get("https://www.okx.com/api/v5/public/open-interest", {"instId": inst}, timeout=(1.2, 2.5))
                oi_row = ((oi_raw or {}).get("data") or [{}])[0]
                # oi in contracts * ctVal approx; use oiCcy if present
                oi_usd = float(oi_row.get("oiCcy") or oi_row.get("oi") or 0)
            except Exception:
                pass
            out = {"ok": True, "source": "okx",
                   "funding_pct": round(fr * 100, 4),
                   "funding_apr": round(fr * 3 * 365 * 100, 1),  # 8h funding → *3 per day
                   "oi_usd": round(oi_usd),
                   "mark": mark, "index": mark,
                   "basis_pct": 0.0,
                   "next_funding": int(fr_row.get("fundingTime") or 0)}
            _mark("okx", True)
        except Exception as e:
            _mark("okx", False, err=str(e))
            out = hit[1] if hit else {"ok": False, "reason": "unreachable"}

    if out.get("ok"):
        _DERIV_CACHE[sym] = (time.time(), out)
    return out



# ── global context ─────────────────────────────────────────────────────────
_GLOBAL: dict = {"ts": 0.0, "data": {}}
_GLOBAL_LOCK = threading.Lock()


def fetch_global() -> dict:
    now = time.time()
    with _GLOBAL_LOCK:
        d = dict(_GLOBAL["data"])
        if now - _GLOBAL["ts"] < 900 and d:
            return d
        _GLOBAL["ts"] = now
    out = dict(d)
    try:
        raw = _get("https://api.alternative.me/fng/", {"limit": 2}, timeout=(2.0, 4.0))
        rows = (raw or {}).get("data") or []
        if rows:
            out["fng"] = int(float(rows[0]["value"]))
            out["fng_label"] = str(rows[0].get("value_classification", ""))
            if len(rows) > 1:
                out["fng_prev"] = int(float(rows[1]["value"]))
    except Exception:
        pass
    try:
        raw = _get("https://api.coingecko.com/api/v3/global", None, timeout=(2.0, 4.0))
        dd = (raw or {}).get("data") or {}
        btc = (dd.get("market_cap_percentage") or {}).get("btc")
        if btc is not None:
            out["btc_dom"] = round(float(btc), 2)
        if dd.get("market_cap_change_percentage_24h_usd") is not None:
            out["mcap_chg_24h"] = round(float(dd["market_cap_change_percentage_24h_usd"]), 2)
    except Exception:
        pass
    with _GLOBAL_LOCK:
        if out:
            _GLOBAL["data"] = out
    return out
