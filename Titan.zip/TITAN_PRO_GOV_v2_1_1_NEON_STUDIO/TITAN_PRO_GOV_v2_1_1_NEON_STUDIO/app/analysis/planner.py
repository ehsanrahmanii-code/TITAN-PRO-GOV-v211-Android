"""Entry / stop / target laboratory.

For one symbol it builds a menu of concrete trade plans - market entry, pull-back limit entries at real
structure (EMA, VWAP, Fibonacci, POC, support/resistance, order blocks, fair-value gaps) and a breakout stop-entry -
and replays every plan on the same 600 simulated price paths (with simulated wicks):
  P(fill), P(TP1 / TP2 / TP3 / stop | filled), expected R after fees+slippage, typical time to fill.
The recommended plan maximises expected R weighted by fill probability. Conservative rules: a stop and a
target inside the same candle -> stop first; no target is credited in the candle that fills a limit order.
"""
from __future__ import annotations
import numpy as np

from app.config import PARTIALS, FEE_TAKER, FEE_MAKER, SLIPPAGE

R_MULT = (1.2, 2.2, 3.5)


def _replay(sim: dict, side: str, entry: float, stop: float, tps: tuple, mode: str, valid: int = 10) -> dict | None:
    H, L, C = sim["highs"], sim["lows"], sim["closes"]
    P, N = C.shape
    d = 1.0 if side == "LONG" else -1.0
    risk = abs(entry - stop)
    if risk <= 0:
        return None
    r_of = [d * (tp - entry) / risk for tp in tps]
    filled = np.zeros(P, bool); alive = np.zeros(P, bool); stage = np.zeros(P, int); R = np.zeros(P)
    fill_i = np.full(P, -1); tp1_i = np.full(P, -1)
    h1 = np.zeros(P, bool); h2 = np.zeros(P, bool); h3 = np.zeros(P, bool); stopped = np.zeros(P, bool)
    last = sim["last"]
    for i in range(N):
        prev = filled & alive
        # --- management of already-open paths (same exit rules as the paper exchange)
        if side == "LONG":
            adverse = np.where(stage >= 1, L[:, i] <= entry, L[:, i] <= stop); fav = [H[:, i] >= tp for tp in tps]
        else:
            adverse = np.where(stage >= 1, H[:, i] >= entry, H[:, i] >= stop); fav = [L[:, i] <= tp for tp in tps]
        hs = prev & adverse
        stopped |= hs & (stage == 0); R += np.where(hs & (stage == 0), -1.0, 0.0); alive &= ~hs
        m = alive & prev & (stage == 0) & fav[0]; R += np.where(m, PARTIALS[0] * r_of[0], 0.0); tp1_i = np.where(m & (tp1_i < 0), i, tp1_i); h1 |= m; stage = np.where(m, 1, stage)
        m = alive & prev & (stage == 1) & fav[1]; R += np.where(m, PARTIALS[1] * r_of[1], 0.0); h2 |= m; stage = np.where(m, 2, stage)
        m = alive & prev & (stage == 2) & fav[2]; R += np.where(m, PARTIALS[2] * r_of[2], 0.0); h3 |= m; stage = np.where(m, 3, stage); alive &= ~m
        # --- new fills this candle
        if mode == "market":
            cond = np.ones(P, bool) if i == 0 else np.zeros(P, bool)
        elif mode == "limit":
            cond = (L[:, i] <= entry) if side == "LONG" else (H[:, i] >= entry)
        else:                                                      # breakout stop-entry
            cond = (H[:, i] >= entry) if side == "LONG" else (L[:, i] <= entry)
        nf = (~filled) & cond & (i < (1 if mode == "market" else valid))
        if nf.any():
            filled |= nf; alive |= nf; fill_i = np.where(nf, i, fill_i)
            bad = nf & ((L[:, i] <= stop) if side == "LONG" else (H[:, i] >= stop))              # filled and stopped in the same candle
            stopped |= bad; R += np.where(bad, -1.0, 0.0); alive &= ~bad
    rem = np.where(stage == 0, 1.0, np.where(stage == 1, 1 - PARTIALS[0], np.where(stage == 2, 1 - PARTIALS[0] - PARTIALS[1], 0.0)))
    R += np.where(alive, rem * d * (C[:, -1] - entry) / risk, 0.0)
    nfill = int(filled.sum())
    if nfill < 20:
        return {"p_fill": round(nfill / P, 3), "n": nfill, "ev_r": None}
    fee_in = FEE_TAKER if mode != "limit" else FEE_MAKER
    cost = (fee_in + FEE_TAKER + 2 * SLIPPAGE) * entry / risk
    Rf = R[filled] - cost
    t1 = tp1_i[(tp1_i >= 0) & filled]; tf_ = fill_i[filled]
    return {"p_fill": round(nfill / P, 3), "n": nfill, "p_tp1": round(float(h1[filled].mean()), 3), "p_tp2": round(float(h2[filled].mean()), 3),
            "p_tp3": round(float(h3[filled].mean()), 3), "p_stop": round(float(stopped[filled].mean()), 3), "ev_r": round(float(Rf.mean()), 3), "ev_se": round(float(Rf.std() / np.sqrt(max(1, len(Rf)))), 3),
            "win": round(float((Rf > 0).mean()), 3), "worst": round(float(np.percentile(Rf, 10)), 2), "best": round(float(np.percentile(Rf, 90)), 2),
            "t_fill": int(np.median(tf_)) + 1 if mode != "market" else 0, "t_tp1": int(np.median(t1)) + 1 if len(t1) else None, "cost_r": round(float(cost), 3)}


def candidates(side: str, px: float, atr: float, ind: dict, ex: dict, zones: list) -> list[dict]:
    d = 1 if side == "LONG" else -1
    out, seen = [{"k": "market", "name": "ورود فوری (بازار)", "p": px, "mode": "market"}], []

    def add(name, p, mode="limit"):
        if not p or not np.isfinite(p):
            return
        dist = (px - p) * d / atr                                        # >0 = better price than now for this side
        if mode == "limit" and not (0.25 <= dist <= 3.5):
            return
        if mode == "stop" and not (0.15 <= -dist <= 2.2):
            return
        if any(abs(p - q) < 0.15 * atr for q in seen):
            return
        seen.append(p); out.append({"k": f"{mode}{len(out)}", "name": name, "p": float(p), "mode": mode})
    add("EMA 21", ind.get("ema21")); add("EMA 50", ind.get("ema50")); add("VWAP", ind.get("vwap"))
    vp, fb = ex.get("vp") or {}, ex.get("fib") or {}
    add("POC حجم", vp.get("poc"))
    for lv in (fb.get("levels") or []):
        if lv["r"] in (0.5, 0.618):
            add(f"فیبو {lv['r']}", lv["p"])
    sm = ex.get("smc") or {}
    for z in (sm.get("ob") or []):
        if (z["kind"] == "bull") == (side == "LONG"):
            add("اردر‌بلاک", (z["lo"] + z["hi"]) / 2)
    for z in (sm.get("fvg") or []):
        if (z["kind"] == "bull") == (side == "LONG"):
            add("گپ ارزش (FVG)", (z["lo"] + z["hi"]) / 2)
    for z in zones:
        if (z["kind"] == "S") == (side == "LONG"):
            add(("حمایت" if side == "LONG" else "مقاومت") + (f" ×{z['n']}" if z["n"] > 1 else ""), z["p"] + d * 0.05 * atr)
    opp = sorted([z for z in zones if (z["kind"] == "R") == (side == "LONG") and (z["p"] - px) * d > 0], key=lambda z: abs(z["p"] - px))
    if opp:
        add("شکست " + ("مقاومت" if side == "LONG" else "حمایت"), opp[0]["p"] + d * 0.08 * atr, "stop")
    return out[:9]


def stops_for(side: str, entry: float, atr: float, ex: dict, zones: list) -> list[tuple[str, float]]:
    d = 1 if side == "LONG" else -1
    res = [("ATR×1.5", entry - d * 1.5 * atr), ("ATR×2.2", entry - d * 2.2 * atr)]
    sm = ex.get("smc") or {}
    st = sm.get("structure") or {}
    base = st.get("last_low") if side == "LONG" else st.get("last_high")
    pool = [z["p"] for z in zones if (z["kind"] == "S") == (side == "LONG") and (entry - z["p"]) * d > 0.3 * atr]
    if base and (entry - base) * d > 0.3 * atr:
        pool.append(base)
    if pool:
        s = (max(pool) if side == "LONG" else min(pool)) - d * 0.3 * atr
        dist = (entry - s) * d / atr
        if 1.0 <= dist <= 3.4:
            res.append(("زیر ساختار", s))
    return res


def run(sim: dict, side: str, px: float, atr: float, ind: dict, ex: dict, zones: list) -> dict:
    d = 1 if side == "LONG" else -1
    rows = []
    for c in candidates(side, px, atr, ind, ex, zones):
        best = None
        for sname, stop in stops_for(side, c["p"], atr, ex, zones):
            risk = abs(c["p"] - stop)
            tps = tuple(c["p"] + d * risk * m for m in R_MULT)
            r = _replay(sim, side, c["p"], stop, tps, c["mode"], 10 if c["mode"] == "limit" else 8)
            if not r or r.get("ev_r") is None:
                continue
            row = {**c, **r, "stop": float(stop), "stop_name": sname, "tp1": tps[0], "tp2": tps[1], "tp3": tps[2], "risk_pct": round(risk / c["p"] * 100, 2),
                   "dist_atr": round((px - c["p"]) * d / atr, 2), "score": round(r["ev_r"] * float(np.sqrt(r["p_fill"])), 3)}
            if best is None or row["score"] > best["score"]:
                best = row
        if best:
            rows.append(best)
    rows.sort(key=lambda r: -r["score"])
    # the best of ~25 plans on the same 600 paths is optimistically biased (winner's curse): demand EV above its own 1-sigma noise
    pick = next((r for r in rows if r["p_fill"] >= 0.3 and r["ev_r"] - r.get("ev_se", 0.0) > 0), None)
    return {"side": side, "rows": rows[:8], "best": pick, "note": None if pick else "هیچ طرحی در شبیه‌سازی امید ریاضی مثبت نداشت؛ صبر بهتر از ورود است."}
