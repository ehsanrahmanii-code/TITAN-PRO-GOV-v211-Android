"""TITAN signal engine v2 — 16 weighted components, regime-adaptive weights,
swing-aware stops, full explainability (every component is returned to the UI)."""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
import numpy as np
import pandas as pd

from app.config import SIDE_THRESHOLD
from app.analysis import extras as extras_mod
from app.config import ADV_INDICATORS
from app.analysis import pro_core
from app.analysis import smc as smc_mod
from app import core as _core


@dataclass
class Signal:
    symbol: str
    timeframe: str
    side: str
    score: float
    confidence: float
    entry: float
    stop: float
    tp1: float
    tp2: float
    tp3: float
    risk_reward: float
    reasons: list = field(default_factory=list)
    indicators: dict = field(default_factory=dict)
    levels: dict = field(default_factory=dict)
    components: list = field(default_factory=list)
    regime: str = "unknown"
    bias: str = "flat"
    agree: float = 0.0
    extras: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


# ───────────────────────────── indicators ─────────────────────────────
def _ema(s, n): return s.ewm(span=n, adjust=False).mean()
def _sma(s, n): return s.rolling(n).mean()


def _rsi(close, n=14):
    d = close.diff()
    ag = d.clip(lower=0).ewm(alpha=1 / n, min_periods=n, adjust=False).mean()
    al = (-d.clip(upper=0)).ewm(alpha=1 / n, min_periods=n, adjust=False).mean()
    out = 100 - 100 / (1 + ag / al.replace(0, np.nan))
    out = out.where(~((al == 0) & (ag > 0)), 100.0)          # only gains in the window -> RSI 100 (was NaN)
    return out.where(~((al == 0) & (ag == 0)), 50.0)          # completely flat -> neutral


def _tr(df):
    h, l, c = df["high"], df["low"], df["close"]
    return pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)


def _atr(df, n=14):
    return _tr(df).ewm(alpha=1 / n, min_periods=n, adjust=False).mean()      # Wilder


def _macd(close):
    line = _ema(close, 12) - _ema(close, 26)
    sig = _ema(line, 9)
    return line, sig, line - sig


def _adx(df, n=14):
    up, dn = df["high"].diff(), -df["low"].diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    atr = _tr(df).ewm(alpha=1 / n, adjust=False).mean().replace(0, np.nan)
    pdi = (100 * pdm.ewm(alpha=1 / n, adjust=False).mean() / atr).fillna(0.0)
    mdi = (100 * mdm.ewm(alpha=1 / n, adjust=False).mean() / atr).fillna(0.0)
    dx = (100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)).fillna(0.0)
    return dx.ewm(alpha=1 / n, adjust=False).mean(), pdi, mdi


def _supertrend(df, n=10, mult=3.0):
    h, l, c = df["high"].values, df["low"].values, df["close"].values
    atr = _atr(df, n).bfill().values
    hl2 = (h + l) / 2
    ub, lb = hl2 + mult * atr, hl2 - mult * atr
    fub, flb = ub.copy(), lb.copy()
    d = np.ones(len(c))
    flip = 0
    for i in range(1, len(c)):
        fub[i] = ub[i] if (ub[i] < fub[i - 1] or c[i - 1] > fub[i - 1]) else fub[i - 1]
        flb[i] = lb[i] if (lb[i] > flb[i - 1] or c[i - 1] < flb[i - 1]) else flb[i - 1]
        d[i] = d[i - 1]
        if d[i - 1] == 1 and c[i] < flb[i]:
            d[i] = -1
        elif d[i - 1] == -1 and c[i] > fub[i]:
            d[i] = 1
        if d[i] != d[i - 1]:
            flip = i
    return int(d[-1]), len(c) - 1 - flip


def _pivots(arr, left=3, right=3, high=True):
    out = []
    for i in range(left, len(arr) - right):
        w = arr[i - left:i + right + 1]
        if (high and arr[i] == w.max() and arr[i] > arr[i - 1]) or (not high and arr[i] == w.min() and arr[i] < arr[i - 1]):
            out.append(i)
    return out


def _clip(x, a=-1.0, b=1.0): return float(max(a, min(b, x)))
def r8_(v): return float(f"{float(v):.8g}")


# ───────────────────────────── main analysis ─────────────────────────────
# Regime multipliers applied AFTER independent group scores are computed.
# Groups are informationally independent buckets to reduce double-counting.
GROUP_W = {
    "trend": {"structure": 1.15, "trend": 1.30, "momentum": 1.10, "volume": 1.0, "revert": 0.40, "pattern": 0.85, "volatility": 1.0},
    "range": {"structure": 1.25, "trend": 0.55, "momentum": 0.75, "volume": 0.95, "revert": 1.45, "pattern": 1.15, "volatility": 1.1},
    "neutral": {"structure": 1.0, "trend": 1.0, "momentum": 1.0, "volume": 1.0, "revert": 1.0, "pattern": 1.0, "volatility": 1.0},
}
# Target share of final score coming from each independent information group
# (structure 25%, trend+momentum 20%, volume 15%, liquidity/levels via structure,
#  multi-TF is external, volatility/regime 10%). Pattern is auxiliary.
GROUP_CAP = {
    "structure": 0.28, "trend": 0.18, "momentum": 0.18, "volume": 0.15,
    "revert": 0.12, "pattern": 0.08, "volatility": 0.10,
}
SCALE = 1.55   # calibrated down vs 1.7 to avoid inflated absolute scores after group capping
MIN_AGREE = 0.62


def _stub(df, symbol, tf, text="داده ناکافی"):
    p = float(df["close"].iloc[-1]) if len(df) else 0.0
    return Signal(symbol, tf, "WAIT", 0, 0.1, p, p, p, p, p, 0, [text])


def analyze(df: pd.DataFrame, symbol: str, timeframe: str, price: float | None = None,
            force_side: str | None = None) -> Signal:
    if df is None or len(df) < 60:
        return _stub(df if df is not None else pd.DataFrame({"close": []}), symbol, timeframe)

    close, high, low, vol = df["close"], df["high"], df["low"], df["volume"]
    last = float(close.iloc[-1])
    px = float(price) if price and price > 0 else last

    e9, e21, e50 = (float(_ema(close, n).iloc[-1]) for n in (9, 21, 50))
    ema200_s = _ema(close, 200)
    e200 = float(ema200_s.iloc[-1])
    e200_slope = float(ema200_s.iloc[-1] - ema200_s.iloc[-10]) / (last + 1e-12)
    have200 = len(df) >= 200
    rsi_s = _rsi(close)
    r = float(rsi_s.iloc[-1])
    a = float(_atr(df).iloc[-1])
    a = a if a > 0 and np.isfinite(a) else last * 0.01
    atr_pct = a / last * 100
    _, _, mh_s = _macd(close)
    mh, mh_prev = float(mh_s.iloc[-1]), float(mh_s.iloc[-2])
    mid = close.rolling(20).mean()
    sd = close.rolling(20).std()
    bu, bm, bl = float(mid.iloc[-1] + 2 * sd.iloc[-1]), float(mid.iloc[-1]), float(mid.iloc[-1] - 2 * sd.iloc[-1])
    bb_pos = (last - bl) / (bu - bl + 1e-12)
    width = ((mid + 2 * sd) - (mid - 2 * sd)) / mid
    w_hist = width.dropna().tail(100)
    squeeze = bool(len(w_hist) > 30 and width.iloc[-1] <= w_hist.quantile(0.15))
    ll_n = low.rolling(14).min(); hh_n = high.rolling(14).max()
    st_k = 100 * (close - ll_n) / (hh_n - ll_n + 1e-12)
    sk, sdd = float(st_k.iloc[-1]), float(st_k.rolling(3).mean().iloc[-1])
    adx_s, pdi_s, mdi_s = _adx(df)
    adx, pdi, mdi = float(adx_s.iloc[-1]), float(pdi_s.iloc[-1]), float(mdi_s.iloc[-1])
    st_dir, st_age = _supertrend(df)
    obv = (np.sign(close.diff().fillna(0)) * vol).cumsum()
    obv_slope = float((obv.iloc[-1] - obv.iloc[-21]) / (vol.tail(20).sum() + 1e-12))
    vol_sma = float(_sma(vol, 20).iloc[-1])
    vol_ratio = float(vol.iloc[-1]) / (vol_sma + 1e-12) if vol_sma > 0 else 1.0
    tp_ = (high + low + close) / 3
    vwap = float((tp_ * vol).tail(48).sum() / (vol.tail(48).sum() + 1e-12))
    roc10 = float(close.iloc[-1] / close.iloc[-11] - 1)

    regime = "trend" if adx >= 25 else "range" if adx < 18 else "neutral"
    gw = GROUP_W[regime]

    H, L = high.values, low.values
    ph, pl = _pivots(H, high=True), _pivots(L, high=False)
    res_all = [float(H[i]) for i in ph[-6:]]
    sup_all = [float(L[i]) for i in pl[-6:]]

    comps: list[dict] = []

    def add(k, name, group, w, s, text):
        comps.append({"k": k, "n": name, "g": group, "w": w, "s": round(_clip(s), 3), "t": text})

    # — trend —
    if e9 > e21 > e50: s, t = 1.0, "EMA 9>21>50 صعودی"
    elif e9 < e21 < e50: s, t = -1.0, "EMA 9<21<50 نزولی"
    elif e21 > e50: s, t = 0.35 if last > e21 else 0.1, "EMA21 بالای EMA50"
    elif e21 < e50: s, t = -0.35 if last < e21 else -0.1, "EMA21 زیر EMA50"
    else: s, t = 0.0, "EMAها در هم"
    add("ema", "چینش EMA", "trend", 1.2, s, t)
    d200 = (last - e200) / (a * 6)
    s = _clip(d200) * (1.0 if have200 else 0.5) + (0.2 if e200_slope > 0 else -0.2)
    add("e200", "EMA200", "trend", 0.9, s, "بالای EMA200" if last > e200 else "زیر EMA200")
    add("st", "سوپرترند", "trend", 1.1, st_dir * (1.0 if st_age <= 40 else 0.8),
        ("صعودی" if st_dir > 0 else "نزولی") + f" · {st_age} کندل")
    s = (1 if pdi > mdi else -1) * _clip((adx - 15) / 25, 0, 1)
    add("adx", "ADX/DI", "trend", 1.0, s, f"ADX {adx:.0f} · {'+DI' if pdi > mdi else '-DI'} غالب")
    # — momentum —
    if mh > 0 and mh > mh_prev: s, t = 1.0, "MACD صعودی و شتاب‌دار"
    elif mh > 0: s, t = 0.35, "MACD مثبت ولی ضعیف‌شونده"
    elif mh < 0 and mh < mh_prev: s, t = -1.0, "MACD نزولی و شتاب‌دار"
    elif mh < 0: s, t = -0.35, "MACD منفی ولی ضعیف‌شونده"
    else: s, t = 0.0, "MACD خنثی"
    add("macd", "MACD", "momentum", 1.0, s, t)
    add("rsim", "RSI مومنتوم", "momentum", 0.7, (r - 50) / 25 * 0.8, f"RSI {r:.0f}")
    add("roc", "نرخ تغییر", "momentum", 0.6, roc10 / (atr_pct / 100 * 3.2 + 1e-9), f"ROC10 {roc10 * 100:.1f}%")
    # divergence
    div, div_t = 0.0, "واگرایی ندارد"
    if len(pl) >= 2 and pl[-1] >= len(df) - 25 and L[pl[-1]] < L[pl[-2]] and rsi_s.iloc[pl[-1]] > rsi_s.iloc[pl[-2]] + 2:
        div, div_t = 1.0, "واگرایی صعودی RSI"
    elif len(ph) >= 2 and ph[-1] >= len(df) - 25 and H[ph[-1]] > H[ph[-2]] and rsi_s.iloc[ph[-1]] < rsi_s.iloc[ph[-2]] - 2:
        div, div_t = -1.0, "واگرایی نزولی RSI"
    add("div", "واگرایی", "momentum", 0.9, div, div_t)
    # — mean reversion —
    s = 1.0 if r < 28 else 0.5 if r < 38 else -1.0 if r > 72 else -0.5 if r > 62 else 0.0
    add("rsir", "RSI اشباع", "revert", 0.9, s, "اشباع فروش" if s > 0 else "اشباع خرید" if s < 0 else "ناحیه عادی")
    if sk < 20 and sk > sdd: s, t = 1.0, "استوکاستیک برگشت صعودی"
    elif sk > 80 and sk < sdd: s, t = -1.0, "استوکاستیک برگشت نزولی"
    else: s, t = (50 - sk) / 100, f"استوکاستیک {sk:.0f}"
    add("stoch", "استوکاستیک", "revert", 0.6, s, t)
    add("bb", "بولینگر", "revert", 0.7, _clip((0.5 - bb_pos) * 2.2),
        "نزدیک باند پایین" if bb_pos < 0.2 else "نزدیک باند بالا" if bb_pos > 0.8 else "وسط باند")
    # — volume —
    add("obv", "OBV", "volume", 0.8, _clip(obv_slope * 4), "جریان پول ورودی" if obv_slope > 0 else "جریان پول خروجی")
    cd = np.sign(last - float(df["open"].iloc[-1]))
    add("vol", "تایید حجم", "volume", 0.7, cd * _clip((vol_ratio - 1) / 1.5, 0, 1), f"حجم {vol_ratio:.1f}×")
    add("vwap", "VWAP", "volume", 0.6, _clip((last - vwap) / (a * 2)) * 0.7, "بالای VWAP" if last > vwap else "زیر VWAP")
    # — structure —
    hh = len(ph) >= 2 and H[ph[-1]] > H[ph[-2]]
    hl = len(pl) >= 2 and L[pl[-1]] > L[pl[-2]]
    lh = len(ph) >= 2 and H[ph[-1]] < H[ph[-2]]
    ll = len(pl) >= 2 and L[pl[-1]] < L[pl[-2]]
    s = (0.5 * hh + 0.5 * hl) - (0.5 * lh + 0.5 * ll)
    add("struct", "ساختار بازار", "structure", 1.0, s,
        "HH/HL صعودی" if s > 0.6 else "LH/LL نزولی" if s < -0.6 else "ساختار مختلط")
    near_s = [x for x in sup_all if 0 <= last - x <= 0.7 * a]
    near_r = [x for x in res_all if 0 <= x - last <= 0.7 * a]
    s = (0.9 if near_s else 0) - (0.9 if near_r else 0)
    add("sr", "نزدیکی به سطوح", "structure", 0.7, s,
        "روی حمایت" if near_s else "زیر مقاومت" if near_r else "فاصله از سطوح")
    # — pattern —
    o1, c1, o2, c2 = (float(df["open"].iloc[-2]), float(close.iloc[-2]), float(df["open"].iloc[-1]), last)
    body, rng = abs(c2 - o2), float(high.iloc[-1] - low.iloc[-1]) + 1e-12
    uw, lw = float(high.iloc[-1]) - max(o2, c2), min(o2, c2) - float(low.iloc[-1])
    pat, pat_t = 0.0, "الگوی خاصی نیست"
    if c1 < o1 and c2 > o2 and c2 >= o1 and o2 <= c1: pat, pat_t = 1.0, "انگالف صعودی"
    elif c1 > o1 and c2 < o2 and c2 <= o1 and o2 >= c1: pat, pat_t = -1.0, "انگالف نزولی"
    elif lw >= 2 * body and uw <= body * 0.6 and last < e21: pat, pat_t = 0.8, "چکش (برگشت صعودی)"
    elif uw >= 2 * body and lw <= body * 0.6 and last > e21: pat, pat_t = -0.8, "ستاره دنباله‌دار"
    elif body < 0.1 * rng: pat_t = "دوجی (تردید)"
    add("pat", "الگوی کندلی", "pattern", 0.8, pat, pat_t)

    # — extended components (v2.1) —
    ex = extras_mod.compute(df, timeframe)
    # Lightweight SMC (OB/FVG) from V84 technicals_core — pure local df
    try:
        _smc = _core.guard("smc", smc_mod.detect_order_blocks_fvg, df, default={}) or {}
        ex = dict(ex or {})
        # MERGE (never replace): extras.compute already holds the market-structure part (trend, BOS/CHoCH, sweep, premium/discount
        # range); the OB/FVG detector adds order blocks and fair-value gaps next to it.
        ex["smc"] = {**(ex.get("smc") or {}), **_smc}
    except Exception:
        _smc = {}
    ic = ex.get("ichimoku") or {}
    if ic:
        s = 0.6 * ic["pos"] + 0.25 * (1 if ic["tenkan"] > ic["kijun"] else -1) + 0.15 * ic["chikou"]
        add("ichi", "ابر ایچیموکو", "trend", 0.9, s, ("بالای ابر" if ic["pos"] > 0 else "زیر ابر" if ic["pos"] < 0 else "داخل ابر") + (" · تقاطع TK صعودی" if ic["tk_cross"] > 0 else " · تقاطع TK نزولی" if ic["tk_cross"] < 0 else ""))
    o_arr, h_arr, l_arr, c_arr = (df[k].values.astype(float) for k in ("open", "high", "low", "close"))
    ha_c = (o_arr + h_arr + l_arr + c_arr) / 4
    ha_o = np.empty_like(ha_c); ha_o[0] = (o_arr[0] + c_arr[0]) / 2
    for i in range(1, len(ha_c)):
        ha_o[i] = (ha_o[i - 1] + ha_c[i - 1]) / 2
    hb = np.sign(ha_c[-3:] - ha_o[-3:])
    ha_s = float(hb.mean()) * (0.6 + 0.4 * (1.0 if (hb[-1] > 0 and min(ha_o[-1], ha_c[-1]) - min(l_arr[-1], ha_o[-1]) < 1e-12 * last) or (hb[-1] < 0 and max(h_arr[-1], ha_o[-1]) - max(ha_o[-1], ha_c[-1]) < 1e-12 * last) else 0.0))
    add("ha", "هایکن‌آشی", "trend", 0.5, ha_s, "۳ کندل هایکن‌آشی صعودی" if hb.sum() == 3 else "۳ کندل هایکن‌آشی نزولی" if hb.sum() == -3 else "هایکن‌آشی مختلط")
    rmin, rmax = rsi_s.rolling(14).min(), rsi_s.rolling(14).max()
    srsi = ((rsi_s - rmin) / (rmax - rmin + 1e-12) * 100)
    sk2, sd2 = srsi.rolling(3).mean(), srsi.rolling(3).mean().rolling(3).mean()
    k2, d2 = float(sk2.iloc[-1]) if np.isfinite(sk2.iloc[-1]) else 50.0, float(sd2.iloc[-1]) if np.isfinite(sd2.iloc[-1]) else 50.0
    if k2 < 20 and k2 > d2: s, t = 1.0, "StochRSI برگشت از اشباع فروش"
    elif k2 > 80 and k2 < d2: s, t = -1.0, "StochRSI برگشت از اشباع خرید"
    else: s, t = (50 - k2) / 120, f"StochRSI {k2:.0f}"
    add("srsi", "StochRSI", "revert", 0.6, s, t)
    v_arr = vol.values.astype(float)
    tpv = ((high + low + close) / 3).values.astype(float)
    mf = tpv * v_arr
    dtp = np.diff(tpv, prepend=tpv[0])
    pos_f, neg_f = mf[-14:][dtp[-14:] > 0].sum(), mf[-14:][dtp[-14:] < 0].sum()
    mfi = 100 - 100 / (1 + pos_f / (neg_f + 1e-12)) if (pos_f + neg_f) > 0 else 50.0
    add("mfi", "جریان پول MFI", "volume", 0.6, _clip((mfi - 50) / 30) * (0.5 if mfi > 80 or mfi < 20 else 1.0) * (1 if 20 <= mfi <= 80 else -1), f"MFI {mfi:.0f}")
    rngv = (h_arr - l_arr)
    clv = np.where(rngv > 0, ((c_arr - l_arr) - (h_arr - c_arr)) / np.where(rngv > 0, rngv, 1), 0.0)
    cmf = float((clv[-20:] * v_arr[-20:]).sum() / (v_arr[-20:].sum() + 1e-12))
    add("cmf", "Chaikin CMF", "volume", 0.7, _clip(cmf * 3), f"CMF {cmf:+.2f}")
    dh = float(high.iloc[-21:-1].max()); dl = float(low.iloc[-21:-1].min())
    if last > dh: s, t = 1.0, "شکست سقف ۲۰ کندل (Donchian)"
    elif last < dl: s, t = -1.0, "شکست کف ۲۰ کندل (Donchian)"
    else: s, t = ((last - dl) / (dh - dl + 1e-12) - 0.5) * 0.8, "داخل کانال Donchian"
    add("donch", "کانال Donchian", "structure", 0.8, s, t)
    # three-bar patterns / pin bars
    p3, pt = 0.0, "الگوی چندکندلی ندارد"
    bd = c_arr - o_arr
    big = np.abs(bd[-3:]) > 0.5 * a
    if len(df) > 5 and bd[-3] < 0 and big[0] and abs(bd[-2]) < 0.35 * abs(bd[-3]) and bd[-1] > 0 and c_arr[-1] > (o_arr[-3] + c_arr[-3]) / 2: p3, pt = 1.0, "ستاره صبحگاهی"
    elif len(df) > 5 and bd[-3] > 0 and big[0] and abs(bd[-2]) < 0.35 * abs(bd[-3]) and bd[-1] < 0 and c_arr[-1] < (o_arr[-3] + c_arr[-3]) / 2: p3, pt = -1.0, "ستاره عصرگاهی"
    elif (bd[-3:] > 0).all() and (c_arr[-3:] > np.r_[c_arr[-4], c_arr[-3], c_arr[-2]]).all() and big.all(): p3, pt = 0.9, "سه سرباز سفید"
    elif (bd[-3:] < 0).all() and (c_arr[-3:] < np.r_[c_arr[-4], c_arr[-3], c_arr[-2]]).all() and big.all(): p3, pt = -0.9, "سه کلاغ سیاه"
    else:
        lo10, hi10 = float(low.iloc[-10:].min()), float(high.iloc[-10:].max())
        if lw >= 2.5 * max(body, 1e-12) and float(low.iloc[-1]) <= lo10 * 1.0005 + 0.2 * a: p3, pt = 0.8, "پین‌بار صعودی در کف"
        elif uw >= 2.5 * max(body, 1e-12) and float(high.iloc[-1]) >= hi10 * 0.9995 - 0.2 * a: p3, pt = -0.8, "پین‌بار نزولی در سقف"
    add("pat2", "الگوهای چندکندلی", "pattern", 0.6, p3, pt)

    sm = ex.get("smc") or {}
    if sm.get("structure"):
        st_, evn, sw_ = sm["structure"], sm.get("event"), sm.get("sweep")
        s = {"bull": .5, "bear": -.5}.get(st_["trend"], 0.0)
        if evn and evn["ago"] <= 12:
            s += (0.35 if evn["kind"] == "CHoCH" else 0.28) * (1 if evn["dir"] == "up" else -1) * (1 - evn["ago"] / 20)
        if sw_:
            s += .25 if sw_["dir"] == "low" else -.25
        add("smc", "ساختار بازار (SMC)", "structure", 0.9, _clip(s), f"{st_['label']}" + (f" · {evn['kind']} {'صعودی' if evn['dir'] == 'up' else 'نزولی'} ({evn['ago']} کندل پیش)" if evn else "") + (" · جمع‌آوری نقدینگی" if sw_ else ""))
    oc = ex.get("osc") or {}
    if oc.get("osc"):
        add("osc", "رای‌گیری اسیلاتورها و میانگین‌ها", "momentum", 0.8, _clip(oc["all_score"] / 60), f"{oc['all_label']} · {oc['osc_buy']} خرید / {oc['osc_sell']} فروش اسیلاتور · {oc['ma_buy']}/{oc['ma_sell']} میانگین")

    # — x10 complementary indicators (quality / timing / flow) — modest weights, informationally distinct from the core —
    x10 = ex.get("x10") or {}
    X_MAP = {"hurst": ("trend", 0.45), "linreg": ("trend", 0.7), "vortex": ("trend", 0.6), "chop": ("volatility", 0.4), "vol_exp": ("volatility", 0.6),
             "crsi": ("revert", 0.7), "fisher": ("revert", 0.55), "vwapz": ("revert", 0.6), "sqz": ("momentum", 0.7), "klinger": ("volume", 0.7)}
    for xk, (xg, xw) in X_MAP.items():
        it = (x10.get("items") or {}).get(xk)
        if it:
            add("x_" + xk, it["n"], xg, xw, it["s"], it["t"])

    # — x11: structure / participation (anchored VWAP, Donchian breakout, prior-day levels & sweeps, same-hour relative volume) —
    x11 = ex.get("x11") or {}
    if ADV_INDICATORS:
        X11_MAP = {"avwap": ("structure", 0.6), "donch": ("trend", 0.5), "prior": ("structure", 0.5), "rvol": ("volume", 0.5), "persist": ("trend", 0.35)}
        for xk, (xg, xw) in X11_MAP.items():
            it = (x11.get("items") or {}).get(xk)
            if it:
                add("x_" + xk, it["n"], xg, xw, it["s"], it["t"])

    # — x12: regime / pressure / path / energy (10 complementary) —
    x12 = ex.get("x12") or {}
    if ADV_INDICATORS:
        X12_MAP = {
            "eff_ratio": ("trend", 0.45), "ulcer": ("volatility", 0.4), "mass": ("volatility", 0.35),
            "tsi": ("momentum", 0.55), "coppock": ("momentum", 0.5), "force": ("volume", 0.55),
            "nvi_pvi": ("volume", 0.4), "pivot_bias": ("structure", 0.45), "range_pos": ("revert", 0.45),
            "gap_pressure": ("momentum", 0.35),
        }
        for xk, (xg, xw) in X12_MAP.items():
            it = (x12.get("items") or {}).get(xk)
            if it:
                add("x12_" + xk, it["n"], xg, xw, it["s"], it["t"])

    # ── aggregate by independent information groups (reduces double-counting) ──
    # 1) per-group weighted mean of component scores in [-1, +1]
    group_scores: dict[str, float] = {}
    group_agree: dict[str, float] = {}
    for gname in set(c["g"] for c in comps):
        gcomps = [c for c in comps if c["g"] == gname]
        tw = sum(c["w"] for c in gcomps) or 1e-9
        group_scores[gname] = sum(c["w"] * c["s"] for c in gcomps) / tw
        act_g = [c for c in gcomps if abs(c["s"]) >= 0.2]
        if act_g:
            sg = 1 if group_scores[gname] >= 0 else -1
            group_agree[gname] = sum(c["w"] for c in act_g if np.sign(c["s"]) == sg) / (sum(c["w"] for c in act_g) + 1e-9)
        else:
            group_agree[gname] = 0.0

    # 2) apply regime multipliers then cap each group's contribution
    raw_parts = {}
    for gname, gs in group_scores.items():
        mult = gw.get(gname, 1.0)
        cap = GROUP_CAP.get(gname, 0.12)
        raw_parts[gname] = _clip(gs * mult) * cap
    raw = sum(raw_parts.values())
    # renormalize so full agreement across caps ≈ 1.0 magnitude
    max_possible = sum(GROUP_CAP.get(g, 0.12) for g in group_scores) or 1.0
    raw = raw / max_possible
    score = raw * 100 * SCALE
    if atr_pct < 0.2:
        score *= 0.7
    if regime == "range":
        score *= 0.88
    score = float(max(-100, min(100, score)))
    sign = 1 if score >= 0 else -1
    act = [c for c in comps if abs(c["s"]) >= 0.2]
    agree = (sum(c["w"] for c in act if np.sign(c["s"]) == sign) / (sum(c["w"] for c in act) + 1e-9)) if act else 0.0
    # group-level agreement (harder to inflate by correlated oscillators)
    g_act = [g for g, s in group_scores.items() if abs(s) >= 0.15]
    group_agree_mean = (sum(group_agree.get(g, 0) for g in g_act) / len(g_act)) if g_act else 0.0
    # Confidence is still heuristic (not calibrated probability). Label remains
    # "confidence" for UI compatibility; Signal Outcome Engine should calibrate later.
    conf = 0.18 + 0.42 * min(1, abs(score) / 65) + 0.18 * agree + 0.17 * group_agree_mean
    if atr_pct < 0.2:
        conf *= 0.85
    if regime == "range" and abs(score) > 40:
        conf *= 0.92  # strong scores in range are less reliable
    quality, timing = float(x10.get("quality", 50.0)), float(x10.get("timing", 0.0))
    conf *= 0.88 + 0.20 * (quality / 100.0)                 # tradable regimes earn confidence, choppy ones lose it
    # x12 complementary layer modulates confidence (not direction alone)
    x12 = ex.get("x12") or {}
    try:
        sc12 = float(x12.get("score") or 0.0)
        # agreement of x12 with current score sign boosts conf; conflict cuts it
        if abs(score) >= 8 and abs(sc12) >= 15:
            same = (score > 0 and sc12 > 0) or (score < 0 and sc12 < 0)
            conf *= 1.06 if same else 0.92
    except (TypeError, ValueError):
        sc12 = 0.0
    conf = round(min(0.92, conf), 3)


    # ── PRO V84 core adjustment (EMA/VWAP/volume/BTC/funding/OI) ──
    try:
        _vol_spike = bool(vol_ratio >= 1.6)
        _pro = pro_core.pro_score_adjust(
            score,
            price=px, rsi=r, vwap=float(vwap or 0), ema20=float(e21 or 0), ema50=float(e50 or 0),
            atr=float(a or 0), volume_spike=_vol_spike, btc_trend="خنثی", symbol=symbol,
            funding=None, oi_delta=None,
        )
        # blend: 55% engine + 45% PRO 0-100 mapped to signed
        score = 0.55 * score + 0.45 * float(_pro["signed_score"])
        ex = dict(ex or {})
        ex["pro_core"] = _pro
    except Exception:
        pass

    # mild SMC alignment boost (does not invent direction alone)
    try:
        _sb, _sn = smc_mod.smc_score_boost(
            "LONG" if score >= 0 else "SHORT",
            ex.get("smc") or {},
            px,
        )
        if abs(_sb) >= 0.05:
            score = float(max(-100, min(100, score + _sb * 40)))
            if _sn:
                # reasons filled later from comps; stash note on extras
                ex = dict(ex or {})
                ex["smc_note"] = _sn
    except Exception:
        pass

    side = "LONG" if score >= SIDE_THRESHOLD else "SHORT" if score <= -SIDE_THRESHOLD else "WAIT"
    gated = False
    if side != "WAIT" and agree < MIN_AGREE:          # strong score but indicators disagree -> not a clean setup
        side, gated = "WAIT", True
    # quality hard-gate at TF level (Governor also gates; double-safety)
    if side != "WAIT" and quality < 25 and regime != "range":
        side, gated = "WAIT", True
    # x12 strong conflict soft-gate when agreement is only moderate
    if side != "WAIT" and abs(sc12) >= 35:
        conflict = (side == "LONG" and sc12 < -35) or (side == "SHORT" and sc12 > 35)
        if conflict and agree < 0.72:
            side, gated = "WAIT", True
    bias = "bull" if score >= 12 else "bear" if score <= -12 else "flat"
    use_side = force_side if force_side in ("LONG", "SHORT") else side
    if gated and not force_side:
        use_side = "WAIT"
    d_side = 1 if use_side == "LONG" else -1 if use_side == "SHORT" else 0
    timing_fit = timing * d_side                          # >0: entry timing agrees with the trade direction
    if d_side:
        conf = round(min(0.92, max(0.05, conf + (0.03 if timing_fit >= 25 else -0.04 if timing_fit <= -35 else 0.0))), 3)

    # ── levels ──
    k = {"trend": (1.5, (1.6, 3.0, 4.6)), "range": (1.2, (1.1, 1.9, 2.8)), "neutral": (1.4, (1.4, 2.5, 3.8))}[regime]
    if use_side == "LONG":
        stop = px - k[0] * a
        cand = [x for x in sup_all if 0.9 * a <= px - x + 0.25 * a <= 3 * a]
        if cand:
            stop = min(stop, max(cand) - 0.25 * a)
        stop = min(stop, px - 0.9 * a)
        tps = [px + m * a for m in k[1]]
    elif use_side == "SHORT":
        stop = px + k[0] * a
        cand = [x for x in res_all if 0.9 * a <= x - px + 0.25 * a <= 3 * a]
        if cand:
            stop = max(stop, min(cand) + 0.25 * a)
        stop = max(stop, px + 0.9 * a)
        tps = [px - m * a for m in k[1]]
    else:
        stop, tps = px, [px, px, px]

    # PRO multi-anchor levels override when directional
    if use_side in ("LONG", "SHORT"):
        try:
            sl_hi = float(max(sup_all)) if sup_all else 0.0
            sh_hi = float(min(res_all)) if res_all else 0.0
            # swing approx
            swing_low = float(min(L[-20:])) if len(L) >= 20 else 0.0
            swing_high = float(max(H[-20:])) if len(H) >= 20 else 0.0
            psl, p1, p2, p3 = pro_core.calculate_levels_pro(
                px, a, use_side, swing_low=swing_low, swing_high=swing_high,
                vwap=float(vwap or 0), ema20=float(e21 or 0), ema50=float(e50 or 0),
            )
            if psl > 0 and p1 > 0:
                stop, tps = psl, [p1, p2, p3]
        except Exception:
            pass

    risk = abs(px - stop)
    rr = abs(tps[1] - px) / risk if risk > 0 else 0.0

    zones = []
    prices_pv = [(float(H[i]), "R") for i in ph[-14:]] + [(float(L[i]), "S") for i in pl[-14:]]
    for pxv, _k in sorted(prices_pv):
        if zones and abs(pxv - zones[-1]["p"]) < 0.5 * a:
            z = zones[-1]; z["n"] += 1; z["p"] = (z["p"] * (z["n"] - 1) + pxv) / z["n"]
        else:
            zones.append({"p": pxv, "n": 1})
    for z in zones:
        z["p"] = float(f"{z['p']:.8g}"); z["kind"] = "R" if z["p"] > px else "S"; z["dist_pct"] = round((z["p"] / px - 1) * 100, 2)
    zones_up = sorted([z for z in zones if z["kind"] == "R"], key=lambda z: z["p"])[:4]
    zones_dn = sorted([z for z in zones if z["kind"] == "S"], key=lambda z: -z["p"])[:4]

    # — smarter entries / exits from the x10 layer —
    refs = x10.get("exit_refs") or {}
    misc = (ex.get("osc") or {}).get("misc") or {}
    entry_zone, tp_notes, trail = {}, [], None
    if use_side in ("LONG", "SHORT"):
        anchors = [v for v in (e21, refs.get("vwap")) if v]
        if anchors:
            lo_, hi_ = min(anchors), max(anchors)
            if use_side == "LONG":
                hi_ = min(hi_, px)
                lo_ = min(lo_, hi_)
                now_ok = px - hi_ <= 0.6 * a
            else:
                lo_ = max(lo_, px)
                hi_ = max(hi_, lo_)
                now_ok = lo_ - px <= 0.6 * a
            entry_zone = {"lo": r8_(lo_), "hi": r8_(hi_), "now_ok": bool(now_ok), "src": "EMA21/VWAP",
                          "note": "قیمت در ناحیهٔ ورود خوب است" if now_ok else "قیمت از ناحیهٔ ورود دور شده؛ منتظر پولبک بمانید یا حجم را کم کنید"}
        lim = refs.get("vwap_u2") if use_side == "LONG" else refs.get("vwap_l2")
        lr_lim = refs.get("lr_upper") if use_side == "LONG" else refs.get("lr_lower")
        for nm, tpv in (("TP1", tps[0]), ("TP2", tps[1]), ("TP3", tps[2])):
            for ref, lab in ((lim, "باند ±۲σ VWAP"), (lr_lim, "کران کانال رگرسیون")):
                if ref and ((use_side == "LONG" and tpv > ref) or (use_side == "SHORT" and tpv < ref)):
                    tp_notes.append(f"{nm} فراتر از {lab} است؛ احتمال رسیدن کمتر")
                    break
        trail = misc.get("chandelier_long") if use_side == "LONG" else misc.get("chandelier_short")

    warns = []
    if gated and quality < 25: warns.append(f"کیفیت بازار پایین (x10={quality:.0f}) → انتشار متوقف")
    if gated and abs(sc12) >= 35: warns.append(f"لایه x12 قویاً مخالف ({sc12:+.0f}) با هم‌سویی متوسط")
    if use_side in ("LONG", "SHORT") and quality < 35: warns.append("کیفیت بازار پایین (چاپی/تصادفی)؛ حجم پوزیشن را کم کنید")
    if d_side and timing_fit <= -35: warns.append("زمان‌بندی ورود نامناسب؛ قیمت نسبت به VWAP/کانال کشیده است")
    if atr_pct < 0.2: warns.append("نوسان بسیار کم؛ سیگنال کم‌اعتبار")
    if atr_pct > 6: warns.append("نوسان بسیار شدید؛ حجم پوزیشن را کم کنید")
    if vol_ratio < 0.5: warns.append("حجم کندل آخر ضعیف است")
    if agree < 0.55 and side != "WAIT": warns.append("هم‌سویی اندیکاتورها پایین است")
    stt = ex.get("stats") or {}
    if stt.get("vol_pct", 0) >= 92: warns.append("نوسان در بالاترین صدک ۱۲۰ کندل اخیر")
    if ADV_INDICATORS and x11.get("rvol") is not None and x11["rvol"] < 0.45 and use_side in ("LONG", "SHORT"): warns.append("مشارکت حجمی نسبت به هم‌ساعت‌های قبل بسیار پایین است")
    if use_side == "LONG" and near_r: warns.append("قیمت زیر مقاومت نزدیک است")
    if use_side == "SHORT" and near_s: warns.append("قیمت روی حمایت نزدیک است")
    _smc_n = (ex.get("smc_note") or "")
    if _smc_n:
        warns.append(_smc_n) if "مخالف" in _smc_n or "نزولی" in _smc_n and use_side == "LONG" else None
        # prefer reasons path: keep as soft note only when opposing
    nob = ((ex.get("smc") or {}).get("nearest_ob") or {})
    if use_side == "LONG" and nob.get("type") == "bearish_ob":
        warns.append("نزدیک Order Block نزولی")
    if use_side == "SHORT" and nob.get("type") == "bullish_ob":
        warns.append("نزدیک Order Block صعودی")
    if use_side == "LONG" and r > 75: warns.append("RSI بالا؛ ورود دیرهنگام")
    if use_side == "SHORT" and r < 25: warns.append("RSI پایین؛ ورود دیرهنگام")
    if gated: warns.append("امتیاز بالاست ولی اندیکاتورها هم‌نظر نیستند؛ سیگنال مسدود شد")
    if squeeze: warns.append("فشردگی بولینگر؛ جهت شکست نامشخص است")

    reasons = [c["t"] for c in sorted(comps, key=lambda c: -abs(c["s"] * c["w"])) if abs(c["s"]) >= 0.3][:6]
    reasons.append({"trend": "رژیم: روندی", "range": "رژیم: رنج", "neutral": "رژیم: گذار"}[regime])
    if squeeze:
        reasons.append("فشردگی بولینگر (احتمال حرکت انفجاری)")

    r8 = lambda v: float(f"{float(v):.8g}")
    return Signal(
        symbol=symbol, timeframe=timeframe, side=side if not force_side else use_side,
        score=round(score, 1), confidence=conf, entry=r8(px), stop=r8(stop),
        tp1=r8(tps[0]), tp2=r8(tps[1]), tp3=r8(tps[2]), risk_reward=round(rr, 2),
        reasons=reasons[:8],
        indicators={"rsi": round(r, 2), "atr": r8(a), "atr_pct": round(atr_pct, 3), "ema9": r8(e9), "ema21": r8(e21),
                    "ema50": r8(e50), "ema200": r8(e200), "macd_hist": r8(mh), "bb_pos": round(bb_pos, 3),
                    "stoch_k": round(sk, 2), "vol_ratio": round(vol_ratio, 2), "adx": round(adx, 1),
                    "pdi": round(pdi, 1), "mdi": round(mdi, 1), "supertrend": st_dir, "obv_slope": round(obv_slope, 3),
                    "vwap": r8(vwap), "squeeze": squeeze, "mfi": round(float(mfi), 1), "cmf": round(cmf, 3), "srsi_k": round(k2, 1),
                    "donch_hi": r8(dh), "donch_lo": r8(dl), "roc10": round(roc10 * 100, 2)},
        levels={"resistance": sorted({round(x, 8) for x in res_all}, reverse=True),
                "support": sorted({round(x, 8) for x in sup_all}),
                "bb": {"upper": bu, "mid": bm, "lower": bl}, "zones": zones_up + zones_dn,
                "entry_zone": entry_zone, "tp_notes": tp_notes, "trail": r8(trail) if trail else None, "refs": refs,
                "quality": quality, "timing": timing, "timing_fit": round(timing_fit, 1)},
        components=comps, regime=regime, bias=bias, agree=round(agree, 3), extras=ex, warnings=warns,
    )
