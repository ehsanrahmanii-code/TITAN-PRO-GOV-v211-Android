"""Auto-trading policy: when is a signal trustworthy enough to risk (paper) money on?

Every directional verdict goes through the same explicit gates and the result - with the reason for each failed
gate - is logged, so "why did it (not) open?" always has an answer. Three profiles; every number is overridable.
The gates combine: multi-timeframe grade, indicator agreement, the simulated edge of a concrete entry plan,
extension from the mean, liquidity, per-coin walk-forward evidence, portfolio heat and correlation, BTC alignment
and circuit-breakers (daily loss, loss streak, drawdown)."""
from __future__ import annotations
import json
import os
import threading

from app.config import DATA_DIR

_FILE = DATA_DIR / "auto_cfg.json"
_LOCK = threading.RLock()
GRADES = "ABCD"
BOUNDS = {"risk_pct": (0.05, 2.0), "max_total_risk": (0.5, 10.0), "max_open": (1, 12), "max_same_dir": (1, 12), "min_agree": (0.0, 1.0),
          "min_cons": (0.0, 100.0), "min_ptp1": (0.0, 1.0), "min_rr": (0.5, 10.0), "time_stop_h": (1, 168), "valid_h": (0.25, 72),
          "max_ext_atr": (0.5, 10.0), "min_quality": (0.0, 100.0), "min_timing": (-100.0, 100.0), "min_t": (-1.0, 5.0), "min_qv": (0.0, 1e10)}

MODES = {
    "safe": {"name": "قابل‌اتکا (محتاط)", "min_grade": "B", "min_cons": 48, "min_agree": 0.68, "min_ev": 0.08, "min_ptp1": 0.50, "min_rr": 1.8, "risk_pct": 0.5,
             "max_open": 4, "max_same_dir": 2, "max_total_risk": 2.0, "time_stop_h": 18, "allow_market": False, "min_qv": 8e6, "need_evidence": True, "max_ext_atr": 2.0, "valid_h": 6, "min_quality": 45.0, "min_timing": -20.0, "min_t": 1.0},
    "balanced": {"name": "متعادل", "min_grade": "B", "min_cons": 42, "min_agree": 0.62, "min_ev": 0.03, "min_ptp1": 0.46, "min_rr": 1.6, "risk_pct": 0.7,
                 "max_open": 6, "max_same_dir": 3, "max_total_risk": 3.5, "time_stop_h": 24, "allow_market": True, "min_qv": 4e6, "need_evidence": True, "max_ext_atr": 2.4, "valid_h": 8, "min_quality": 38.0, "min_timing": -35.0, "min_t": 0.5},
    "active": {"name": "فعال (پرمعامله)", "min_grade": "C", "min_cons": 38, "min_agree": 0.58, "min_ev": 0.0, "min_ptp1": 0.42, "min_rr": 1.4, "risk_pct": 1.0,
               "max_open": 8, "max_same_dir": 4, "max_total_risk": 5.0, "time_stop_h": 36, "allow_market": True, "min_qv": 2e6, "need_evidence": False, "max_ext_atr": 3.0, "valid_h": 10, "min_quality": 0.0, "min_timing": -60.0, "min_t": 0.0},
}


def load_cfg() -> dict:
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:                                      # noqa: BLE001
        return {}


def save_cfg(body: dict) -> dict:
    cur = load_cfg()
    mode = body.get("mode", cur.get("mode", "balanced"))
    if mode not in MODES:
        raise ValueError("حالت نامعتبر")
    ov = dict(cur.get("overrides", {})) if mode == cur.get("mode") else {}
    for k, v in (body.get("overrides") or {}).items():
        if k in MODES[mode] and k != "name":
            base = MODES[mode][k]
            try:
                ov[k] = bool(v) if isinstance(base, bool) else str(v) if isinstance(base, str) else float(v)
                if k in BOUNDS and not isinstance(ov[k], (bool, str)):
                    lo_, hi_ = BOUNDS[k]
                    ov[k] = max(lo_, min(hi_, ov[k])) if ov[k] == ov[k] else MODES[mode][k]      # NaN -> default
            except (TypeError, ValueError):
                continue
    if ov.get("min_grade") not in (None, "A", "B", "C"):
        ov.pop("min_grade")
    out = {"mode": mode, "overrides": ov}
    with _LOCK:
        tmp = _FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(out), encoding="utf-8")
        os.replace(tmp, _FILE)
    return out


def effective() -> dict:
    c = load_cfg()
    mode = c.get("mode", "balanced") if c.get("mode") in MODES else "balanced"
    cfg = dict(MODES[mode]); cfg.update(c.get("overrides", {})); cfg["mode"] = mode
    return cfg


def evaluate(cfg: dict, x: dict) -> dict:
    """x: verdict, grade, cons, agree, side, plan (planner row), ind, qv, evidence, open (list), corr (fn), btc_cons, risk_open_pct."""
    checks = []

    def chk(k, ok, text, crit=True):
        checks.append({"k": k, "ok": bool(ok), "t": text, "crit": crit})
    g = x["grade"]
    gi = GRADES.index(g) if g in GRADES else 9
    chk("grade", gi <= GRADES.index(cfg["min_grade"]), f"درجه ستاپ {g} (حداقل {cfg['min_grade']})")
    chk("cons", abs(x["cons"]) >= cfg["min_cons"], f"اجماع {abs(x['cons']):.0f} (حداقل {cfg['min_cons']:.0f})")
    chk("agree", x["agree"] >= cfg["min_agree"], f"هم‌سویی اندیکاتورها {x['agree'] * 100:.0f}٪ (حداقل {cfg['min_agree'] * 100:.0f}٪)")
    p = x.get("plan")
    chk("plan", p is not None, "طرح ورودی با امید ریاضی مثبت در شبیه‌سازی پیدا نشد" if p is None else f"طرح «{p['name']}» انتخاب شد")
    if p:
        rr = abs(p["tp2"] - p["p"]) / max(abs(p["p"] - p["stop"]), 1e-12)
        chk("rr", rr >= cfg["min_rr"], f"ریسک به ریوارد (TP2) {rr:.2f} (حداقل {cfg['min_rr']})")
        chk("ev", p["ev_r"] >= cfg["min_ev"], f"امید ریاضی {p['ev_r']:+.2f}R (حداقل {cfg['min_ev']:+.2f})")
        chk("ptp1", p["p_tp1"] >= cfg["min_ptp1"], f"احتمال TP1 {p['p_tp1'] * 100:.0f}٪ (حداقل {cfg['min_ptp1'] * 100:.0f}٪)")
        chk("mode", p["mode"] != "market" or cfg["allow_market"], "ورود فوری در این حالت مجاز نیست؛ فقط ورود در پولبک/شکست")
    ext = x.get("ext_atr", 0.0)
    if p and p["mode"] == "market":
        chk("ext", ext <= cfg["max_ext_atr"], f"فاصله قیمت از EMA21 = {ext:.1f} ATR (حداکثر {cfg['max_ext_atr']}) — دنبال‌کردن حرکت کشیده")
    q = x.get("quality")
    if q is not None:
        chk("quality", q >= cfg["min_quality"], f"کیفیت بازار (x10) {q:.0f} (حداقل {cfg['min_quality']:.0f})")
    tfit = x.get("timing_fit")
    if tfit is not None and p and p["mode"] == "market":
        chk("timing", tfit >= cfg["min_timing"], f"زمان‌بندی ورود {tfit:+.0f} (حداقل {cfg['min_timing']:+.0f}) — قیمت نسبت به VWAP/کانال کشیده نباشد")
    chk("rsi", not x.get("rsi_extreme"), "RSI در ناحیه اشباع هم‌جهت با ورود (ورود دیرهنگام)")
    chk("liq", x["qv"] >= cfg["min_qv"], f"حجم ۲۴ساعته {x['qv'] / 1e6:.1f}M (حداقل {cfg['min_qv'] / 1e6:.0f}M)")
    ev = x.get("evidence")
    if cfg["need_evidence"]:
        if ev is None:
            chk("evid", gi == 0, "بک‌تست این ارز هنوز آماده نیست (فقط درجه A مجاز است)")
        elif ev["n"] >= 20:
            # Require positive expectancy that is not pure noise; PF / DD / t-stat come from the walk-forward evidence payload
            ok_ev = ev.get("avg_r", -99) >= 0.05 and ev.get("pf", 0) >= 1.15 and ev.get("t", 0.0) >= cfg.get("min_t", 0.0)
            dd_r = ev.get("dd", ev.get("max_dd_r"))
            if dd_r is not None:
                ok_ev = ok_ev and dd_r <= 8.0
            chk("evid", ok_ev,
                f"بک‌تست: avg {ev.get('avg_r', 0):+.2f}R · PF {ev.get('pf', '—')} · t {ev.get('t', 0):+.1f} (حداقل {cfg.get('min_t', 0):.1f}) · DD {dd_r if dd_r is not None else '—'} روی {ev['n']} معامله")
        elif ev["n"] >= 12:
            ok_ev = ev.get("avg_r", -99) >= 0.08 and ev.get("pf", 0) >= 1.25 and ev.get("t", 0.0) >= max(cfg.get("min_t", 0.0), 1.0)
            chk("evid", ok_ev,
                f"نمونه متوسط ({ev['n']}): avg {ev.get('avg_r', 0):+.2f}R · t {ev.get('t', 0):+.1f} (حداقل +1.0) — آستانه سخت‌تر")
        else:
            chk("evid", gi == 0, f"نمونه بک‌تست کم است ({ev['n']} معامله)؛ فقط درجه A")
    op = x["open"]
    chk("n_open", len(op) + x.get("n_orders", 0) < cfg["max_open"], f"{len(op)} پوزیشن/سفارش فعال (سقف {cfg['max_open']:.0f})")
    same = [q for q in op if q["side"] == x["side"]]
    chk("same_dir", len(same) < cfg["max_same_dir"], f"{len(same)} پوزیشن هم‌جهت (سقف {cfg['max_same_dir']:.0f})")
    chk("track", x.get("track_ok", True), x.get("track_text") or "کارنامهٔ زنده مانع نیست")
    chk("ctx", x.get("ctx_ok", True), x.get("ctx_text") or "بافت بازار مانع نیست")
    size = min(cfg["risk_pct"] * {"A": 1.25, "B": 1.0, "C": 0.7}.get(g, 0.5) * (0.75 if x.get("vol_hot") else 1.0), cfg["risk_pct"] * 1.5)
    chk("heat", x["risk_open_pct"] + size <= cfg["max_total_risk"], f"ریسک باز {x['risk_open_pct']:.1f}٪ + {size:.2f}٪ (سقف {cfg['max_total_risk']}٪)")
    hot = [q["symbol"] for q in same if x["corr"](q["symbol"]) > 0.85]
    chk("corr", not hot, "هم‌بستگی بالا با " + "، ".join(s.replace("USDT", "") for s in hot) if hot else "هم‌بستگی با پوزیشن‌ها مشکلی ندارد")
    d = 1 if x["side"] == "LONG" else -1
    if x["symbol"] != "BTCUSDT" and x.get("btc_cons") is not None:
        chk("btc", x["btc_cons"] * d > -45, f"اجماع بیت‌کوین ({x['btc_cons']:+.0f}) شدیداً خلاف جهت است")
    ok = all(c["ok"] for c in checks if c["crit"])
    fails = [c["t"] for c in checks if not c["ok"]]
    return {"ok": ok, "checks": checks, "fails": fails, "risk_pct": round(size, 3)}
