"""Static guard: (1) names that are never bound anywhere in their module, (2) `module.attr` references to app modules whose attribute does not exist.
(Added after a refactor silently deleted two functions that no test touched.)"""
import ast, builtins, importlib, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def check() -> list[str]:
    problems: list[str] = []
    for f in sorted((ROOT / "app").rglob("*.py")):
        tree = ast.parse(f.read_text(encoding="utf-8"))
        bound = set(dir(builtins)) | {"__file__", "__name__"}
        mods: dict[str, str] = {}
        stored = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}      # a local variable may shadow a module name
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                bound.add(n.name)
                if not isinstance(n, ast.ClassDef):
                    a = n.args
                    for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg]:
                        if x:
                            bound.add(x.arg)
            elif isinstance(n, ast.Lambda):
                a = n.args
                for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg]:
                    if x:
                        bound.add(x.arg)
            elif isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
                bound.add(n.id)
            elif isinstance(n, ast.ExceptHandler) and n.name:
                bound.add(n.name)
            elif isinstance(n, (ast.Import, ast.ImportFrom)):
                for al in n.names:
                    nm = (al.asname or al.name).split(".")[0]
                    bound.add(nm)
                    if isinstance(n, ast.ImportFrom) and n.module and n.module.startswith("app"):
                        mods[al.asname or al.name] = f"{n.module}.{al.name}"
            elif isinstance(n, (ast.Global, ast.Nonlocal)):
                bound.update(n.names)
        for n in ast.walk(tree):
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in bound:
                problems.append(f"{f.relative_to(ROOT)}:{n.lineno} undefined name '{n.id}'")
            if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in mods and n.value.id not in stored and isinstance(n.ctx, ast.Load):
                try:
                    m = importlib.import_module(mods[n.value.id])
                except Exception:                                 # not a module (e.g. imported function/class)
                    continue
                if not hasattr(m, n.attr):
                    problems.append(f"{f.relative_to(ROOT)}:{n.lineno} module '{mods[n.value.id]}' has no attribute '{n.attr}'")
    return problems


if __name__ == "__main__":
    pr = check()
    print("\n".join(pr) or "static check OK")
    sys.exit(1 if pr else 0)
