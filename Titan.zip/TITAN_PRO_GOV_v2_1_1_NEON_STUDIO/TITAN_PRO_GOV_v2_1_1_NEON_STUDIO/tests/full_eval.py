#!/usr/bin/env python3
"""Full evaluation of TITAN PRO Clean signal quality and pipeline health."""
from __future__ import annotations
import time
import traceback
import math
from collections import Counter

from app.config import TIMEFRAMES, SIDE_THRESHOLD, VERSION, DATA_DIR
from app.data.market import (
    fetch_tickers, fetch_klines, closed_only, source_status,
    fetch_derivs, fetch_global, fetch_depth,
)
from app.analysis.technicals import analyze
from app.analysis.grade import fuse, grade_from
from app.analysis.forecast import forecast_summary
from app.analysis import patterns as pat
from app.engine.decision import final_voice
from app.engine import context

SYMBOLS = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT",
    "BNBUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "SUIUSDT",
]


def section(title: str):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


def main():
    print(f"TITAN PRO Clean full evaluation — {VERSION}")
    print(f"DATA_DIR = {DATA_DIR}")
    issues = []

    # ── 1. Live data health ────────────────────────────────────────────
    section("1. LIVE DATA HEALTH")
    t0 = time.time()
    ticks = fetch_tickers()
    print(f"Tickers: {len(ticks)} in {time.time()-t0:.2f}s")
    if len(ticks) < 50:
        issues.append("CRITICAL: too few tickers returned")
    for sym in ("BTCUSDT", "ETHUSDT"):
        t = ticks.get(sym) or {}
        print(f"  {sym}: price={t.get('price')} chg={t.get('change_pct')} src={t.get('source')}")
        if not t.get("price"):
            issues.append(f"CRITICAL: no price for {sym}")

    print("\nSource health:")
    for k, v in source_status().items():
        print(f"  {k}: ok={v['ok']} fail={v['fail']} lat={v['lat_ms']}ms cool={v['cooling']}")
        if v["fail"] > 0 and v["ok"] == 0:
            issues.append(f"WARN: source {k} has only failures")

    # klines
    print("\nKlines:")
    for tf in TIMEFRAMES:
        t0 = time.time()
        df = fetch_klines("BTCUSDT", tf, 200)
        elapsed = time.time() - t0
        n = 0 if df is None else len(df)
        print(f"  BTC {tf}: {n} bars in {elapsed:.2f}s")
        if n < 80:
            issues.append(f"WARN: BTC {tf} has only {n} bars")
        if elapsed > 3.0:
            issues.append(f"WARN: BTC {tf} klines slow ({elapsed:.1f}s)")

    # derivs
    print("\nDerivatives BTC:")
    d = fetch_derivs("BTCUSDT")
    print(" ", {k: d.get(k) for k in ("ok", "funding_pct", "oi_usd", "basis_pct", "oi_chg_4h", "ls_buy")})
    if not d.get("ok"):
        issues.append("WARN: derivatives fetch failed for BTC (funding/OI unavailable)")

    print("\nGlobal:", fetch_global())
    dep = fetch_depth("BTCUSDT")
    print("Depth:", {k: dep.get(k) for k in ("ok", "spread_bps", "imbalance", "source")})
    if dep.get("ok") and dep.get("spread_bps") == 0.0:
        issues.append("MINOR: depth spread_bps=0 (possible parse issue on OKX books)")

    # ── 2. Per-symbol multi-TF analysis ────────────────────────────────
    section("2. MULTI-TF SIGNAL ANALYSIS (10 coins)")
    all_sides = []
    grades = []
    errors = 0
    wait_count = 0
    long_count = 0
    short_count = 0

    for sym in SYMBOLS:
        print(f"\n--- {sym} ---")
        sigs = {}
        fcs = {}
        for tf in TIMEFRAMES:
            try:
                full = fetch_klines(sym, tf, 280)
                df = closed_only(full, tf)
                if df is None or len(df) < 50:
                    print(f"  {tf}: insufficient data ({0 if df is None else len(df)})")
                    continue
                price = float(df["close"].iloc[-1])
                sig = analyze(df, sym, tf, price=price)
                sigs[tf] = sig
                lv = None
                if sig.side != "WAIT":
                    lv = {"entry": sig.entry, "stop": sig.stop, "tp1": sig.tp1, "tp2": sig.tp2, "tp3": sig.tp3}
                fc = forecast_summary(df, sig.side, n_ahead=10, seed_key=f"{sym}{tf}", levels=lv)
                fcs[tf] = fc
                rsi = (sig.indicators or {}).get("rsi")
                adx = (sig.indicators or {}).get("adx")
                print(f"  {tf}: {sig.side:5s} score={sig.score:+6.1f} conf={sig.confidence:5.1f} "
                      f"RR={sig.risk_reward} regime={sig.regime} RSI={rsi} ADX={adx}")
                # sanity checks
                if sig.side != "WAIT":
                    if sig.entry is None or sig.stop is None:
                        issues.append(f"BUG: {sym} {tf} directional but missing entry/stop")
                    elif sig.side == "LONG" and sig.stop >= sig.entry:
                        issues.append(f"BUG: {sym} {tf} LONG stop >= entry")
                    elif sig.side == "SHORT" and sig.stop <= sig.entry:
                        issues.append(f"BUG: {sym} {tf} SHORT stop <= entry")
                    if sig.risk_reward is not None and sig.risk_reward < 0:
                        issues.append(f"BUG: {sym} {tf} negative RR")
                if sig.score is not None and (sig.score < -100 or sig.score > 100):
                    issues.append(f"BUG: {sym} {tf} score out of range: {sig.score}")
                if any(isinstance(v, float) and (math.isnan(v) or math.isinf(v)) for v in (sig.score, sig.confidence, sig.risk_reward) if v is not None):
                    issues.append(f"BUG: {sym} {tf} NaN/Inf in core fields")
            except Exception as e:
                errors += 1
                print(f"  {tf}: ERROR {e}")
                traceback.print_exc()
                issues.append(f"ERROR: {sym} {tf} analyze failed: {e}")

        if not sigs:
            print("  no signals")
            continue

        scores = {tf: s.score for tf, s in sigs.items()}
        cons, side, note = fuse(scores, 0.0)
        sig_dicts = {tf: s.to_dict() for tf, s in sigs.items()}
        g = grade_from(sig_dicts, fcs, side, cons, "1h" if "1h" in sigs else next(iter(sigs)), None)
        voice = final_voice(side, cons, g, None, None, None, None)
        print(f"  FUSION → side={side} cons={cons:+.1f} grade={g.get('grade')} "
              f"voice={voice['side']}/{voice['action']} conf={voice['confidence']}")
        if note:
            print(f"  note: {note}")
        if voice.get("vetoes"):
            print(f"  vetoes: {voice['vetoes']}")

        all_sides.append(side)
        grades.append(g.get("grade"))
        if side == "LONG":
            long_count += 1
        elif side == "SHORT":
            short_count += 1
        else:
            wait_count += 1

    # ── 3. Distribution & bias check ───────────────────────────────────
    section("3. SIGNAL DISTRIBUTION")
    print(f"LONG={long_count}  SHORT={short_count}  WAIT={wait_count}  errors={errors}")
    print("Sides:", Counter(all_sides))
    print("Grades:", Counter(grades))
    if long_count + short_count == 0:
        issues.append("WARN: zero directional signals on 10 major coins — system may be overly conservative or data issue")
    if wait_count == len(SYMBOLS):
        issues.append("WARN: all WAIT — check SIDE_THRESHOLD or market conditions")

    # ── 4. Context layer ───────────────────────────────────────────────
    section("4. CONTEXT LAYER")
    try:
        # refresh context for a few symbols
        def chg(sy):
            t = ticks.get(sy) or {}
            return t.get("change_pct")
        context.refresh(SYMBOLS[:5], chg)
        for sym in SYMBOLS[:5]:
            c = context.get(sym)
            print(f"  {sym}: bias={c.get('bias')} liq_ok={c.get('liq_ok')} keys={list(c.keys())[:8]}")
    except Exception as e:
        issues.append(f"ERROR: context layer failed: {e}")
        traceback.print_exc()

    # ── 5. Edge cases & robustness ─────────────────────────────────────
    section("5. EDGE CASES / ROBUSTNESS")
    # empty-ish data
    try:
        from app.analysis.technicals import analyze as an
        import pandas as pd
        empty = pd.DataFrame()
        try:
            r = an(empty, "BTCUSDT", "1h", price=100.0)
            print("  empty df handled:", r.side if r else None)
        except Exception as e:
            print("  empty df raised:", type(e).__name__, e)
            # should not crash the process
    except Exception as e:
        issues.append(f"ERROR: edge empty df: {e}")

    # constant price series
    try:
        import pandas as pd
        import numpy as np
        n = 100
        const = pd.DataFrame({
            "open_time": pd.date_range("2024-01-01", periods=n, freq="h", tz="UTC"),
            "open": 100.0, "high": 100.0, "low": 100.0, "close": 100.0, "volume": 1.0,
        })
        r = analyze(const, "TESTUSDT", "1h", price=100.0)
        print(f"  constant series: side={r.side} score={r.score} (should be neutral/WAIT, no NaN)")
        if r.score is not None and (math.isnan(r.score) or math.isinf(r.score)):
            issues.append("BUG: NaN/Inf score on constant series")
    except Exception as e:
        issues.append(f"ERROR: constant series crashed: {e}")
        traceback.print_exc()

    # ── 6. Decision module ─────────────────────────────────────────────
    section("6. UNIFIED DECISION (final_voice)")
    cases = [
        ("LONG", 35, {"grade": "A", "score": 78}, {"bias": 0.2, "liq_ok": True}, None),
        ("LONG", 22, {"grade": "C", "score": 48}, {"bias": 0.1, "liq_ok": True}, None),
        ("SHORT", -40, {"grade": "B", "score": 65}, {"bias": 0.7, "liq_ok": True}, None),  # context opposes
        ("LONG", 30, {"grade": "B", "score": 60}, {"bias": 0.0, "liq_ok": False}, None),  # liquidity
    ]
    for side, cons, g, ctx, plan in cases:
        v = final_voice(side, cons, g, ctx, plan)
        print(f"  in={side}/{cons}/{g['grade']} → out={v['side']}/{v['action']} conf={v['confidence']} vetoes={v['vetoes']}")

    # ── 7. Summary ─────────────────────────────────────────────────────
    section("7. ISSUES FOUND")
    if not issues:
        print("No issues collected.")
    else:
        for i, msg in enumerate(issues, 1):
            print(f"  {i}. {msg}")

    section("8. OVERALL ASSESSMENT")
    crit = sum(1 for x in issues if x.startswith("CRITICAL") or x.startswith("BUG") or x.startswith("ERROR"))
    warn = sum(1 for x in issues if x.startswith("WARN"))
    print(f"Critical/Bug/Error: {crit}")
    print(f"Warnings: {warn}")
    print(f"Directional signals: {long_count + short_count}/{len(SYMBOLS)}")
    if crit == 0 and (long_count + short_count) > 0:
        print("STATUS: Pipeline is functional. Signal quality needs forward testing.")
    elif crit == 0:
        print("STATUS: Pipeline runs but produced no directional signals (market or threshold).")
    else:
        print("STATUS: Issues need fixing before trusting signals.")
    return issues


if __name__ == "__main__":
    main()
